#!/usr/bin/env python3
"""Four-worker compatibility bridge for Dense Exact v0.3 development."""

from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
from typing import Any, Callable, Mapping

from slcv003_resolution import (
    lift_dos_rows_through_chain,
    validate_fiber_chain,
    validate_fiber_receipt,
)


CAMPAIGN_ID = "SLCV003_DENSE_EXACT_TYPED_RESOLUTION_N96"
VERSION_LABEL = "SLC_DENSE_EXACT_V0_3_DEVELOPMENT"
CLUSTER_SIZE = 4
NODE_IDS = tuple(f"SLC_{index}" for index in range(CLUSTER_SIZE))
CHECKPOINT_DOMAIN = "SLCV003-NODE-ROOT-BATCH-V1"
TABLE_DOMAIN = "SLCV003-NODE-BATCH-STEP-TABLE-V1"
CHAIN_DOMAIN = "SLCV003-FOUR-NODE-WAVE-CHAIN-V1"
DOS_DOMAIN = "SLCV003-EXACT-DOS-V1"
PLAN_DOMAIN = "SLCV003-CLUSTER-PLAN-V1"
SEMANTIC_DOS_DOMAIN = "SLCV003-SEMANTIC-EXACT-DOS-V1"
MINIMUM_AVAILABLE_MEMORY_BYTES = 16 * (1 << 30)
MAXIMUM_AGGREGATE_RSS_BYTES = 12 * (1 << 30)

BASE = Path(__file__).resolve().parent
REPO_ROOT = BASE.parents[1]
BASE_WORKER_PATH = (
    REPO_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLCV002C4_FOUR_SLC_CLUSTER_SCALING_LADDER"
    / "slcv002c4_worker.py"
)
V3_ENGINE_PATH = BASE / "slcv003_core.py"


def _load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _load_base_worker() -> Any:
    return _load_module(BASE_WORKER_PATH, "_slcv003_frozen_cluster_base")


def _load_v3_engine() -> Any:
    path = str(BASE)
    if path not in sys.path:
        sys.path.insert(0, path)
    return _load_module(V3_ENGINE_PATH, f"_slcv003_core_{__import__('os').getpid()}")


_BASE = _load_base_worker()
_ORIGINAL_NODE_LOOP = _BASE._node_loop
_ORIGINAL_BUILD_CLUSTER_PLAN = _BASE.build_cluster_plan

ClusterError = _BASE.ClusterError
atomic_json = _BASE.atomic_json
canonical_sha256 = _BASE.canonical_sha256
dos_mapping = _BASE.dos_mapping
sha256_file = _BASE.sha256_file


def _build_cluster_plan_adapter(instance: Mapping[str, Any]) -> dict[str, Any]:
    raw = dict(_ORIGINAL_BUILD_CLUSTER_PLAN(instance))
    source_hash = raw.pop("source_slcv002_plan_sha256", None)
    source_version = raw.pop("source_slcv002_version_label", None)
    raw.pop("plan_sha256", None)
    raw["schema"] = "SLCV003_CLUSTER_PLAN_V1"
    raw["numeric_compatibility_parent_schema"] = "SLCV002C4_CLUSTER_PLAN_V1"
    raw["source_slcv003_plan_sha256"] = source_hash
    raw["source_slcv003_version_label"] = source_version
    return {**raw, "plan_sha256": canonical_sha256(raw)}


def _node_loop(*args: Any, **kwargs: Any) -> None:
    _configure_base()
    _ORIGINAL_NODE_LOOP(*args, **kwargs)


def _configure_base() -> None:
    _BASE.CAMPAIGN_ID = CAMPAIGN_ID
    _BASE.VERSION_LABEL = VERSION_LABEL
    _BASE.CHECKPOINT_DOMAIN = CHECKPOINT_DOMAIN
    _BASE.TABLE_DOMAIN = TABLE_DOMAIN
    _BASE.CHAIN_DOMAIN = CHAIN_DOMAIN
    _BASE.DOS_DOMAIN = DOS_DOMAIN
    _BASE.PLAN_DOMAIN = PLAN_DOMAIN
    _BASE.MINIMUM_AVAILABLE_MEMORY_BYTES = MINIMUM_AVAILABLE_MEMORY_BYTES
    _BASE.MAXIMUM_AGGREGATE_RSS_BYTES = MAXIMUM_AGGREGATE_RSS_BYTES
    _BASE._load_v2_engine = _load_v3_engine
    _BASE._node_loop = _node_loop
    _BASE.build_cluster_plan = _build_cluster_plan_adapter


_configure_base()


def build_cluster_plan(instance: Mapping[str, Any]) -> dict[str, Any]:
    _configure_base()
    return _build_cluster_plan_adapter(instance)


def attach_semantic_resolution(
    result: Mapping[str, Any],
    instance: Mapping[str, Any],
) -> dict[str, Any]:
    """Attach an exact semantic DOS for one fiber or an explicit chain."""

    raw = dict(result)
    receipts = list(instance.get("resolution_receipts", []))
    if not receipts:
        return raw
    validations = [
        validate_fiber_receipt(receipt) for receipt in receipts
    ]
    chain = instance.get("resolution_chain")
    if len(receipts) > 1:
        if not isinstance(chain, Mapping):
            raise ClusterError(
                "multiple fibers require an explicit dimension-matched chain"
            )
        chain_validation = validate_fiber_chain(chain, receipts)
        chain_sha256 = chain_validation["chain_sha256"]
    elif chain is not None:
        chain_validation = validate_fiber_chain(chain, receipts)
        chain_sha256 = chain_validation["chain_sha256"]
    else:
        chain_sha256 = None
    semantic_rows = lift_dos_rows_through_chain(
        raw["dos"],
        receipts,
        chain=chain if isinstance(chain, Mapping) else None,
    )
    quotient_count = int(raw["configuration_count"])
    semantic_count = sum(int(row["count"]) for row in semantic_rows)
    total_multiplicity = 1
    for validation in validations:
        total_multiplicity *= int(validation["fiber_multiplicity"])
    checks = {
        "quotient_configuration_count": (
            quotient_count == 1 << int(validations[0]["quotient_N"])
        ),
        "semantic_configuration_count": (
            semantic_count == 1 << int(validations[-1]["semantic_N"])
        ),
        "constant_fiber_multiplicity": (
            semantic_count == quotient_count * total_multiplicity
        ),
    }
    if not all(checks.values()):
        raise ClusterError("semantic resolution lift invariant failure")
    raw["semantic_dos"] = semantic_rows
    raw["semantic_dos_sha256"] = canonical_sha256(
        {"domain": SEMANTIC_DOS_DOMAIN, "dos": semantic_rows}
    )
    raw["semantic_configuration_count"] = str(semantic_count)
    raw["resolution_output"] = {
        "schema": "SLCV003_SEMANTIC_RESOLUTION_OUTPUT_V1",
        "quotient_N": int(validations[0]["quotient_N"]),
        "semantic_N": int(validations[-1]["semantic_N"]),
        "fiber_ids": [str(row["fiber_id"]) for row in validations],
        "receipt_sha256s": [
            str(row["receipt_sha256"]) for row in validations
        ],
        "chain_sha256": chain_sha256,
        "total_fiber_multiplicity": total_multiplicity,
        "checks": checks,
    }
    return raw


def run_cluster_instance(
    instance: Mapping[str, Any],
    work_dir: Path,
    *,
    address_space_cap_gib: float = 6.0,
    progress: Callable[[dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    """Run the inherited fused kernel through the v0.3 plan and prime roster."""

    _configure_base()
    raw = dict(
        _BASE.run_cluster_instance(
            instance,
            work_dir,
            address_space_cap_gib=address_space_cap_gib,
            progress=progress,
        )
    )
    numeric_parent_schema = raw.get("schema")
    raw["schema"] = "SLCV003_EXACT_CLUSTER_SOLVE_V1"
    raw["numeric_compatibility_parent_schema"] = numeric_parent_schema
    raw["campaign_id"] = CAMPAIGN_ID
    raw["version_label"] = VERSION_LABEL
    return attach_semantic_resolution(raw, instance)


__all__ = [
    "CAMPAIGN_ID",
    "CHAIN_DOMAIN",
    "CHECKPOINT_DOMAIN",
    "CLUSTER_SIZE",
    "ClusterError",
    "DOS_DOMAIN",
    "NODE_IDS",
    "VERSION_LABEL",
    "attach_semantic_resolution",
    "atomic_json",
    "build_cluster_plan",
    "canonical_sha256",
    "dos_mapping",
    "run_cluster_instance",
    "sha256_file",
]
