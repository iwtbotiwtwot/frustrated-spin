#!/usr/bin/env python3
"""Execute and preserve the first v0.3 numerical regression at N24."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

import slcv003_cluster as cluster


BASE = Path(__file__).resolve().parent
REPO_ROOT = BASE.parents[1]
CORPUS = (
    REPO_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLCX023_EXACT_FRUSTRATED_ISING_DENSITY_OF_STATES_DEVELOPMENT_LADDER"
    / "SLCX023_FROZEN_INSTANCE_CORPUS.jsonl"
)
AUTHORITY = (
    REPO_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLCV002C4_FOUR_SLC_CLUSTER_SCALING_LADDER"
    / "release"
    / "instances"
    / "SLCX023_N24_I00.json"
)
DEFAULT_WORK_DIR = BASE / "work" / "N24_I00_NUMERICAL_REGRESSION"
DEFAULT_RESULT = DEFAULT_WORK_DIR / "SLCV003_N24_I00_REGRESSION.json"
DEFAULT_RESUME_RESULT = DEFAULT_WORK_DIR / "RESUME_VALIDATION.json"


def _load_instance(instance_id: str) -> dict[str, Any]:
    for line in CORPUS.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        if row.get("instance_id") == instance_id:
            return row
    raise cluster.ClusterError(f"source instance absent: {instance_id}")


def _dos_mapping(rows: Sequence[Mapping[str, Any]]) -> dict[int, int]:
    return {
        int(row["energy"]): int(row["count"])
        for row in rows
    }


def _validate_self_hash(record: Mapping[str, Any], label: str) -> None:
    unsigned = {
        key: value
        for key, value in record.items()
        if key != "result_sha256"
    }
    if record.get("result_sha256") != cluster.canonical_sha256(unsigned):
        raise cluster.ClusterError(f"{label} self hash differs")


def _stable_completion_material(
    record: Mapping[str, Any],
) -> dict[str, Any]:
    """Select scientific and execution-structure fields stable across resumes."""

    return {
        key: value
        for key, value in record.items()
        if key not in {"environment", "metrics", "result_sha256"}
    }


def _preserve_resume_validation(
    *,
    path: Path,
    preserved: Mapping[str, Any],
    invocation: Mapping[str, Any],
) -> None:
    stable_equal = (
        cluster.canonical_sha256(_stable_completion_material(preserved))
        == cluster.canonical_sha256(_stable_completion_material(invocation))
    )
    metrics = invocation.get("metrics", {})
    checks = {
        "scientific_and_execution_structure_equal": stable_equal,
        "internal_verification": (
            invocation.get("verification", {}).get("status") == "PASS"
        ),
        "no_tasks_reexecuted": metrics.get("executed_task_count") == 0,
        "all_tasks_reused": (
            metrics.get("reused_task_count")
            == metrics.get("total_task_count")
            == 4
        ),
        "checkpoint_roster_equal": (
            invocation.get("checkpoint_roster_sha256")
            == preserved.get("checkpoint_roster_sha256")
        ),
        "chain_roster_equal": (
            invocation.get("chain_roster_sha256")
            == preserved.get("chain_roster_sha256")
        ),
    }
    unsigned = {
        "schema": "SLCV003_N24_I00_RESUME_VALIDATION_V1",
        "campaign_id": cluster.CAMPAIGN_ID,
        "version_label": cluster.VERSION_LABEL,
        "status": "COMPLETED" if all(checks.values()) else "BOUNDARY",
        "preserved_candidate_result_sha256": preserved["result_sha256"],
        "resume_invocation_result_sha256": invocation["result_sha256"],
        "stable_completion_material_sha256": cluster.canonical_sha256(
            _stable_completion_material(invocation)
        ),
        "checks": checks,
        "resume_metrics": metrics,
    }
    receipt = {
        **unsigned,
        "result_sha256": cluster.canonical_sha256(unsigned),
    }
    if path.exists():
        existing = json.loads(path.read_text(encoding="utf-8"))
        _validate_self_hash(existing, "existing resume validation")
        if existing.get("status") != "COMPLETED":
            raise cluster.ClusterError(
                "existing resume validation reached a boundary"
            )
        if (
            existing.get("stable_completion_material_sha256")
            != receipt["stable_completion_material_sha256"]
        ):
            raise cluster.ClusterError(
                "resume stable completion material differs"
            )
    else:
        cluster.atomic_json(path, receipt, new_only=True)
    if receipt["status"] != "COMPLETED":
        raise cluster.ClusterError("N24 resume validation reached a boundary")


def run(work_dir: Path, result_path: Path) -> dict[str, Any]:
    instance = _load_instance("SLCX023_N24_I00")
    authority = json.loads(AUTHORITY.read_text(encoding="utf-8"))
    candidate_raw = cluster.run_cluster_instance(instance, work_dir)
    candidate_unsigned = dict(candidate_raw)
    candidate = {
        **candidate_unsigned,
        "result_sha256": cluster.canonical_sha256(candidate_unsigned),
    }
    candidate_path = work_dir / "CANDIDATE_COMPLETION.json"
    if candidate_path.exists():
        existing = json.loads(candidate_path.read_text(encoding="utf-8"))
        _validate_self_hash(existing, "existing candidate completion")
        if cluster.canonical_sha256(
            _stable_completion_material(existing)
        ) != cluster.canonical_sha256(
            _stable_completion_material(candidate)
        ):
            differing_keys = sorted(
                key
                for key in (
                    set(_stable_completion_material(existing))
                    | set(_stable_completion_material(candidate))
                )
                if cluster.canonical_sha256(existing.get(key))
                != cluster.canonical_sha256(candidate.get(key))
            )
            raise cluster.ClusterError(
                "existing candidate stable completion fields differ: "
                + ",".join(differing_keys)
            )
        _preserve_resume_validation(
            path=work_dir / "RESUME_VALIDATION.json",
            preserved=existing,
            invocation=candidate,
        )
        candidate = existing
    else:
        cluster.atomic_json(candidate_path, candidate, new_only=True)

    candidate_dos = _dos_mapping(candidate["dos"])
    authority_dos = _dos_mapping(authority["dos"])
    energies = sorted(set(candidate_dos) | set(authority_dos))
    differences = [
        {
            "energy": energy,
            "candidate_count": str(candidate_dos.get(energy, 0)),
            "authority_count": str(authority_dos.get(energy, 0)),
        }
        for energy in energies
        if candidate_dos.get(energy, 0) != authority_dos.get(energy, 0)
    ]
    checks = {
        "candidate_execution_completed": candidate.get("status") == "COMPLETED",
        "candidate_internal_verification": (
            candidate.get("verification", {}).get("status") == "PASS"
        ),
        "all_four_workers_observed": (
            candidate.get("metrics", {}).get("maximum_active_nodes") == 4
        ),
        "configuration_count_equal": (
            candidate.get("configuration_count")
            == authority.get("configuration_count")
            == str(1 << 24)
        ),
        "every_dos_coefficient_equal": not differences,
        "induced_width_10": candidate["plan"]["induced_width"] == 10,
        "node_checkpoint_count_4": (
            len(candidate.get("checkpoint_roster", [])) == 4
        ),
        "four_node_wave_count_1": (
            len(candidate.get("chain_roster", [])) == 1
        ),
    }
    unsigned = {
        "schema": "SLCV003_N24_I00_NUMERICAL_REGRESSION_V1",
        "campaign_id": cluster.CAMPAIGN_ID,
        "version_label": cluster.VERSION_LABEL,
        "status": "COMPLETED" if all(checks.values()) else "BOUNDARY",
        "instance_id": instance["instance_id"],
        "instance_sha256": instance["instance_sha256"],
        "source_corpus_path": str(CORPUS.relative_to(REPO_ROOT)),
        "source_corpus_sha256": cluster.sha256_file(CORPUS),
        "authority_path": str(AUTHORITY.relative_to(REPO_ROOT)),
        "authority_file_sha256": cluster.sha256_file(AUTHORITY),
        "authority_result_sha256": authority.get("result_sha256"),
        "candidate_completion_path": str(candidate_path.relative_to(BASE)),
        "candidate_result_sha256": candidate["result_sha256"],
        "candidate_plan_sha256": candidate["plan"]["plan_sha256"],
        "candidate_dos_sha256": candidate["dos_sha256"],
        "authority_dos_sha256": authority["dos_sha256"],
        "coefficient_domain": [
            min(energies) if energies else None,
            max(energies) if energies else None,
        ],
        "coefficient_position_count": len(energies),
        "coefficient_difference_count": len(differences),
        "coefficient_differences": differences,
        "checks": checks,
        "metrics": candidate["metrics"],
    }
    result = {
        **unsigned,
        "result_sha256": cluster.canonical_sha256(unsigned),
    }
    if result_path.exists():
        existing = json.loads(result_path.read_text(encoding="utf-8"))
        _validate_self_hash(existing, "existing N24 regression result")
        if cluster.canonical_sha256(existing) != cluster.canonical_sha256(
            result
        ):
            raise cluster.ClusterError("existing N24 regression result differs")
    else:
        cluster.atomic_json(result_path, result, new_only=True)
    if result["status"] != "COMPLETED":
        raise cluster.ClusterError("N24 numerical regression reached a boundary")
    return result


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--work-dir", type=Path, default=DEFAULT_WORK_DIR)
    parser.add_argument("--result", type=Path, default=DEFAULT_RESULT)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    result = run(args.work_dir.resolve(), args.result.resolve())
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
