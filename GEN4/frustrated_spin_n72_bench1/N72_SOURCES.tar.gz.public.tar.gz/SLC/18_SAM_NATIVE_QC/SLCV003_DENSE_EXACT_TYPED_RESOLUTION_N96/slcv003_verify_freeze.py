#!/usr/bin/env python3
"""Create or verify the v0.3 pre-dense-N96 candidate manifest."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

import slcv003_cluster as cluster
import slcv003_core as core


BASE = Path(__file__).resolve().parent
SLC_ROOT = BASE.parents[1]
MANIFEST_PATH = (
    BASE / "release" / "SLCV003_PRE_DENSE_N96_FREEZE_MANIFEST.json"
)

SOURCE_FILES = (
    "README.md",
    "SLCV003_ARCHITECTURE.md",
    "SLCV003_CONTRACT.json",
    "slcv003_cluster.py",
    "slcv003_core.py",
    "slcv003_n24_regression.py",
    "slcv003_n96_crt_regression.py",
    "slcv003_resolution.py",
    "slcv003_verify_freeze.py",
    "tests/test_slcv003.py",
)

ARTIFACTS = (
    (
        "N24_CANDIDATE_COMPLETION",
        "work/N24_I00_NUMERICAL_REGRESSION/CANDIDATE_COMPLETION.json",
        "result_sha256",
    ),
    (
        "N24_COEFFICIENT_REGRESSION",
        (
            "work/N24_I00_NUMERICAL_REGRESSION/"
            "SLCV003_N24_I00_REGRESSION.json"
        ),
        "result_sha256",
    ),
    (
        "N24_RESUME_VALIDATION",
        "work/N24_I00_NUMERICAL_REGRESSION/RESUME_VALIDATION.json",
        "result_sha256",
    ),
    (
        "N96_CRT_FIXTURE_INSTANCE",
        (
            "work/N96_FOUR_PRIME_CRT_CONTROL/"
            "SLCV003_N96_PAIR_FIXTURE_INSTANCE.json"
        ),
        "instance_sha256",
    ),
    (
        "N96_CRT_ANALYTIC_AUTHORITY",
        (
            "work/N96_FOUR_PRIME_CRT_CONTROL/"
            "SLCV003_N96_PAIR_ANALYTIC_AUTHORITY.json"
        ),
        "result_sha256",
    ),
    (
        "N96_CRT_CANDIDATE_COMPLETION",
        "work/N96_FOUR_PRIME_CRT_CONTROL/CANDIDATE_COMPLETION.json",
        "result_sha256",
    ),
    (
        "N96_CRT_COEFFICIENT_REGRESSION",
        (
            "work/N96_FOUR_PRIME_CRT_CONTROL/"
            "SLCV003_N96_FOUR_PRIME_CRT_REGRESSION.json"
        ),
        "result_sha256",
    ),
    (
        "N96_CRT_RESUME_VALIDATION",
        "work/N96_FOUR_PRIME_CRT_CONTROL/RESUME_VALIDATION.json",
        "result_sha256",
    ),
)

DEPENDENCIES = (
    (
        "FUSED_NUMERICAL_KERNEL",
        (
            "18_SAM_NATIVE_QC/"
            "SLCX030_N72_STRUCTURE_ONLY_RETAINED_BOUNDARY_COMPRESSION_GATE/"
            "release/executed_capsule/slcx029_graph_engine.py"
        ),
        core.EXPECTED_FUSED_ENGINE_SHA256,
    ),
    (
        "EXACT_ARITHMETIC_PARENT",
        (
            "18_SAM_NATIVE_QC/"
            "SLCX025_EXACT_N72_FRUSTRATED_ISING_DOS_EXTENSION/"
            "SLCX025_EXECUTION_CAPSULE/slcx023_exact_engine.py"
        ),
        core.EXPECTED_PARENT_ENGINE_SHA256,
    ),
    (
        "FOUR_WORKER_ROOT_SHARD_PARENT",
        (
            "18_SAM_NATIVE_QC/"
            "SLCV002C4_FOUR_SLC_CLUSTER_SCALING_LADDER/"
            "slcv002c4_worker.py"
        ),
        "a21e3cbbf7099a2d5285b7a93d45a843df451d42709558acd6b9cc8048ff027f",
    ),
    (
        "TYPED_CELL_UNION_LINEAGE",
        (
            "18_SAM_NATIVE_QC/"
            "SLCX043_EXACT_TYPED_CELL_TRANSFER_UNION/slcx043_engine.py"
        ),
        "c6dae37e00d31d5270c1fc38fa56ba813c514200e197c0f06248d41532015502",
    ),
)


def _validate_embedded_seal(
    record: Mapping[str, Any],
    seal_key: str,
    label: str,
) -> None:
    unsigned = {
        key: value
        for key, value in record.items()
        if key != seal_key
    }
    if record.get(seal_key) != core.canonical_sha256(unsigned):
        raise core.SLCV003Error(f"{label} embedded seal differs")


def _source_rows() -> list[dict[str, Any]]:
    rows = []
    for relative in SOURCE_FILES:
        path = BASE / relative
        if not path.is_file() or path.is_symlink():
            raise core.SLCV003Error(f"source file absent or indirect: {relative}")
        rows.append(
            {
                "path": relative,
                "sha256": core.sha256_file(path),
            }
        )
    return rows


def _artifact_rows() -> list[dict[str, Any]]:
    rows = []
    for role, relative, seal_key in ARTIFACTS:
        path = BASE / relative
        if not path.is_file() or path.is_symlink():
            raise core.SLCV003Error(
                f"regression artifact absent or indirect: {relative}"
            )
        record = json.loads(path.read_text(encoding="utf-8"))
        _validate_embedded_seal(record, seal_key, role)
        rows.append(
            {
                "role": role,
                "path": relative,
                "file_sha256": core.sha256_file(path),
                "embedded_seal_key": seal_key,
                "embedded_seal": record[seal_key],
                "status": record.get("status"),
            }
        )
    return rows


def _dependency_rows() -> list[dict[str, Any]]:
    rows = []
    for role, relative, expected in DEPENDENCIES:
        path = SLC_ROOT / relative
        observed = core.sha256_file(path)
        if observed != expected:
            raise core.SLCV003Error(f"dependency custody differs: {role}")
        rows.append(
            {
                "role": role,
                "path": relative,
                "sha256": observed,
            }
        )
    return rows


def build_manifest() -> dict[str, Any]:
    n24 = json.loads(
        (
            BASE
            / "work/N24_I00_NUMERICAL_REGRESSION/"
            "SLCV003_N24_I00_REGRESSION.json"
        ).read_text(encoding="utf-8")
    )
    n96 = json.loads(
        (
            BASE
            / "work/N96_FOUR_PRIME_CRT_CONTROL/"
            "SLCV003_N96_FOUR_PRIME_CRT_REGRESSION.json"
        ).read_text(encoding="utf-8")
    )
    unsigned = {
        "schema": "SLCV003_PRE_DENSE_N96_FREEZE_MANIFEST_V1",
        "campaign_id": cluster.CAMPAIGN_ID,
        "version_label": cluster.VERSION_LABEL,
        "status": "FROZEN_PRE_DENSE_N96_GENERATION",
        "dense_frustrated_n96_benchmark_status": "NOT_GENERATED",
        "source_files": _source_rows(),
        "source_roster_sha256": core.canonical_sha256(_source_rows()),
        "numerical_dependencies": _dependency_rows(),
        "dependency_roster_sha256": core.canonical_sha256(
            _dependency_rows()
        ),
        "regression_artifacts": _artifact_rows(),
        "artifact_roster_sha256": core.canonical_sha256(_artifact_rows()),
        "regression_summary": {
            "N24": {
                "result_sha256": n24["result_sha256"],
                "coefficient_position_count": n24[
                    "coefficient_position_count"
                ],
                "coefficient_difference_count": n24[
                    "coefficient_difference_count"
                ],
                "all_checks": all(n24["checks"].values()),
            },
            "N96_four_prime_arithmetic_control": {
                "result_sha256": n96["result_sha256"],
                "coefficient_position_count": n96[
                    "coefficient_position_count"
                ],
                "coefficient_difference_count": n96[
                    "coefficient_difference_count"
                ],
                "selected_primes": n96["selected_primes"],
                "all_checks": all(n96["checks"].values()),
            },
            "unit_test_count": 13,
            "unit_test_command": (
                "PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover "
                "-s SLC/18_SAM_NATIVE_QC/"
                "SLCV003_DENSE_EXACT_TYPED_RESOLUTION_N96/tests -v"
            ),
        },
        "next_authorized_sequence": [
            "GENERATE_ONE_UNFILTERED_DENSE_FRUSTRATED_N96_INSTANCE",
            "SEAL_INSTANCE_BEFORE_DOS_EXECUTION",
            "COMPILE_MONOLITHIC_AND_TYPED_CELL_PLANS",
            "EXECUTE_ONLY_THE_FROZEN_ADMISSIBLE_PLAN",
        ],
    }
    return {
        **unsigned,
        "manifest_sha256": core.canonical_sha256(unsigned),
    }


def verify_manifest(manifest_path: Path = MANIFEST_PATH) -> dict[str, Any]:
    observed = json.loads(manifest_path.read_text(encoding="utf-8"))
    unsigned = {
        key: value
        for key, value in observed.items()
        if key != "manifest_sha256"
    }
    if observed.get("manifest_sha256") != core.canonical_sha256(unsigned):
        raise core.SLCV003Error("freeze manifest self hash differs")
    expected = build_manifest()
    if core.canonical_sha256(observed) != core.canonical_sha256(expected):
        raise core.SLCV003Error("freeze manifest differs from current custody")
    return {
        "status": "PASS",
        "manifest_path": str(manifest_path.relative_to(BASE)),
        "manifest_sha256": observed["manifest_sha256"],
        "source_file_count": len(observed["source_files"]),
        "dependency_count": len(observed["numerical_dependencies"]),
        "artifact_count": len(observed["regression_artifacts"]),
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--manifest", type=Path, default=MANIFEST_PATH)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    path = args.manifest.resolve()
    if args.write and not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        cluster.atomic_json(path, build_manifest(), new_only=True)
    report = verify_manifest(path)
    print(json.dumps(report, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
