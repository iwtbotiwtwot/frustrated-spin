#!/usr/bin/env python3
"""Generic N24-N96 planning and numerical bridge for Dense Exact v0.3."""

from __future__ import annotations

from collections import defaultdict, deque
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import ModuleType
from typing import Any, Iterable, Mapping, Sequence

from slcv003_resolution import (
    make_global_spin_gauge_fiber,
    validate_fiber_chain,
    validate_fiber_receipt,
)


CAMPAIGN_ID = "SLCV003_DENSE_EXACT_TYPED_RESOLUTION_N96"
VERSION_LABEL = "SLC_DENSE_EXACT_V0_3_DEVELOPMENT"
PLAN_SCHEMA = "SLCV003_EXECUTION_PLAN_V1"
PLAN_DOMAIN = "SLCV003-DENSE-EXACT-PLAN-V1"
CHECKPOINT_DOMAIN = "SLCV003-ROOT-BATCH-CHECKPOINT-V1"
TABLE_DOMAIN = "SLCV003-BATCH-STEP-TABLE-V1"
DOS_DOMAIN = "SLCV003-EXACT-DOS-V1"

BENCHMARK_SIZES = frozenset({24, 48, 60, 72, 96})
ALLOWED_SIZES = frozenset(range(1, 97))
CELL_SIZE = 12
RETAINED_BATCH_ENTRY_CAP = 1 << 26
LOGICAL_UNION_BATCH_ENTRY_CAP = 1 << 27
FUSED_CHUNK_CAP = 32768
MAX_NTT_LENGTH = 2048
PRIMITIVE_ROOT = 3
PRIMES = (998244353, 1004535809, 469762049, 167772161)
THREE_PRIME_PRODUCT = PRIMES[0] * PRIMES[1] * PRIMES[2]
FOUR_PRIME_PRODUCT = THREE_PRIME_PRODUCT * PRIMES[3]

EXPECTED_FUSED_ENGINE_SHA256 = (
    "9827128293c306439000e5160fcac3d13d534cb825b7c508fcdef921bdded3aa"
)
EXPECTED_PARENT_ENGINE_SHA256 = (
    "fb8bff08ae0836a628a90edb141f8e3d96ae13d96075eb2e2031d12737f77c5a"
)

BASE = Path(__file__).resolve().parent
REPO_ROOT = BASE.parents[1]
DEFAULT_FUSED_ENGINE = (
    REPO_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLCX030_N72_STRUCTURE_ONLY_RETAINED_BOUNDARY_COMPRESSION_GATE"
    / "release"
    / "executed_capsule"
    / "slcx029_graph_engine.py"
)
DEFAULT_PARENT_ENGINE = (
    REPO_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLCX025_EXACT_N72_FRUSTRATED_ISING_DOS_EXTENSION"
    / "SLCX025_EXECUTION_CAPSULE"
    / "slcx023_exact_engine.py"
)


class SLCV003Error(RuntimeError):
    """Raised when a v0.3 contract, plan, or numerical dependency is invalid."""


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seal_instance(instance: Mapping[str, Any]) -> dict[str, Any]:
    unsigned = {
        key: value for key, value in instance.items() if key != "instance_sha256"
    }
    return {**unsigned, "instance_sha256": canonical_sha256(unsigned)}


def ntt_length_for_bound(bound: int) -> int:
    if type(bound) is not int or bound < 0:
        raise SLCV003Error("energy bound must be a nonnegative integer")
    length = 1
    while length <= 2 * bound:
        length <<= 1
    if length > MAX_NTT_LENGTH:
        raise SLCV003Error("NTT length exceeds the v0.3 dense benchmark cap")
    if any((prime - 1) % length for prime in PRIMES):
        raise SLCV003Error("NTT length is unsupported by the v0.3 prime roster")
    return length


def selected_primes(n: int) -> tuple[int, ...]:
    if type(n) is not int or n < 0:
        raise SLCV003Error("N must be a nonnegative integer")
    product = 1
    selected: list[int] = []
    for prime in PRIMES:
        selected.append(prime)
        product *= prime
        if product > 1 << n:
            return tuple(selected)
    raise SLCV003Error("four-prime CRT product is smaller than the state count")


def _require_int(value: Any, label: str) -> int:
    if type(value) is not int:
        raise SLCV003Error(f"{label} must be a plain integer")
    return value


def _edge_pairs(instance: Mapping[str, Any]) -> list[tuple[int, int]]:
    return [(int(row[0]), int(row[1])) for row in instance["edges"]]


def _connected(n: int, pairs: Iterable[tuple[int, int]]) -> bool:
    adjacency = [set() for _ in range(n)]
    for left, right in pairs:
        adjacency[left].add(right)
        adjacency[right].add(left)
    seen = {0}
    queue: deque[int] = deque([0])
    while queue:
        vertex = queue.popleft()
        for neighbor in adjacency[vertex]:
            if neighbor not in seen:
                seen.add(neighbor)
                queue.append(neighbor)
    return len(seen) == n


def _induced_width(
    n: int,
    pairs: Iterable[tuple[int, int]],
    order: Sequence[int],
) -> int:
    adjacency = {vertex: set() for vertex in range(n)}
    for left, right in pairs:
        adjacency[left].add(right)
        adjacency[right].add(left)
    remaining = set(range(n))
    width = 0
    for raw_vertex in order:
        vertex = int(raw_vertex)
        if vertex not in remaining:
            raise SLCV003Error("elimination order is not a vertex permutation")
        neighbors = sorted(adjacency[vertex] & remaining)
        width = max(width, len(neighbors))
        for index, left in enumerate(neighbors):
            for right in neighbors[index + 1 :]:
                adjacency[left].add(right)
                adjacency[right].add(left)
        for neighbor in neighbors:
            adjacency[neighbor].discard(vertex)
        remaining.remove(vertex)
    if remaining:
        raise SLCV003Error("elimination order omitted vertices")
    return width


def _crossing_stats(
    n: int,
    pairs: Iterable[tuple[int, int]],
) -> tuple[int, list[list[int]]]:
    cell_count = n // CELL_SIZE
    counts = [[0 for _ in range(cell_count)] for _ in range(cell_count)]
    crossing = 0
    for left, right in pairs:
        left_cell, right_cell = left // CELL_SIZE, right // CELL_SIZE
        if left_cell != right_cell:
            crossing += 1
            counts[left_cell][right_cell] += 1
            counts[right_cell][left_cell] += 1
    return crossing, counts


def _validate_k33_witness(
    witness: Any,
    pairs: set[tuple[int, int]],
    n: int,
) -> None:
    if not isinstance(witness, list) or len(witness) != 9:
        raise SLCV003Error("k33_witness_edges must contain nine edges")
    witness_pairs: list[tuple[int, int]] = []
    for index, raw in enumerate(witness):
        if not isinstance(raw, list) or len(raw) != 2:
            raise SLCV003Error(f"k33_witness_edges[{index}] is malformed")
        left = _require_int(raw[0], f"k33_witness_edges[{index}][0]")
        right = _require_int(raw[1], f"k33_witness_edges[{index}][1]")
        if not (0 <= left < n and 0 <= right < n and left != right):
            raise SLCV003Error("K3,3 witness vertex lies outside the graph")
        pair = (min(left, right), max(left, right))
        if pair not in pairs:
            raise SLCV003Error("K3,3 witness edge is absent")
        witness_pairs.append(pair)
    if len(set(witness_pairs)) != 9:
        raise SLCV003Error("K3,3 witness contains duplicate edges")
    adjacency: dict[int, set[int]] = defaultdict(set)
    for left, right in witness_pairs:
        adjacency[left].add(right)
        adjacency[right].add(left)
    if len(adjacency) != 6 or any(
        len(neighbors) != 3 for neighbors in adjacency.values()
    ):
        raise SLCV003Error("K3,3 witness is not a six-vertex cubic graph")
    colors: dict[int, int] = {}
    for root in adjacency:
        if root in colors:
            continue
        colors[root] = 0
        queue: deque[int] = deque([root])
        while queue:
            vertex = queue.popleft()
            for neighbor in adjacency[vertex]:
                if neighbor not in colors:
                    colors[neighbor] = 1 - colors[vertex]
                    queue.append(neighbor)
                elif colors[neighbor] == colors[vertex]:
                    raise SLCV003Error("K3,3 witness is not bipartite")
    if list(colors.values()).count(0) != 3 or list(colors.values()).count(1) != 3:
        raise SLCV003Error("K3,3 witness does not have a 3+3 partition")


def validate_solver_instance(instance: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the generic integer pairwise solver contract through N96."""

    if not isinstance(instance, Mapping):
        raise SLCV003Error("instance must be a mapping")
    instance_id = instance.get("instance_id")
    if not isinstance(instance_id, str) or not instance_id:
        raise SLCV003Error("instance_id must be a nonempty string")
    n = _require_int(instance.get("N"), "N")
    if n not in ALLOWED_SIZES:
        raise SLCV003Error("solver N lies outside 1..96")

    fields = instance.get("fields")
    if not isinstance(fields, list) or len(fields) != n:
        raise SLCV003Error("fields must contain exactly N entries")
    canonical_fields = [
        _require_int(value, f"fields[{index}]")
        for index, value in enumerate(fields)
    ]

    raw_edges = instance.get("edges")
    if not isinstance(raw_edges, list):
        raise SLCV003Error("edges must be a list")
    weighted: list[tuple[int, int, int]] = []
    pairs: set[tuple[int, int]] = set()
    for index, raw in enumerate(raw_edges):
        if not isinstance(raw, list) or len(raw) != 3:
            raise SLCV003Error(f"edges[{index}] must be [u,v,J]")
        left = _require_int(raw[0], f"edges[{index}][0]")
        right = _require_int(raw[1], f"edges[{index}][1]")
        coupling = _require_int(raw[2], f"edges[{index}][2]")
        if not 0 <= left < right < n:
            raise SLCV003Error("edges must use canonical 0<=u<v<N endpoints")
        if coupling == 0:
            raise SLCV003Error("zero pair couplings must be omitted")
        if (left, right) in pairs:
            raise SLCV003Error("parallel edge detected")
        pairs.add((left, right))
        weighted.append((left, right, coupling))
    if weighted != sorted(weighted):
        raise SLCV003Error("weighted edges are not canonically sorted")
    if instance.get("edge_count") is not None and (
        _require_int(instance["edge_count"], "edge_count") != len(weighted)
    ):
        raise SLCV003Error("edge_count mismatch")

    bound = sum(abs(coupling) for _, _, coupling in weighted) + sum(
        abs(value) for value in canonical_fields
    )
    if instance.get("energy_bound_B") != bound:
        raise SLCV003Error("energy_bound_B mismatch")
    ntt_length = ntt_length_for_bound(bound)

    orders = instance.get("orders")
    widths = instance.get("induced_widths")
    required = ("cell_min_fill", "min_fill", "min_degree")
    if not isinstance(orders, Mapping):
        raise SLCV003Error("orders must be a mapping")
    if not all(name in orders for name in required):
        raise SLCV003Error("one or more required order seeds are absent")
    observed_widths: dict[str, int] = {}
    for name in required:
        raw_order = orders[name]
        if not isinstance(raw_order, list) or len(raw_order) != n:
            raise SLCV003Error(f"orders[{name}] has the wrong length")
        order = [
            _require_int(value, f"orders[{name}]")
            for value in raw_order
        ]
        if sorted(order) != list(range(n)):
            raise SLCV003Error(f"orders[{name}] is not a vertex permutation")
        observed_widths[name] = _induced_width(n, pairs, order)
    if widths is not None:
        if not isinstance(widths, Mapping):
            raise SLCV003Error("induced_widths must be a mapping")
        for name, observed_width in observed_widths.items():
            if widths.get(name) != observed_width:
                raise SLCV003Error(f"induced width mismatch for {name}")

    expected_hash = canonical_sha256(
        {
            key: value
            for key, value in instance.items()
            if key != "instance_sha256"
        }
    )
    if instance.get("instance_sha256") != expected_hash:
        raise SLCV003Error("instance_sha256 mismatch")

    receipts = instance.get("resolution_receipts", [])
    if not isinstance(receipts, list):
        raise SLCV003Error("resolution_receipts must be a list")
    receipt_validations = []
    for receipt in receipts:
        validation = validate_fiber_receipt(receipt)
        receipt_validations.append(validation)
    for index, validation in enumerate(receipt_validations):
        expected_quotient_n = (
            n
            if index == 0
            else int(receipt_validations[index - 1]["semantic_N"])
        )
        if int(validation["quotient_N"]) != expected_quotient_n:
            raise SLCV003Error(
                "fiber receipt quotient dimension differs from its input"
            )
    chain = instance.get("resolution_chain")
    if len(receipts) > 1:
        if chain is None:
            raise SLCV003Error(
                "multiple fiber receipts require an explicit chain"
            )
        validate_fiber_chain(chain, receipts)
    elif chain is not None:
        if not receipts:
            raise SLCV003Error("fiber chain supplied without receipts")
        validate_fiber_chain(chain, receipts)

    return {
        "status": "PASS",
        "instance_id": instance_id,
        "instance_sha256": expected_hash,
        "N": n,
        "edge_count": len(weighted),
        "energy_bound_B": bound,
        "ntt_length": ntt_length,
        "induced_widths": observed_widths,
        "resolution_receipt_count": len(receipts),
        "resolution_chain_sha256": (
            chain.get("chain_sha256")
            if isinstance(chain, Mapping)
            else None
        ),
    }


def validate_benchmark_instance(instance: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the N24-N96 five-regular frustrated-spin benchmark family."""

    report = validate_solver_instance(instance)
    n = int(report["N"])
    if n not in BENCHMARK_SIZES:
        raise SLCV003Error("N is outside the N24/N48/N60/N72/N96 ladder")
    if instance.get("cell_size") != CELL_SIZE:
        raise SLCV003Error("benchmark cell_size must be 12")
    if instance.get("cell_count") != n // CELL_SIZE:
        raise SLCV003Error("benchmark cell_count mismatch")
    if any(int(value) not in {-2, -1, 0, 1, 2} for value in instance["fields"]):
        raise SLCV003Error("benchmark field lies outside the inherited alphabet")
    if any(int(row[2]) not in {-3, -2, -1, 1, 2, 3} for row in instance["edges"]):
        raise SLCV003Error("benchmark coupling lies outside the inherited alphabet")

    degrees = [0] * n
    pairs = set(_edge_pairs(instance))
    for left, right in pairs:
        degrees[left] += 1
        degrees[right] += 1
    if len(pairs) != 5 * n // 2 or instance.get("edge_count") != len(pairs):
        raise SLCV003Error("benchmark edge count is not five-regular")
    if any(degree != 5 for degree in degrees):
        raise SLCV003Error("benchmark graph is not five-regular")
    if not _connected(n, pairs):
        raise SLCV003Error("benchmark graph is disconnected")
    _validate_k33_witness(instance.get("k33_witness_edges"), pairs, n)

    crossing, counts = _crossing_stats(n, pairs)
    if instance.get("cross_cell_edge_count") != crossing:
        raise SLCV003Error("cross_cell_edge_count mismatch")
    if instance.get("cell_pair_edge_counts") != counts:
        raise SLCV003Error("cell_pair_edge_counts mismatch")
    return {
        **report,
        "family": "SLC_DENSE_FRUSTRATED_FIVE_REGULAR",
        "cell_count": n // CELL_SIZE,
        "cross_cell_edge_count": crossing,
    }


def validate_instance(instance: Mapping[str, Any]) -> dict[str, Any]:
    """Dispatch to the strict benchmark family or generic quotient contract."""

    if "k33_witness_edges" in instance or instance.get("family") == (
        "SLC_DENSE_FRUSTRATED_FIVE_REGULAR"
    ):
        return validate_benchmark_instance(instance)
    return validate_solver_instance(instance)


def _adjacency(instance: Mapping[str, Any]) -> dict[int, set[int]]:
    n = int(instance["N"])
    result = {vertex: set() for vertex in range(n)}
    for left, right, _coupling in instance["edges"]:
        result[int(left)].add(int(right))
        result[int(right)].add(int(left))
    return result


def _fill_count(
    vertex: int,
    adjacency: Mapping[int, set[int]],
    remaining: set[int],
) -> int:
    neighbors = sorted(adjacency[vertex] & remaining)
    return sum(
        right not in adjacency[left]
        for index, left in enumerate(neighbors)
        for right in neighbors[index + 1 :]
    )


def _eliminate(
    vertex: int,
    adjacency: dict[int, set[int]],
    remaining: set[int],
) -> None:
    neighbors = sorted(adjacency[vertex] & remaining)
    for index, left in enumerate(neighbors):
        for right in neighbors[index + 1 :]:
            adjacency[left].add(right)
            adjacency[right].add(left)
    for neighbor in neighbors:
        adjacency[neighbor].discard(vertex)
    remaining.remove(vertex)


def order_structure(
    instance: Mapping[str, Any],
    order: Sequence[int],
) -> dict[str, Any]:
    """Return the graph-only retained and union sizes for one order."""

    n = int(instance["N"])
    canonical_order = tuple(int(vertex) for vertex in order)
    if len(canonical_order) != n or sorted(canonical_order) != list(range(n)):
        raise SLCV003Error("candidate order is not a vertex permutation")
    adjacency = _adjacency(instance)
    remaining = set(range(n))
    steps: list[dict[str, Any]] = []
    width = 0
    union_sum = 0
    output_sum = 0
    for step, vertex in enumerate(canonical_order, 1):
        neighbors = tuple(sorted(adjacency[vertex] & remaining))
        degree = len(neighbors)
        union_entries = 1 << (degree + 1)
        output_entries = 1 << degree
        width = max(width, degree)
        union_sum += union_entries
        output_sum += output_entries
        steps.append(
            {
                "step": step,
                "vertex": vertex,
                "output_neighbors": list(neighbors),
                "induced_width": degree,
                "union_assignment_entries": union_entries,
                "output_assignment_entries": output_entries,
            }
        )
        _eliminate(vertex, adjacency, remaining)
    return {
        "induced_width": width,
        "sum_2_pow_union_scope": union_sum,
        "sum_2_pow_output_scope": output_sum,
        "peak_union_assignment_entries": max(
            row["union_assignment_entries"] for row in steps
        ),
        "peak_output_assignment_entries": max(
            row["output_assignment_entries"] for row in steps
        ),
        "canonical_order": list(canonical_order),
        "score": [width, union_sum, list(canonical_order)],
        "steps": steps,
    }


def _portfolio_greedy_order(
    instance: Mapping[str, Any],
    policy: str,
) -> list[int]:
    """Reproduce the inherited finite graph-only order policies."""

    n = int(instance["N"])
    cell_size = int(instance.get("cell_size", CELL_SIZE))
    adjacency = _adjacency(instance)
    remaining = set(range(n))
    order: list[int] = []

    def simulate_next_min_fill(candidate: int) -> int:
        if len(remaining) <= 1:
            return 0
        trial_adjacency = {
            vertex: set(neighbors)
            for vertex, neighbors in adjacency.items()
        }
        trial_remaining = set(remaining)
        _eliminate(candidate, trial_adjacency, trial_remaining)
        return min(
            _fill_count(vertex, trial_adjacency, trial_remaining)
            for vertex in trial_remaining
        )

    while remaining:
        rows: list[tuple[tuple[int, ...], int]] = []
        for vertex in sorted(remaining):
            degree = len(adjacency[vertex] & remaining)
            fill = _fill_count(vertex, adjacency, remaining)
            cross = sum(
                neighbor // cell_size != vertex // cell_size
                for neighbor in adjacency[vertex] & remaining
            )
            if policy == "deterministic_min_fill_degree_vertex":
                key = (fill, degree, vertex)
            elif policy == "deterministic_min_fill_cross_degree_vertex":
                key = (fill, cross, degree, vertex)
            elif policy == "deterministic_min_fill_degree_cross_vertex":
                key = (fill, degree, cross, vertex)
            elif policy == "one_step_lookahead_min_fill":
                key = (
                    fill,
                    simulate_next_min_fill(vertex),
                    degree,
                    cross,
                    vertex,
                )
            else:
                raise SLCV003Error(f"unknown portfolio policy: {policy}")
            rows.append((key, vertex))
        chosen = min(rows)[1]
        order.append(chosen)
        _eliminate(chosen, adjacency, remaining)
    return order


def _adjacent_swap_refinement(
    instance: Mapping[str, Any],
    seed: Sequence[int],
) -> list[int]:
    current = [int(value) for value in seed]
    structure = order_structure(instance, current)
    current_score = (
        int(structure["induced_width"]),
        int(structure["sum_2_pow_union_scope"]),
        tuple(current),
    )
    for index in range(len(current) - 1):
        trial = list(current)
        trial[index], trial[index + 1] = trial[index + 1], trial[index]
        structure = order_structure(instance, trial)
        trial_score = (
            int(structure["induced_width"]),
            int(structure["sum_2_pow_union_scope"]),
            tuple(trial),
        )
        if trial_score < current_score:
            current = trial
            current_score = trial_score
    return current


PORTFOLIO_IDS = (
    "historical_cell_min_fill",
    "historical_min_fill",
    "historical_min_degree",
    "deterministic_min_fill_degree_vertex",
    "deterministic_min_fill_cross_degree_vertex",
    "deterministic_min_fill_degree_cross_vertex",
    "one_step_lookahead_min_fill",
    "deterministic_adjacent_swap_refinement",
)


def select_graph_only_order(instance: Mapping[str, Any]) -> dict[str, Any]:
    """Select from the inherited fixed graph-only portfolio."""

    historical = instance.get("orders")
    if not isinstance(historical, Mapping):
        raise SLCV003Error("instance lacks historical order seeds")
    generated: dict[str, list[int]] = {
        "historical_cell_min_fill": [
            int(value) for value in historical["cell_min_fill"]
        ],
        "historical_min_fill": [
            int(value) for value in historical["min_fill"]
        ],
        "historical_min_degree": [
            int(value) for value in historical["min_degree"]
        ],
    }
    for policy in (
        "deterministic_min_fill_degree_vertex",
        "deterministic_min_fill_cross_degree_vertex",
        "deterministic_min_fill_degree_cross_vertex",
        "one_step_lookahead_min_fill",
    ):
        generated[policy] = _portfolio_greedy_order(instance, policy)
    generated["deterministic_adjacent_swap_refinement"] = (
        _adjacent_swap_refinement(
            instance,
            generated["deterministic_min_fill_degree_vertex"],
        )
    )
    if tuple(generated) != PORTFOLIO_IDS:
        raise SLCV003Error("portfolio identity or order drift")
    portfolio = [
        {
            "policy_id": policy_id,
            **order_structure(instance, generated[policy_id]),
        }
        for policy_id in PORTFOLIO_IDS
    ]
    selected = min(
        portfolio,
        key=lambda row: (
            int(row["induced_width"]),
            int(row["sum_2_pow_union_scope"]),
            tuple(int(value) for value in row["canonical_order"]),
        ),
    )
    return {
        "selection_rule": (
            "LEXICOGRAPHIC_MIN_INDUCED_WIDTH_THEN_SUM_2_POW_UNION_"
            "THEN_CANONICAL_ORDER"
        ),
        "portfolio_ids": list(PORTFOLIO_IDS),
        "portfolio": portfolio,
        "selected_policy_id": selected["policy_id"],
        "selected_order": list(selected["canonical_order"]),
        "selected_structure": selected,
        "portfolio_sha256": canonical_sha256(portfolio),
    }


def deterministic_order(
    instance: Mapping[str, Any],
    policy: str,
) -> list[int]:
    n = int(instance["N"])
    cell_size = int(instance.get("cell_size", CELL_SIZE))
    adjacency = _adjacency(instance)
    remaining = set(range(n))
    order: list[int] = []
    while remaining:
        rows: list[tuple[tuple[int, ...], int]] = []
        for vertex in sorted(remaining):
            degree = len(adjacency[vertex] & remaining)
            fill = _fill_count(vertex, adjacency, remaining)
            cross = sum(
                neighbor // cell_size != vertex // cell_size
                for neighbor in adjacency[vertex] & remaining
            )
            if policy == "min_fill":
                key = (fill, degree, vertex)
            elif policy == "min_degree":
                key = (degree, fill, vertex)
            elif policy == "cell_min_fill":
                key = (cross, fill, degree, vertex)
            else:
                raise SLCV003Error(f"unknown deterministic order policy: {policy}")
            rows.append((key, vertex))
        chosen = min(rows)[1]
        order.append(chosen)
        _eliminate(chosen, adjacency, remaining)
    return order


def attach_deterministic_orders(instance: Mapping[str, Any]) -> dict[str, Any]:
    unsigned = {
        key: value for key, value in instance.items() if key != "instance_sha256"
    }
    orders = {
        name: deterministic_order(unsigned, name)
        for name in ("cell_min_fill", "min_fill", "min_degree")
    }
    pairs = _edge_pairs(unsigned)
    unsigned["orders"] = orders
    unsigned["induced_widths"] = {
        name: _induced_width(int(unsigned["N"]), pairs, order)
        for name, order in orders.items()
    }
    return seal_instance(unsigned)


def compile_global_spin_gauge(
    semantic_instance: Mapping[str, Any],
    *,
    anchor_site: int = 0,
) -> dict[str, Any]:
    """Compile one zero-field model to a fixed-spin orbit representative."""

    validation = validate_solver_instance(semantic_instance)
    semantic_n = int(validation["N"])
    if not 0 <= anchor_site < semantic_n:
        raise SLCV003Error("gauge anchor lies outside the semantic roster")
    if semantic_instance["fields"] != [0] * semantic_n:
        raise SLCV003Error("global-spin gauge requires exactly zero source fields")

    quotient_to_semantic = [
        site for site in range(semantic_n) if site != anchor_site
    ]
    semantic_to_quotient: list[int | None] = [None] * semantic_n
    for quotient_site, semantic_site in enumerate(quotient_to_semantic):
        semantic_to_quotient[semantic_site] = quotient_site

    quotient_n = semantic_n - 1
    fields = [0] * quotient_n
    edges: list[list[int]] = []
    incident: list[list[int]] = []
    for raw_left, raw_right, raw_coupling in semantic_instance["edges"]:
        left, right, coupling = (
            int(raw_left),
            int(raw_right),
            int(raw_coupling),
        )
        if anchor_site in (left, right):
            other = right if left == anchor_site else left
            mapped = semantic_to_quotient[other]
            if mapped is None:
                raise SLCV003Error("gauge compiler encountered an invalid edge")
            fields[mapped] += coupling
            incident.append([left, right, coupling])
        else:
            mapped_left = semantic_to_quotient[left]
            mapped_right = semantic_to_quotient[right]
            if mapped_left is None or mapped_right is None:
                raise SLCV003Error("gauge remap omitted a non-anchor endpoint")
            edges.append(
                [
                    min(mapped_left, mapped_right),
                    max(mapped_left, mapped_right),
                    coupling,
                ]
            )
    edges.sort()
    bound = sum(abs(row[2]) for row in edges) + sum(abs(value) for value in fields)
    if bound != int(semantic_instance["energy_bound_B"]):
        raise SLCV003Error("gauge compilation changed the energy bound")
    receipt = make_global_spin_gauge_fiber(
        semantic_n=semantic_n,
        anchor_site=anchor_site,
        source_instance_sha256=str(semantic_instance["instance_sha256"]),
    )
    unsigned = {
        "schema": "SLCV003_GLOBAL_SPIN_GAUGE_INSTANCE_V1",
        "campaign_id": CAMPAIGN_ID,
        "instance_id": f"{semantic_instance['instance_id']}__GAUGE_Q{quotient_n}",
        "N": quotient_n,
        "semantic_N": semantic_n,
        "fields": fields,
        "edges": edges,
        "edge_count": len(edges),
        "energy_bound_B": bound,
        "gauge": {
            "symmetry": "GLOBAL_SPIN_FLIP",
            "anchor_site": anchor_site,
            "fixed_spin": 1,
            "incident_edge_to_field_rule": "h_v=J_anchor_v",
            "constant_energy_shift": 0,
        },
        "anchor_incident_source_edges": sorted(incident),
        "quotient_to_semantic_site": quotient_to_semantic,
        "semantic_to_quotient_site": semantic_to_quotient,
        "resolution_receipts": [receipt],
        "semantic_source_instance": dict(semantic_instance),
    }
    return attach_deterministic_orders(unsigned)


def compile_cell_linkage(
    instance: Mapping[str, Any],
    *,
    compact_port_certificates: Mapping[str, Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Assign every local and cross-cell factor to one typed packet."""

    n = int(instance["N"])
    cell_size = int(instance.get("cell_size", CELL_SIZE))
    cell_count = (n + cell_size - 1) // cell_size
    local: dict[int, list[dict[str, Any]]] = {
        cell: [] for cell in range(cell_count)
    }
    boundaries: dict[tuple[int, int], list[dict[str, Any]]] = defaultdict(list)
    for factor_index, raw in enumerate(instance["edges"]):
        left, right, coupling = map(int, raw)
        row = {
            "factor_index": factor_index,
            "u": left,
            "v": right,
            "J": coupling,
        }
        left_cell, right_cell = left // cell_size, right // cell_size
        if left_cell == right_cell:
            local[left_cell].append(row)
        else:
            boundaries[(left_cell, right_cell)].append(row)

    certificates = compact_port_certificates or {}
    boundary_rows: list[dict[str, Any]] = []
    for (left_cell, right_cell), factors in sorted(boundaries.items()):
        left_sites = sorted(
            {
                row["u"] if row["u"] // cell_size == left_cell else row["v"]
                for row in factors
            }
        )
        right_sites = sorted(
            {
                row["u"] if row["u"] // cell_size == right_cell else row["v"]
                for row in factors
            }
        )
        key = f"{left_cell}:{right_cell}"
        certificate = certificates.get(key)
        compact = bool(
            isinstance(certificate, Mapping)
            and certificate.get("sufficiency_status") == "ESTABLISHED"
            and certificate.get("left_sites") == left_sites
            and certificate.get("right_sites") == right_sites
        )
        boundary_rows.append(
            {
                "boundary_id": f"CELL_{left_cell}__CELL_{right_cell}",
                "left_cell": left_cell,
                "right_cell": right_cell,
                "packet_type": (
                    "COMPACT_TYPED_TRANSFER"
                    if compact
                    else "DENSE_FACTOR_PACKET"
                ),
                "left_sites": left_sites,
                "right_sites": right_sites,
                "raw_boundary_site_count": len(left_sites) + len(right_sites),
                "cross_factor_count": len(factors),
                "factors": factors,
                "compact_certificate_sha256": (
                    canonical_sha256(certificate) if compact else None
                ),
            }
        )

    local_rows = [
        {
            "cell_id": f"CELL_{cell}",
            "cell_index": cell,
            "site_start": cell * cell_size,
            "site_stop": min(n, (cell + 1) * cell_size),
            "local_factor_count": len(local[cell]),
            "factors": local[cell],
        }
        for cell in range(cell_count)
    ]
    owned = [
        row["factor_index"]
        for cell in local_rows
        for row in cell["factors"]
    ] + [
        row["factor_index"]
        for boundary in boundary_rows
        for row in boundary["factors"]
    ]
    if sorted(owned) != list(range(len(instance["edges"]))):
        raise SLCV003Error("typed cell linkage does not own every factor exactly once")
    unsigned = {
        "schema": "SLCV003_TYPED_CELL_LINKAGE_PLAN_V1",
        "operator": "T_(A_UNION_B)=T_A STAR_BOUNDARY(A,B) T_B",
        "default_boundary_packet": "DENSE_FACTOR_PACKET",
        "cell_size": cell_size,
        "cell_count": cell_count,
        "local_packets": local_rows,
        "boundary_packets": boundary_rows,
        "local_factor_count": sum(row["local_factor_count"] for row in local_rows),
        "cross_factor_count": sum(
            row["cross_factor_count"] for row in boundary_rows
        ),
        "owned_factor_count": len(owned),
        "factor_ownership_complete": True,
        "factor_ownership_unique": len(owned) == len(set(owned)),
    }
    return {
        **unsigned,
        "linkage_plan_sha256": canonical_sha256(unsigned),
    }


def _largest_power_of_two_at_most(value: int) -> int:
    if value < 1:
        raise SLCV003Error("no admissible root batch under the capacity contract")
    return 1 << (value.bit_length() - 1)


def _load_module(path: Path, expected_sha256: str, name: str) -> ModuleType:
    if path.is_symlink() or not path.is_file():
        raise SLCV003Error(f"numerical source must be a regular file: {path}")
    observed = sha256_file(path)
    if observed != expected_sha256:
        raise SLCV003Error(f"numerical source custody mismatch: {path.name}")
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise SLCV003Error(f"could not import numerical source: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(name, None)
        raise
    return module


def load_engines(
    fused_path: Path = DEFAULT_FUSED_ENGINE,
    parent_path: Path = DEFAULT_PARENT_ENGINE,
) -> tuple[ModuleType, ModuleType]:
    """Load the sealed fused kernel with the v0.3 validator and prime roster."""

    fused = _load_module(
        fused_path,
        EXPECTED_FUSED_ENGINE_SHA256,
        f"_slcv003_fused_{EXPECTED_FUSED_ENGINE_SHA256[:12]}",
    )
    fused.ALLOWED_SIZES = ALLOWED_SIZES
    fused.FROZEN_CHUNK_CAP = FUSED_CHUNK_CAP
    fused._load_parent.cache_clear()
    # The sealed loader first checks the inherited three-prime parent exactly
    # as stored.  The v0.3 fourth prime is attached only after that source
    # custody check succeeds.
    parent = fused.load_parent(parent_path)
    parent.ALLOWED_SIZES = ALLOWED_SIZES
    parent.NTT_PRIMES = PRIMES
    parent.MAX_NTT_LENGTH = MAX_NTT_LENGTH
    parent.validate_instance = validate_instance
    fused.PARENT_PRIMES = PRIMES
    return fused, parent


def build_plan(
    instance: Mapping[str, Any],
    fused: ModuleType | None = None,
    parent: ModuleType | None = None,
) -> dict[str, Any]:
    """Build a generic, capacity-bounded four-prime-ready execution plan."""

    validation = dict(validate_instance(instance))
    selection = select_graph_only_order(instance)
    structure = dict(selection["selected_structure"])
    n = int(instance["N"])
    ntt_length = ntt_length_for_bound(int(instance["energy_bound_B"]))
    primes = selected_primes(n)
    retained_per_root = int(structure["peak_output_assignment_entries"])
    union_per_root = int(structure["peak_union_assignment_entries"])
    raw_limit = min(
        ntt_length,
        RETAINED_BATCH_ENTRY_CAP // retained_per_root,
        LOGICAL_UNION_BATCH_ENTRY_CAP // union_per_root,
    )
    root_batch_size = _largest_power_of_two_at_most(raw_limit)
    if ntt_length % root_batch_size:
        raise SLCV003Error("root batch does not divide the NTT length")
    cluster_root_batch = min(root_batch_size, ntt_length // 4)
    if cluster_root_batch < 1 or cluster_root_batch & (cluster_root_batch - 1):
        raise SLCV003Error("four-worker root batch is not a positive power of two")
    if ntt_length % cluster_root_batch:
        raise SLCV003Error("four-worker root batch does not divide the NTT length")
    tasks_per_prime = ntt_length // cluster_root_batch
    if tasks_per_prime % 4:
        raise SLCV003Error("four-worker plan contains a partial wave")

    receipts = list(instance.get("resolution_receipts", []))
    receipt_validations = [
        validate_fiber_receipt(receipt) for receipt in receipts
    ]
    resolution_chain = instance.get("resolution_chain")
    linkage = compile_cell_linkage(instance)
    order = [int(value) for value in selection["selected_order"]]
    unsigned = {
        "schema": PLAN_SCHEMA,
        "domain": PLAN_DOMAIN,
        "campaign_id": CAMPAIGN_ID,
        "version_label": VERSION_LABEL,
        "instance_id": str(instance["instance_id"]),
        "instance_sha256": str(instance["instance_sha256"]),
        "N": n,
        "semantic_N": (
            int(receipt_validations[-1]["semantic_N"])
            if receipt_validations
            else n
        ),
        "validation_status": validation.get("status"),
        "benchmark_family": validation.get("family"),
        "selected_policy_id": str(selection["selected_policy_id"]),
        "selected_order": order,
        "selected_order_sha256": canonical_sha256(order),
        "portfolio_sha256": str(selection["portfolio_sha256"]),
        "induced_width": int(structure["induced_width"]),
        "sum_2_pow_union_scope": int(structure["sum_2_pow_union_scope"]),
        "peak_retained_entries_per_root": retained_per_root,
        "peak_union_entries_per_root": union_per_root,
        "ntt_length": ntt_length,
        "primes": list(primes),
        "crt_modulus_product": str(
            __import__("math").prod(primes)
        ),
        "solver_configuration_count": str(1 << n),
        "root_batch_size": root_batch_size,
        "retained_batch_entries": retained_per_root * root_batch_size,
        "logical_union_batch_entries": union_per_root * root_batch_size,
        "retained_batch_entry_cap": RETAINED_BATCH_ENTRY_CAP,
        "logical_union_batch_entry_cap": LOGICAL_UNION_BATCH_ENTRY_CAP,
        "fused_chunk_cap": FUSED_CHUNK_CAP,
        "fused_engine_sha256": EXPECTED_FUSED_ENGINE_SHA256,
        "parent_engine_sha256": EXPECTED_PARENT_ENGINE_SHA256,
        "checkpoint_domain": CHECKPOINT_DOMAIN,
        "resolution_receipts": receipts,
        "resolution_receipt_count": len(receipts),
        "typed_cell_linkage": linkage,
        "typed_cell_linkage_sha256": linkage["linkage_plan_sha256"],
        "four_worker_preview": {
            "cluster_size": 4,
            "root_batch_size": cluster_root_batch,
            "tasks_per_prime": tasks_per_prime,
            "waves_per_prime": tasks_per_prime // 4,
            "total_task_count": tasks_per_prime * len(primes),
            "total_wave_count": (tasks_per_prime // 4) * len(primes),
        },
    }
    if isinstance(resolution_chain, Mapping):
        unsigned["resolution_chain"] = resolution_chain
        unsigned["resolution_chain_sha256"] = resolution_chain[
            "chain_sha256"
        ]
    if int(unsigned["crt_modulus_product"]) <= 1 << n:
        raise SLCV003Error("CRT product does not exceed the coefficient ceiling")
    if unsigned["retained_batch_entries"] > RETAINED_BATCH_ENTRY_CAP:
        raise SLCV003Error("retained capacity violation")
    if unsigned["logical_union_batch_entries"] > LOGICAL_UNION_BATCH_ENTRY_CAP:
        raise SLCV003Error("logical-union capacity violation")
    return {
        **unsigned,
        "plan_sha256": canonical_sha256(unsigned),
    }


def dos_mapping(result: Mapping[str, Any]) -> dict[int, int]:
    return {
        int(row["energy"]): int(row["count"])
        for row in result.get("dos", [])
    }


__all__ = [
    "ALLOWED_SIZES",
    "BENCHMARK_SIZES",
    "CAMPAIGN_ID",
    "CHECKPOINT_DOMAIN",
    "DEFAULT_FUSED_ENGINE",
    "DEFAULT_PARENT_ENGINE",
    "DOS_DOMAIN",
    "FOUR_PRIME_PRODUCT",
    "FUSED_CHUNK_CAP",
    "LOGICAL_UNION_BATCH_ENTRY_CAP",
    "PRIMES",
    "RETAINED_BATCH_ENTRY_CAP",
    "SLCV003Error",
    "THREE_PRIME_PRODUCT",
    "VERSION_LABEL",
    "attach_deterministic_orders",
    "build_plan",
    "canonical_sha256",
    "compile_cell_linkage",
    "compile_global_spin_gauge",
    "deterministic_order",
    "dos_mapping",
    "load_engines",
    "ntt_length_for_bound",
    "seal_instance",
    "selected_primes",
    "sha256_file",
    "validate_benchmark_instance",
    "validate_instance",
    "validate_solver_instance",
]
