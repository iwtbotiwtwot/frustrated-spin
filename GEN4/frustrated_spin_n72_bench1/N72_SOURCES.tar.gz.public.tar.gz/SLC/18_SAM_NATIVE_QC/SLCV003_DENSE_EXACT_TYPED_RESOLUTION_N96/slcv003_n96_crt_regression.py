#!/usr/bin/env python3
"""Exercise the four-prime N96 path against an analytic exact DOS."""

from __future__ import annotations

import argparse
import json
from math import comb
from pathlib import Path
from typing import Any, Mapping, Sequence

import slcv003_cluster as cluster
import slcv003_core as core


BASE = Path(__file__).resolve().parent
DEFAULT_WORK_DIR = BASE / "work" / "N96_FOUR_PRIME_CRT_CONTROL"
DEFAULT_INSTANCE = DEFAULT_WORK_DIR / "SLCV003_N96_PAIR_FIXTURE_INSTANCE.json"
DEFAULT_AUTHORITY = (
    DEFAULT_WORK_DIR / "SLCV003_N96_PAIR_ANALYTIC_AUTHORITY.json"
)
DEFAULT_CANDIDATE = DEFAULT_WORK_DIR / "CANDIDATE_COMPLETION.json"
DEFAULT_RESUME = DEFAULT_WORK_DIR / "RESUME_VALIDATION.json"
DEFAULT_RESULT = (
    DEFAULT_WORK_DIR / "SLCV003_N96_FOUR_PRIME_CRT_REGRESSION.json"
)


def build_fixture() -> dict[str, Any]:
    """Return 48 independent Ising pairs with an exact closed-form DOS."""

    edges = [
        [site, site + 1, 1]
        for site in range(0, 96, 2)
    ]
    unsigned = {
        "schema": "SLCV003_N96_PAIR_CRT_FIXTURE_V1",
        "campaign_id": cluster.CAMPAIGN_ID,
        "family": "N96_FOUR_PRIME_CRT_ARITHMETIC_CONTROL",
        "instance_id": "SLCV003_N96_PAIR_CRT_CONTROL_I00",
        "N": 96,
        "cell_size": 12,
        "fields": [0] * 96,
        "edges": edges,
        "edge_count": len(edges),
        "energy_bound_B": len(edges),
        "analytic_authority": {
            "independent_pair_count": 48,
            "single_pair_polynomial": "2*x^-1+2*x^1",
            "coefficient_rule": (
                "g(-48+2k)=2^48*binomial(48,k),0<=k<=48"
            ),
        },
    }
    return core.attach_deterministic_orders(unsigned)


def analytic_dos_rows() -> list[dict[str, Any]]:
    return [
        {
            "energy": -48 + 2 * anti_aligned_pairs,
            "count": str((1 << 48) * comb(48, anti_aligned_pairs)),
        }
        for anti_aligned_pairs in range(49)
    ]


def _dos_mapping(rows: Sequence[Mapping[str, Any]]) -> dict[int, int]:
    return {
        int(row["energy"]): int(row["count"])
        for row in rows
    }


def _seal(unsigned: Mapping[str, Any]) -> dict[str, Any]:
    return {
        **unsigned,
        "result_sha256": cluster.canonical_sha256(unsigned),
    }


def _validate_self_hash(record: Mapping[str, Any], label: str) -> None:
    unsigned = {
        key: value
        for key, value in record.items()
        if key != "result_sha256"
    }
    if record.get("result_sha256") != cluster.canonical_sha256(unsigned):
        raise cluster.ClusterError(f"{label} self hash differs")


def _preserve_exact(path: Path, record: Mapping[str, Any], label: str) -> None:
    if path.exists():
        existing = json.loads(path.read_text(encoding="utf-8"))
        if cluster.canonical_sha256(existing) != cluster.canonical_sha256(
            record
        ):
            raise cluster.ClusterError(f"existing {label} differs")
    else:
        cluster.atomic_json(path, record, new_only=True)


def _stable_completion_material(
    record: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        key: value
        for key, value in record.items()
        if key not in {"environment", "metrics", "result_sha256"}
    }


def _preserve_candidate(
    path: Path,
    resume_path: Path,
    invocation: Mapping[str, Any],
) -> dict[str, Any]:
    if not path.exists():
        cluster.atomic_json(path, invocation, new_only=True)
        return dict(invocation)

    preserved = json.loads(path.read_text(encoding="utf-8"))
    _validate_self_hash(preserved, "preserved N96 CRT candidate")
    preserved_stable_hash = cluster.canonical_sha256(
        _stable_completion_material(preserved)
    )
    invocation_stable_hash = cluster.canonical_sha256(
        _stable_completion_material(invocation)
    )
    metrics = invocation.get("metrics", {})
    checks = {
        "scientific_and_execution_structure_equal": (
            preserved_stable_hash == invocation_stable_hash
        ),
        "internal_verification": (
            invocation.get("verification", {}).get("status") == "PASS"
        ),
        "no_tasks_reexecuted": metrics.get("executed_task_count") == 0,
        "all_tasks_reused": (
            metrics.get("reused_task_count")
            == metrics.get("total_task_count")
            == 16
        ),
        "checkpoint_roster_equal": (
            invocation.get("checkpoint_roster_sha256")
            == preserved.get("checkpoint_roster_sha256")
        ),
        "chain_roster_equal": (
            invocation.get("chain_roster_sha256")
            == preserved.get("chain_roster_sha256")
        ),
    }
    unsigned = {
        "schema": "SLCV003_N96_FOUR_PRIME_CRT_RESUME_VALIDATION_V1",
        "campaign_id": cluster.CAMPAIGN_ID,
        "version_label": cluster.VERSION_LABEL,
        "status": "COMPLETED" if all(checks.values()) else "BOUNDARY",
        "preserved_candidate_result_sha256": preserved["result_sha256"],
        "resume_invocation_result_sha256": invocation["result_sha256"],
        "stable_completion_material_sha256": invocation_stable_hash,
        "checks": checks,
        "resume_metrics": metrics,
    }
    receipt = _seal(unsigned)
    if resume_path.exists():
        existing = json.loads(resume_path.read_text(encoding="utf-8"))
        _validate_self_hash(existing, "existing N96 CRT resume validation")
        if existing.get("status") != "COMPLETED":
            raise cluster.ClusterError(
                "existing N96 CRT resume validation reached a boundary"
            )
        if (
            existing.get("stable_completion_material_sha256")
            != invocation_stable_hash
        ):
            raise cluster.ClusterError(
                "N96 CRT resume stable completion material differs"
            )
    else:
        cluster.atomic_json(resume_path, receipt, new_only=True)
    if receipt["status"] != "COMPLETED":
        raise cluster.ClusterError(
            "N96 CRT resume validation reached a boundary"
        )
    return preserved


def run(
    work_dir: Path,
    result_path: Path,
) -> dict[str, Any]:
    work_dir.mkdir(parents=True, exist_ok=True)
    instance = build_fixture()
    validation = core.validate_solver_instance(instance)
    instance_path = work_dir / DEFAULT_INSTANCE.name
    _preserve_exact(instance_path, instance, "N96 CRT fixture")

    authority_rows = analytic_dos_rows()
    maximum_authority_coefficient = max(
        int(row["count"]) for row in authority_rows
    )
    authority_unsigned = {
        "schema": "SLCV003_N96_PAIR_ANALYTIC_DOS_AUTHORITY_V1",
        "instance_id": instance["instance_id"],
        "instance_sha256": instance["instance_sha256"],
        "derivation": {
            "independent_pair_count": 48,
            "single_pair_aligned_states": 2,
            "single_pair_aligned_energy": -1,
            "single_pair_antialigned_states": 2,
            "single_pair_antialigned_energy": 1,
            "coefficient_rule": (
                "g(-48+2k)=2^48*binomial(48,k),0<=k<=48"
            ),
        },
        "dos": authority_rows,
        "configuration_count": str(1 << 96),
        "maximum_coefficient": str(maximum_authority_coefficient),
        "dos_sha256": cluster.canonical_sha256(
            {
                "domain": "SLCV003-N96-PAIR-ANALYTIC-DOS-V1",
                "dos": authority_rows,
            }
        ),
    }
    authority = _seal(authority_unsigned)
    authority_path = work_dir / DEFAULT_AUTHORITY.name
    _preserve_exact(authority_path, authority, "N96 analytic authority")

    candidate_raw = cluster.run_cluster_instance(instance, work_dir)
    candidate = _seal(candidate_raw)
    candidate = _preserve_candidate(
        work_dir / DEFAULT_CANDIDATE.name,
        work_dir / DEFAULT_RESUME.name,
        candidate,
    )

    candidate_dos = _dos_mapping(candidate["dos"])
    authority_dos = _dos_mapping(authority_rows)
    energies = sorted(set(candidate_dos) | set(authority_dos))
    differences = [
        {
            "energy": energy,
            "candidate_count": str(candidate_dos.get(energy, 0)),
            "authority_count": str(authority_dos.get(energy, 0)),
        }
        for energy in energies
        if candidate_dos.get(energy, 0) != authority_dos.get(energy, 0)
    ]
    plan = candidate["plan"]
    checks = {
        "generic_n96_fixture_valid": validation.get("status") == "PASS",
        "candidate_execution_completed": candidate.get("status") == "COMPLETED",
        "candidate_internal_verification": (
            candidate.get("verification", {}).get("status") == "PASS"
        ),
        "all_four_workers_observed": (
            candidate.get("metrics", {}).get("maximum_active_nodes") == 4
        ),
        "four_prime_roster_used": plan.get("primes") == list(core.PRIMES),
        "fourth_prime_used": core.PRIMES[3] in plan.get("primes", []),
        "three_prime_product_below_fixture_maximum": (
            core.THREE_PRIME_PRODUCT < maximum_authority_coefficient
        ),
        "four_prime_product_above_fixture_maximum": (
            core.FOUR_PRIME_PRODUCT > maximum_authority_coefficient
        ),
        "configuration_count_equal": (
            candidate.get("configuration_count")
            == authority["configuration_count"]
            == str(1 << 96)
        ),
        "every_dos_coefficient_equal": not differences,
        "induced_width_1": plan.get("induced_width") == 1,
        "node_checkpoint_count_16": (
            len(candidate.get("checkpoint_roster", [])) == 16
        ),
        "four_node_wave_count_4": (
            len(candidate.get("chain_roster", [])) == 4
        ),
    }
    unsigned = {
        "schema": "SLCV003_N96_FOUR_PRIME_CRT_REGRESSION_V1",
        "campaign_id": cluster.CAMPAIGN_ID,
        "version_label": cluster.VERSION_LABEL,
        "status": "COMPLETED" if all(checks.values()) else "BOUNDARY",
        "fixture_role": (
            "ARITHMETIC_CONTROL_ONLY_NOT_THE_DENSE_FRUSTRATED_N96_BENCHMARK"
        ),
        "instance_id": instance["instance_id"],
        "instance_sha256": instance["instance_sha256"],
        "instance_path": str(instance_path.relative_to(BASE)),
        "authority_path": str(authority_path.relative_to(BASE)),
        "authority_result_sha256": authority["result_sha256"],
        "authority_dos_sha256": authority["dos_sha256"],
        "candidate_path": str(
            (work_dir / DEFAULT_CANDIDATE.name).relative_to(BASE)
        ),
        "candidate_result_sha256": candidate["result_sha256"],
        "candidate_plan_sha256": plan["plan_sha256"],
        "candidate_dos_sha256": candidate["dos_sha256"],
        "selected_primes": plan["primes"],
        "three_prime_product": str(core.THREE_PRIME_PRODUCT),
        "four_prime_product": str(core.FOUR_PRIME_PRODUCT),
        "maximum_authority_coefficient": str(maximum_authority_coefficient),
        "coefficient_domain": [
            min(energies) if energies else None,
            max(energies) if energies else None,
        ],
        "coefficient_position_count": len(energies),
        "coefficient_difference_count": len(differences),
        "coefficient_differences": differences,
        "checks": checks,
        "metrics": candidate["metrics"],
    }
    result = _seal(unsigned)
    _preserve_exact(result_path, result, "N96 four-prime CRT result")
    if result["status"] != "COMPLETED":
        raise cluster.ClusterError(
            "N96 four-prime CRT regression reached a boundary"
        )
    return result


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--work-dir", type=Path, default=DEFAULT_WORK_DIR)
    parser.add_argument("--result", type=Path, default=DEFAULT_RESULT)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    result = run(args.work_dir.resolve(), args.result.resolve())
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
