#!/usr/bin/env python3
"""Typed exact-fiber receipts for SLC Dense Exact v0.3 development."""

from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping, Sequence


PRODUCT_RESOLUTION_FIBER = "W10_W9_EXACT_PRODUCT_RESOLUTION_FIBER"
GLOBAL_SPIN_GAUGE_FIBER = "GLOBAL_SPIN_FLIP_EXACT_GAUGE_FIBER"
FIBER_RECEIPT_SCHEMA = "SLCV003_EXACT_FIBER_RECEIPT_V1"
FIBER_CHAIN_SCHEMA = "SLCV003_EXPLICIT_FIBER_CHAIN_V1"


class ResolutionError(ValueError):
    """Raised when a resolution quotient or exact lift is inconsistent."""


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _sealed(unsigned: Mapping[str, Any]) -> dict[str, Any]:
    return {**unsigned, "receipt_sha256": canonical_sha256(unsigned)}


def make_w10_w9_product_fiber(
    *,
    quotient_n: int,
    record_count: int,
    source_semantic_sha256: str | None = None,
) -> dict[str, Any]:
    """Create the exact W10-to-W9 independent-product lift receipt.

    Every record contributes one uncoupled q_hi coordinate.  Nine records
    therefore carry a base-two exponent of nine and multiplicity 512.
    """

    if type(quotient_n) is not int or quotient_n < 0:
        raise ResolutionError("quotient_n must be a nonnegative integer")
    if type(record_count) is not int or record_count < 1:
        raise ResolutionError("record_count must be a positive integer")
    semantic_n = quotient_n + record_count
    exponent = record_count
    multiplicity = 1 << exponent
    unsigned = {
        "schema": FIBER_RECEIPT_SCHEMA,
        "fiber_id": PRODUCT_RESOLUTION_FIBER,
        "fiber_kind": "EXACT_INDEPENDENT_PRODUCT",
        "source_type": "W10_FULL_STATE",
        "quotient_type": "W9_QUOTIENT_STATE",
        "coordinate_rule": "q=2*q_hi+q_lo; p=q_lo",
        "quotient_N": quotient_n,
        "semantic_N": semantic_n,
        "independent_fiber_coordinate_count": record_count,
        "fiber_base2_exponent": exponent,
        "fiber_multiplicity": multiplicity,
        "quotient_configuration_count": str(1 << quotient_n),
        "semantic_configuration_count": str(1 << semantic_n),
        "state_count_equation": (
            f"2^{quotient_n} * 2^{exponent} = 2^{semantic_n}"
        ),
        "descent_checks": {
            "q_hi_field_zero": True,
            "q_hi_internal_couplings_zero": True,
            "q_hi_seam_couplings_zero": True,
            "q_hi_port_roles_zero": True,
            "q_hi_observable_roles_zero": True,
            "energy_invariant": True,
            "transfer_invariant": True,
            "reduction_receipt_invariant": True,
        },
        "source_semantic_sha256": source_semantic_sha256,
    }
    return _sealed(unsigned)


def make_global_spin_gauge_fiber(
    *,
    semantic_n: int,
    anchor_site: int,
    source_instance_sha256: str,
) -> dict[str, Any]:
    """Create a two-member global-spin orbit receipt."""

    if type(semantic_n) is not int or semantic_n < 2:
        raise ResolutionError("semantic_n must be at least two")
    if type(anchor_site) is not int or not 0 <= anchor_site < semantic_n:
        raise ResolutionError("anchor_site lies outside the semantic roster")
    quotient_n = semantic_n - 1
    unsigned = {
        "schema": FIBER_RECEIPT_SCHEMA,
        "fiber_id": GLOBAL_SPIN_GAUGE_FIBER,
        "fiber_kind": "EXACT_SYMMETRY_ORBIT",
        "source_type": "ZERO_FIELD_INTEGER_ISING",
        "quotient_type": "GLOBAL_SPIN_FIXED_REPRESENTATIVE",
        "quotient_N": quotient_n,
        "semantic_N": semantic_n,
        "independent_fiber_coordinate_count": 1,
        "fiber_base2_exponent": 1,
        "fiber_multiplicity": 2,
        "quotient_configuration_count": str(1 << quotient_n),
        "semantic_configuration_count": str(1 << semantic_n),
        "state_count_equation": (
            f"2^{quotient_n} * 2^1 = 2^{semantic_n}"
        ),
        "anchor_site": anchor_site,
        "fixed_spin": 1,
        "source_instance_sha256": source_instance_sha256,
        "descent_checks": {
            "source_fields_zero": True,
            "global_spin_energy_invariant": True,
            "orbit_size_two": True,
            "constant_energy_shift_zero": True,
        },
    }
    return _sealed(unsigned)


def validate_fiber_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(receipt, Mapping):
        raise ResolutionError("fiber receipt must be a mapping")
    unsigned = dict(receipt)
    observed = unsigned.pop("receipt_sha256", None)
    if observed != canonical_sha256(unsigned):
        raise ResolutionError("fiber receipt self-seal mismatch")
    if receipt.get("schema") != FIBER_RECEIPT_SCHEMA:
        raise ResolutionError("fiber receipt schema mismatch")

    quotient_n = receipt.get("quotient_N")
    semantic_n = receipt.get("semantic_N")
    exponent = receipt.get("fiber_base2_exponent")
    multiplicity = receipt.get("fiber_multiplicity")
    values = (quotient_n, semantic_n, exponent, multiplicity)
    if any(type(value) is not int for value in values):
        raise ResolutionError("fiber dimensions and multiplicity must be integers")
    if quotient_n < 0 or semantic_n <= quotient_n or exponent < 1:
        raise ResolutionError("fiber dimensions are inconsistent")
    if semantic_n - quotient_n != exponent:
        raise ResolutionError("fiber exponent does not equal the dimension drop")
    if multiplicity != 1 << exponent:
        raise ResolutionError("fiber multiplicity does not equal 2^exponent")
    if receipt.get("quotient_configuration_count") != str(1 << quotient_n):
        raise ResolutionError("quotient configuration count mismatch")
    if receipt.get("semantic_configuration_count") != str(1 << semantic_n):
        raise ResolutionError("semantic configuration count mismatch")
    checks = receipt.get("descent_checks")
    if not isinstance(checks, Mapping) or not checks or not all(
        value is True for value in checks.values()
    ):
        raise ResolutionError("one or more exact descent checks are absent")
    return {
        "status": "PASS",
        "fiber_id": receipt["fiber_id"],
        "quotient_N": quotient_n,
        "semantic_N": semantic_n,
        "fiber_multiplicity": multiplicity,
        "receipt_sha256": observed,
    }


def lift_dos_rows(
    quotient_rows: Sequence[Mapping[str, Any]],
    receipt: Mapping[str, Any],
) -> list[dict[str, Any]]:
    """Lift an exact quotient DOS by the receipt's constant multiplicity."""

    validation = validate_fiber_receipt(receipt)
    quotient_n = int(validation["quotient_N"])
    semantic_n = int(validation["semantic_N"])
    multiplicity = int(validation["fiber_multiplicity"])
    rows: list[dict[str, Any]] = []
    seen: set[int] = set()
    for index, row in enumerate(quotient_rows):
        if not isinstance(row, Mapping):
            raise ResolutionError(f"DOS row {index} is not a mapping")
        energy = row.get("energy")
        raw_count = row.get("count")
        if type(energy) is not int:
            raise ResolutionError(f"DOS row {index} energy is not an integer")
        try:
            count = int(raw_count)
        except (TypeError, ValueError) as exc:
            raise ResolutionError(
                f"DOS row {index} count is not an integer"
            ) from exc
        if count < 0 or energy in seen:
            raise ResolutionError("DOS rows contain a negative count or duplicate energy")
        seen.add(energy)
        rows.append({"energy": energy, "count": str(count * multiplicity)})
    if sum(int(row["count"]) for row in quotient_rows) != 1 << quotient_n:
        raise ResolutionError("quotient DOS state count mismatch")
    if sum(int(row["count"]) for row in rows) != 1 << semantic_n:
        raise ResolutionError("lifted DOS state count mismatch")
    return rows


def compose_fiber_receipts(
    receipts: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Compose fibers only through an explicit, dimension-matched request."""

    if not receipts:
        raise ResolutionError("an explicit fiber chain cannot be empty")
    validations = [validate_fiber_receipt(receipt) for receipt in receipts]
    for left, right in zip(validations, validations[1:]):
        if int(left["semantic_N"]) != int(right["quotient_N"]):
            raise ResolutionError("fiber chain dimensions do not meet")
    exponent = sum(
        int(receipt["fiber_base2_exponent"]) for receipt in receipts
    )
    unsigned = {
        "schema": FIBER_CHAIN_SCHEMA,
        "composition_mode": "EXPLICIT_ONLY",
        "fiber_ids": [str(receipt["fiber_id"]) for receipt in receipts],
        "receipt_sha256s": [
            str(receipt["receipt_sha256"]) for receipt in receipts
        ],
        "quotient_N": int(receipts[0]["quotient_N"]),
        "semantic_N": int(receipts[-1]["semantic_N"]),
        "fiber_base2_exponent": exponent,
        "fiber_multiplicity": 1 << exponent,
    }
    return {
        **unsigned,
        "chain_sha256": canonical_sha256(unsigned),
    }


def validate_fiber_chain(
    chain: Mapping[str, Any],
    receipts: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Validate an explicitly supplied chain against its ordered receipts."""

    if not isinstance(chain, Mapping):
        raise ResolutionError("fiber chain must be a mapping")
    expected = compose_fiber_receipts(receipts)
    if canonical_sha256(chain) != canonical_sha256(expected):
        raise ResolutionError("fiber chain differs from its ordered receipts")
    return {
        "status": "PASS",
        "quotient_N": int(expected["quotient_N"]),
        "semantic_N": int(expected["semantic_N"]),
        "fiber_multiplicity": int(expected["fiber_multiplicity"]),
        "chain_sha256": str(expected["chain_sha256"]),
    }


def lift_dos_rows_through_chain(
    quotient_rows: Sequence[Mapping[str, Any]],
    receipts: Sequence[Mapping[str, Any]],
    *,
    chain: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Apply one fiber or an explicitly sealed ordered fiber chain."""

    if not receipts:
        raise ResolutionError("at least one fiber receipt is required")
    if len(receipts) > 1:
        if chain is None:
            raise ResolutionError(
                "multiple fibers require an explicit dimension-matched chain"
            )
        validate_fiber_chain(chain, receipts)
    elif chain is not None:
        validate_fiber_chain(chain, receipts)
    rows = [dict(row) for row in quotient_rows]
    for receipt in receipts:
        rows = lift_dos_rows(rows, receipt)
    return rows


__all__ = [
    "FIBER_CHAIN_SCHEMA",
    "FIBER_RECEIPT_SCHEMA",
    "GLOBAL_SPIN_GAUGE_FIBER",
    "PRODUCT_RESOLUTION_FIBER",
    "ResolutionError",
    "canonical_sha256",
    "compose_fiber_receipts",
    "lift_dos_rows",
    "lift_dos_rows_through_chain",
    "make_global_spin_gauge_fiber",
    "make_w10_w9_product_fiber",
    "validate_fiber_chain",
    "validate_fiber_receipt",
]
