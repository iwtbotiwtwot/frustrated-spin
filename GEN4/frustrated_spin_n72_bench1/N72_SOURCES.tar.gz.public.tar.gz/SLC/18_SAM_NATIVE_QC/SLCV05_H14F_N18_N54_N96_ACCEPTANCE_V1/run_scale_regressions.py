#!/usr/bin/env python3
"""Fresh exact N18/N54 regression plus typed-T18 compatibility readback."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import time
from typing import Any, Mapping


HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parents[2]
CAMPAIGN_ID = "SLCV05_H14F_N18_N54_N96_ACCEPTANCE_V1"
STARTER = (
    REPO_ROOT
    / "SLC/SAM_LANGUAGE/SAM_LANGUAGE_CONTACT_NATIVE_SUCCESSOR_DESIGN"
    / "STARBREAKER_SLC_STARTER_V1"
)
STARTER_RUNNER = STARTER / "run_starbreaker_slc_starter.py"
STARTER_RESULT = STARTER / "STARBREAKER_SLC_STARTER_RESULT.json"
V05_IR = (
    REPO_ROOT
    / "SLC/18_SAM_NATIVE_QC/SLCV05_N72_H14C_T18_CANDIDATE/slcv05_ir.py"
)
CONTRACT = HERE / "ACCEPTANCE_CONTRACT.json"
RELEASE = HERE / "release"
RESULT = RELEASE / "N18_N54_SCALE_REGRESSION_RESULT.json"
RESULT_MD = RELEASE / "N18_N54_SCALE_REGRESSION_RESULT.md"


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_bytes(canonical_bytes(value) + b"\n")
    os.replace(temporary, path)


def mem_available() -> int:
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) * 1024
    raise RuntimeError("MemAvailable is absent")


def render(result: Mapping[str, Any]) -> str:
    return "\n".join(
        [
            "# SLC v0.5 H14F N18/N54 scale regression",
            "",
            f"**Status:** `{result['execution_status']}`  ",
            f"**Classification:** {result['result_classification']}",
            "",
            f"- Fresh nonempty N18 executions: **{result['n18']['executed_nonempty_graphs']}**",
            f"- Exact N18 graph identities: **{result['n18']['graph_count']} / {result['n18']['graph_count']}**",
            f"- Exact N54 reconstructions: **{result['n54']['factorized_ledger_count']} / {result['n54']['factorized_ledger_count']}**",
            f"- Fresh direct N54 wall: **{result['n54']['direct_wall_seconds']:.6f} s**",
            f"- Direct N54 DOS SHA-256: `{result['n54']['direct_dos_sha256']}`",
            f"- T18 map SHA-256: `{result['t18']['map_sha256']}`",
            f"- Total wall: **{result['metrics']['wall_seconds']:.6f} s**",
            f"- Result SHA-256: `{result['result_sha256']}`",
            "",
        ]
    )


def main() -> int:
    if RESULT.exists() or RESULT_MD.exists():
        raise RuntimeError("scale-regression result already exists")
    for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
        if os.environ.get(key) != "1":
            raise RuntimeError(f"{key} must equal 1")
    wall_started = time.perf_counter()
    minimum_available = mem_available()
    starter = load_module(STARTER_RUNNER, "slcv05_scale_starter")
    ir = load_module(V05_IR, "slcv05_scale_ir")
    authority = json.loads(STARTER_RESULT.read_text())
    if authority["result_semantic_sha256"] != (
        "a0eada31c18b703af4b2df0fa197e8888aec3d2c8697f311ca3157dec1d9227d"
    ):
        raise RuntimeError("Starbreaker N18/N54 authority changed")
    fused, _parent = starter.slc_core.load_engines()
    prefinal = starter.load_prefinal_rows()
    compiled = []
    for scenario in starter.SCENARIOS:
        for ledger_id, rows in prefinal[scenario].items():
            print(
                json.dumps(
                    {"event": "SCALE_COMPILE", "scenario": scenario, "ledger": ledger_id},
                    sort_keys=True,
                ),
                flush=True,
            )
            compiled.append(starter.compile_ledger(rows, fused))
    channel_cache, channel_seconds = starter.execute_channel_graphs(compiled, fused)
    minimum_available = min(minimum_available, mem_available())
    authority_channels = {
        row["graph_sha256"]: row for row in authority["channel_executions"]
    }
    if set(channel_cache) != set(authority_channels):
        raise RuntimeError("N18 graph roster differs from authority")
    if any(
        row["dos_sha256"] != authority_channels[key]["dos_sha256"]
        or row["dos"] != authority_channels[key]["dos"]
        for key, row in channel_cache.items()
    ):
        raise RuntimeError("one or more N18 spectra differ from authority")
    factorized = {}
    for ledger in compiled:
        key = (ledger["scenario_id"], int(ledger["ledger_id"]))
        factorized[key] = starter.reconstruct_n54(ledger, channel_cache, fused)
    authority_ledgers = {
        (row["scenario_id"], int(row["ledger_id"])): row
        for row in authority["compiled_ledger_results"]
    }
    if set(factorized) != set(authority_ledgers):
        raise RuntimeError("N54 ledger roster differs from authority")
    if any(
        row["dos_sha256"] != authority_ledgers[key]["dos_sha256"]
        or row["configuration_count"] != 1 << 54
        for key, row in factorized.items()
    ):
        raise RuntimeError("one or more factorized N54 spectra changed")
    compiled_by_key = {
        (row["scenario_id"], int(row["ledger_id"])): row for row in compiled
    }
    direct_started = time.perf_counter()
    direct = starter.run_direct_control(
        compiled_by_key[("REF_0001", 0)],
        factorized[("REF_0001", 0)],
        fused,
    )
    direct_wall = time.perf_counter() - direct_started
    minimum_available = min(minimum_available, mem_available())
    maps, t18 = ir.build_t18_transition_maps()
    ir_checks = dict(ir.run_ir_self_checks())
    if t18["map_sha256"] != ir.EXPECTED_LEGACY_MAP_SHA256:
        raise RuntimeError("typed T18 map changed")
    checks = {
        "all_37_n18_graphs_equal_authority": len(channel_cache) == 37,
        "all_36_nonempty_n18_graphs_executed": sum(
            row["execution_usage"] == "EXECUTED_SLC_NUMERICAL_KERNEL"
            for row in channel_cache.values()
        ) == 36,
        "all_28_n54_factorizations_equal_authority": len(factorized) == 28,
        "direct_n54_equals_factorized": bool(direct["dos_rows_equal"]),
        "direct_n54_equals_authority": direct["direct_dos_sha256"]
        == authority["direct_n54_control"]["direct_dos_sha256"],
        "all_n54_counts_are_2_pow_54": all(
            row["configuration_count"] == 1 << 54 for row in factorized.values()
        ),
        "t18_map_equals_current_v05": t18["map_sha256"]
        == "5cd4e3001b11e8c1ecb828087aaab94bbace51c1129d5bacbd4218f95e7f9ab3",
        "typed_ir_self_checks_pass": all(ir_checks.values()),
        "memory_reserve_retained": minimum_available >= 8 * (1 << 30),
    }
    if not all(checks.values()):
        raise RuntimeError(
            f"scale regression failed: {[key for key, value in checks.items() if not value]}"
        )
    unsigned = {
        "schema": "SLCV05_H14F_N18_N54_SCALE_REGRESSION_RESULT_V1",
        "campaign_id": CAMPAIGN_ID,
        "execution_status": "COMPLETED",
        "result_classification": "The test result suggests strong contact with the concept.",
        "source_custody": {
            "contract_sha256": sha256_file(CONTRACT),
            "starter_runner_sha256": sha256_file(STARTER_RUNNER),
            "starter_result_file_sha256": sha256_file(STARTER_RESULT),
            "starter_result_semantic_sha256": authority["result_semantic_sha256"],
            "v05_ir_sha256": sha256_file(V05_IR),
        },
        "n18": {
            "graph_count": len(channel_cache),
            "executed_nonempty_graphs": sum(
                row["execution_usage"] == "EXECUTED_SLC_NUMERICAL_KERNEL"
                for row in channel_cache.values()
            ),
            "channel_execution_seconds": channel_seconds,
            "graph_dos_roster_sha256": canonical_sha256(
                [
                    [key, channel_cache[key]["dos_sha256"]]
                    for key in sorted(channel_cache)
                ]
            ),
        },
        "n54": {
            "factorized_ledger_count": len(factorized),
            "factorized_dos_roster_sha256": canonical_sha256(
                [
                    [list(key), factorized[key]["dos_sha256"]]
                    for key in sorted(factorized)
                ]
            ),
            "direct_instance_sha256": direct["instance_sha256"],
            "direct_dos_sha256": direct["direct_dos_sha256"],
            "direct_induced_width": direct["induced_width"],
            "direct_wall_seconds": direct_wall,
            "configuration_count": 1 << 54,
        },
        "t18": {
            "assignment_count": int(t18["assignment_count"]),
            "signed_map_count": int(t18["signed_map_count"]),
            "map_sha256": t18["map_sha256"],
            "map_tensor_sha256": hashlib.sha256(maps.tobytes(order="C")).hexdigest(),
            "ir_checks": ir_checks,
        },
        "metrics": {
            "wall_seconds": time.perf_counter() - wall_started,
            "minimum_available_memory_bytes": minimum_available,
            "maximum_process_rss_bytes": int(
                resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            )
            * 1024,
        },
        "checks": checks,
    }
    result = {**unsigned, "result_sha256": canonical_sha256(unsigned)}
    atomic_json(RESULT, result)
    RESULT_MD.write_text(render(result), encoding="utf-8")
    print(
        json.dumps(
            {
                "event": "N18_N54_SCALE_REGRESSION_COMPLETE",
                "wall_seconds": result["metrics"]["wall_seconds"],
                "result_sha256": result["result_sha256"],
            },
            sort_keys=True,
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
