#!/usr/bin/env python3
"""Resumable four-prime H14F acceptance execution on frozen dense N96."""

from __future__ import annotations

from collections import defaultdict
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import queue
import resource
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from typing import Any, Mapping, Sequence

import numpy as np


HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parents[2]
QC_ROOT = HERE.parent
CAMPAIGN_ID = "SLCV05_H14F_N18_N54_N96_ACCEPTANCE_V1"
CANDIDATE_NAME = "SLCV0.5-96-H14F-T18"
ROOT_COUNT = 1024
CPU_IDS = [0, 2, 4, 6, 8, 10, 12, 13, 14, 15, 16, 17, 18, 19]
CHUNK_CAP = 131072
MINIMUM_AVAILABLE_MEMORY_BYTES = 8 * (1 << 30)
PER_WORKER_ADDRESS_SPACE_BYTES = 6 * (1 << 30)

FROZEN_ROOT = QC_ROOT / "SLCV40_N96_CAPACITY_ADMITTED_H14C_512"
FROZEN_INSTANCE = FROZEN_ROOT / "SLCV40_N96_INSTANCE.json"
FROZEN_PLAN = FROZEN_ROOT / "SLCV40_N96_EXECUTION_PLAN.json"
FROZEN_FIBER = FROZEN_ROOT / "SLCV40_N96_FIBER_FREEZE.json"
FROZEN_RESULT = (
    FROZEN_ROOT / "release/SLCV40_N96_24_H14C_512_C40_RESULT.json"
)
FROZEN_OPERATOR = FROZEN_ROOT / "work/N96_H14C/N96_RETAINED_OPERATOR.json"
FROZEN_FREEZE = (
    FROZEN_ROOT / "release/SLCV0.4-96-H14C-512_FINAL_FREEZE.json"
)
FROZEN_ENGINE_ROOT = FROZEN_ROOT
H14F_ROOT = QC_ROOT / "SLCV05_N72_FINAL_REFINEMENT_V1"
H14F_REVISION = (
    H14F_ROOT / "release/SLCV0.5-72-H14F-T18_CURRENT_REVISION.json"
)
H14F_KERNEL_ROOT = H14F_ROOT
H14F_NATIVE_SOURCE = H14F_ROOT / "refined_native_u32_p1.c"
SCALE_RESULT = HERE / "release/N18_N54_SCALE_REGRESSION_RESULT.json"
CONTRACT = HERE / "ACCEPTANCE_CONTRACT.json"

for module_root in (HERE, FROZEN_ENGINE_ROOT, H14F_KERNEL_ROOT):
    if str(module_root) not in sys.path:
        sys.path.insert(0, str(module_root))

import slcv40_n96_engine as n96_engine  # noqa: E402
from native_arithmetic_u32 import NativeArithmeticU32P1  # noqa: E402
from refined_kernel_u32 import retained_port_root_p1_u32  # noqa: E402
from n96_h14f_kernel import evaluate_n96_root_h14f  # noqa: E402
from projection_cache_v2 import (  # noqa: E402
    build_cache_file,
    canonical_bytes,
    canonical_sha256,
    compile_descriptor,
    open_cache_file,
    sha256_file,
    validate_descriptor,
)


WORK = HERE / "work/N96_H14F"
LANES = WORK / "prime_lanes"
NATIVE = WORK / "native/libslcv05_n96_h14f.so"
NATIVE_RECEIPT = WORK / "NATIVE_BUILD_RECEIPT.json"
PLAN = WORK / "EXECUTION_PLAN.json"
MANIFEST = WORK / "SOURCE_MANIFEST.json"
CACHE_ARTIFACT = WORK / "CACHE_ARTIFACT.json"
SMOKE = WORK / "ROOT_ZERO_SMOKE.json"
OPERATOR = WORK / "N96_RETAINED_OPERATOR.json"
RELEASE = HERE / "release"
RESULT = RELEASE / "SLCV0.5-96-H14F-T18_ACCEPTANCE_RESULT.json"
RESULT_MD = RELEASE / "SLCV0.5-96-H14F-T18_ACCEPTANCE_RESULT.md"


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"expected JSON object at {path}")
    return value


def sealed(unsigned: Mapping[str, Any], key: str) -> dict[str, Any]:
    return {**unsigned, key: canonical_sha256(unsigned)}


def validate_seal(value: Mapping[str, Any], key: str) -> None:
    unsigned = dict(value)
    observed = unsigned.pop(key, None)
    if observed != canonical_sha256(unsigned):
        raise RuntimeError(f"semantic self-seal mismatch: {key}")


def atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_bytes(canonical_bytes(value) + b"\n")
    os.replace(temporary, path)


def write_immutable(path: Path, value: Mapping[str, Any]) -> None:
    expected = canonical_bytes(value) + b"\n"
    if path.exists():
        if path.read_bytes() != expected:
            raise RuntimeError(f"immutable artifact differs: {path}")
        return
    atomic_json(path, value)


def meminfo() -> dict[str, int]:
    values: dict[str, int] = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        key, raw = line.split(":", 1)
        values[key] = int(raw.split()[0]) * 1024
    return values


def maximum_rss_bytes() -> int:
    return int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss) * 1024


def pid_rollup(pid: int) -> dict[str, int]:
    output: dict[str, int] = {}
    try:
        lines = Path(f"/proc/{pid}/smaps_rollup").read_text().splitlines()
    except (FileNotFoundError, PermissionError, ProcessLookupError):
        return output
    for line in lines:
        if ":" not in line:
            continue
        key, raw = line.split(":", 1)
        fields = raw.split()
        if fields and fields[0].isdigit():
            output[key] = int(fields[0]) * 1024
    return output


def authority_residue_path(prime_index: int) -> Path:
    return FROZEN_ROOT / f"work/N96_H14C/prime_residues/prime_{prime_index:02d}.json"


def lane_path(prime_index: int) -> Path:
    return LANES / f"prime_{prime_index:02d}.json"


def validate_authorities() -> tuple[
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
]:
    instance = load_json(FROZEN_INSTANCE)
    frozen_plan = load_json(FROZEN_PLAN)
    fiber = load_json(FROZEN_FIBER)
    frozen_result = load_json(FROZEN_RESULT)
    frozen_operator = load_json(FROZEN_OPERATOR)
    freeze = load_json(FROZEN_FREEZE)
    validate_seal(frozen_plan, "plan_sha256")
    validate_seal(fiber, "fiber_freeze_sha256")
    validate_seal(frozen_result, "result_sha256")
    validate_seal(frozen_operator, "operator_sha256")
    validate_seal(freeze, "final_freeze_sha256")
    if (
        instance["instance_sha256"]
        != "625bcd4327e678fa9541d7ab4109449e432d199aad1fba6e1f254395ebdd203d"
        or frozen_plan["plan_sha256"]
        != "2f04592f64ef354da2879ec8338a402655bf086edb5eefa051adb008b47c6b0b"
        or frozen_result["result_sha256"]
        != "dffa16c212faa9783de07b7a6f0194e9b97a7364961d5f89ee76340aa13a9e09"
        or frozen_operator["operator_sha256"]
        != "f9f5c18d7f73d142225a4b789625e8277934d07118779df52e1a61d1310743d4"
        or freeze.get("status") != "FROZEN_CURRENT_SLC_RELEASE"
    ):
        raise RuntimeError("frozen N96 authority identity changed")
    if frozen_plan["primes"] != list(n96_engine.PRIMES):
        raise RuntimeError("frozen N96 prime roster changed")
    for prime_index in range(4):
        residue = load_json(authority_residue_path(prime_index))
        validate_seal(residue, "record_sha256")
        if residue["prime"] != frozen_plan["primes"][prime_index]:
            raise RuntimeError("frozen residue prime roster changed")
    scale = load_json(SCALE_RESULT)
    validate_seal(scale, "result_sha256")
    if not all(scale["checks"].values()):
        raise RuntimeError("N18/N54 scale regression is not complete")
    revision = load_json(H14F_REVISION)
    validate_seal(revision, "revision_sha256")
    if revision["revision_name"] != "SLCV0.5-72-H14F-T18":
        raise RuntimeError("H14F selection authority changed")
    return (
        instance,
        frozen_plan,
        fiber,
        frozen_result,
        frozen_operator,
        freeze,
        scale,
    )


def build_native() -> dict[str, Any]:
    if NATIVE.exists() or NATIVE_RECEIPT.exists():
        if not (NATIVE.exists() and NATIVE_RECEIPT.exists()):
            raise RuntimeError("partial native build artifact exists")
        receipt = load_json(NATIVE_RECEIPT)
        validate_seal(receipt, "receipt_sha256")
        if (
            receipt["source_sha256"] != sha256_file(H14F_NATIVE_SOURCE)
            or receipt["library_sha256"] != sha256_file(NATIVE)
        ):
            raise RuntimeError("persisted native build identity changed")
        return receipt
    NATIVE.parent.mkdir(parents=True, exist_ok=True)
    command = [
        "gcc",
        "-O3",
        "-march=native",
        "-funroll-loops",
        "-std=c11",
        "-fPIC",
        "-shared",
        str(H14F_NATIVE_SOURCE),
        "-o",
        str(NATIVE),
    ]
    started = time.perf_counter()
    completed = subprocess.run(command, check=True, capture_output=True, text=True)
    receipt = sealed(
        {
            "schema": "SLCV05_N96_H14F_NATIVE_BUILD_V1",
            "campaign_id": CAMPAIGN_ID,
            "command": command,
            "compiler": subprocess.run(
                ["gcc", "--version"], check=True, capture_output=True, text=True
            ).stdout.splitlines()[0],
            "stdout": completed.stdout,
            "stderr": completed.stderr,
            "build_seconds": time.perf_counter() - started,
            "source_sha256": sha256_file(H14F_NATIVE_SOURCE),
            "library_bytes": NATIVE.stat().st_size,
            "library_sha256": sha256_file(NATIVE),
        },
        "receipt_sha256",
    )
    atomic_json(NATIVE_RECEIPT, receipt)
    return receipt


def source_manifest() -> dict[str, Any]:
    sources = [
        HERE / "README.md",
        CONTRACT,
        Path(__file__).resolve(),
        HERE / "projection_cache_v2.py",
        HERE / "n96_h14f_kernel.py",
        HERE / "run_scale_regressions.py",
        H14F_ROOT / "refined_kernel_u32.py",
        H14F_ROOT / "native_arithmetic_u32.py",
        H14F_NATIVE_SOURCE,
        QC_ROOT / "SLCV05_N72_H14E_SHARED_PROJECTION_CACHE_V1/shared_projection_cache.py",
        FROZEN_ROOT / "slcv40_n96_engine.py",
        FROZEN_INSTANCE,
        FROZEN_PLAN,
        FROZEN_FIBER,
        FROZEN_RESULT,
        FROZEN_OPERATOR,
        FROZEN_FREEZE,
        H14F_REVISION,
        SCALE_RESULT,
    ] + [authority_residue_path(index) for index in range(4)]
    rows = []
    for path in sources:
        resolved = path.resolve()
        rows.append(
            {
                "path": str(resolved.relative_to(REPO_ROOT)),
                "bytes": resolved.stat().st_size,
                "sha256": sha256_file(resolved),
            }
        )
    return sealed(
        {
            "schema": "SLCV05_N96_H14F_SOURCE_MANIFEST_V1",
            "campaign_id": CAMPAIGN_ID,
            "sources": rows,
        },
        "manifest_sha256",
    )


def validate_cached_indices(cache: Any) -> dict[str, Any]:
    checked_maps = 0
    checked_entries = 0
    maximum_index = 0
    for step, raw_step in zip(cache.maps, cache.descriptor["steps"]):
        for projection, row in zip(step, raw_step["maps"]):
            observed_maximum = int(projection.max(initial=0))
            one_maximum = observed_maximum | int(row["eliminated_factor_bit"])
            if one_maximum >= 1 << int(row["factor_scope_width"]):
                raise RuntimeError("N96 cache projection escaped factor extent")
            checked_maps += 1
            checked_entries += int(projection.size)
            maximum_index = max(maximum_index, one_maximum)
    return {
        "checked_maps": checked_maps,
        "checked_entries": checked_entries,
        "maximum_selected_index": maximum_index,
        "all_zero_and_one_indices_in_factor_extent": True,
    }


def build_execution_plan(
    frozen_plan: Mapping[str, Any],
    descriptor: Mapping[str, Any],
    cache_build: Mapping[str, Any],
    native: Mapping[str, Any],
    manifest: Mapping[str, Any],
    scale: Mapping[str, Any],
) -> dict[str, Any]:
    unsigned = {
        "schema": "SLCV05_N96_H14F_EXECUTION_PLAN_V1",
        "campaign_id": CAMPAIGN_ID,
        "candidate_name": CANDIDATE_NAME,
        "frozen_release_unchanged": "SLCV0.4-96-H14C-512",
        "source_instance_sha256": frozen_plan["instance_sha256"],
        "source_plan_sha256": frozen_plan["plan_sha256"],
        "source_manifest_sha256": manifest["manifest_sha256"],
        "n18_n54_regression_sha256": scale["result_sha256"],
        "topology_edges_sha256": frozen_plan["topology_edges_sha256"],
        "selected_order_sha256": frozen_plan["selected_order_sha256"],
        "cutset_sites_in_order": frozen_plan["cutset_sites_in_order"],
        "cut_edge_endpoints": frozen_plan["cut_edge_endpoints"],
        "port_order": frozen_plan["port_order"],
        "branch_count": frozen_plan["cutset_branch_count"],
        "retained_port_induced_width": frozen_plan["retained_port_induced_width"],
        "y_ntt_length": ROOT_COUNT,
        "primes": frozen_plan["primes"],
        "crt_modulus_product": frozen_plan["crt_modulus_product"],
        "local_y_bound": frozen_plan["local_y_bound"],
        "energy_bound_B": frozen_plan["energy_bound_B"],
        "worker_count": len(CPU_IDS),
        "requested_cpu_ids": CPU_IDS,
        "root_batch_size": 1,
        "queue_packet_size": 1,
        "chunk_cap": CHUNK_CAP,
        "reduced_storage_bits": 32,
        "multiplication_bits": 64,
        "pool_lifetime": "ONE_POOL_RETAINED_ACROSS_ALL_FOUR_CRT_PRIMES",
        "minimum_available_memory_bytes": MINIMUM_AVAILABLE_MEMORY_BYTES,
        "per_worker_address_space_cap_bytes": PER_WORKER_ADDRESS_SPACE_BYTES,
        "cache_descriptor_sha256": descriptor["descriptor_sha256"],
        "cache_bytes": cache_build["cache_bytes"],
        "cache_sha256": cache_build["cache_sha256"],
        "cache_entry_count": descriptor["entry_count"],
        "native_library_sha256": native["library_sha256"],
        "t18_map_sha256": scale["t18"]["map_sha256"],
        "fresh_singleton_task_count": 4 * ROOT_COUNT,
        "runtime_is_observation": True,
        "release_promoted": False,
    }
    return sealed(unsigned, "plan_sha256")


def worker_loop(
    node_id: str,
    cpu_id: int,
    instance: Mapping[str, Any],
    frozen_plan: Mapping[str, Any],
    task_queue: Any,
    result_queue: Any,
    cache_path: str,
    descriptor: Mapping[str, Any],
    native_path: str,
) -> None:
    cache = None
    try:
        resource.setrlimit(
            resource.RLIMIT_AS,
            (PER_WORKER_ADDRESS_SPACE_BYTES, PER_WORKER_ADDRESS_SPACE_BYTES),
        )
        os.sched_setaffinity(0, {cpu_id})
        templates, branch_report = n96_engine.build_branch_templates(
            instance, frozen_plan
        )
        cache = open_cache_file(Path(cache_path), descriptor)
        native = NativeArithmeticU32P1(Path(native_path))
        native.self_test([int(value) for value in frozen_plan["primes"]])
        result_queue.put(
            {
                "kind": "READY",
                "node_id": node_id,
                "pid": os.getpid(),
                "requested_cpu_id": cpu_id,
                "observed_affinity": sorted(os.sched_getaffinity(0)),
                "branch_report_sha256": canonical_sha256(branch_report),
                "maximum_rss_bytes": maximum_rss_bytes(),
            }
        )
        while True:
            task = task_queue.get()
            if task is None:
                break
            root = int(task["root"])
            prime = int(task["prime"])
            points = n96_engine.zeta_points(prime, ROOT_COUNT, root, root + 1)
            started_wall = time.perf_counter()
            started_cpu = time.process_time()
            terminal, structural = evaluate_n96_root_h14f(
                n96_engine,
                templates,
                points,
                prime,
                cache,
                native,
                retained_port_root_p1_u32,
                CHUNK_CAP,
            )
            result_queue.put(
                {
                    "kind": "DONE",
                    "node_id": node_id,
                    "root": root,
                    "evaluations": [int(row[0]) for row in terminal],
                    "evaluation_sha256": canonical_sha256(terminal.tolist()),
                    "structural_metrics": {
                        key: int(value) for key, value in structural.items()
                    },
                    "wall_seconds": time.perf_counter() - started_wall,
                    "process_cpu_seconds": time.process_time() - started_cpu,
                    "maximum_rss_bytes": maximum_rss_bytes(),
                }
            )
    except BaseException as error:
        result_queue.put(
            {
                "kind": "ERROR",
                "node_id": node_id,
                "error": f"{type(error).__name__}: {error}",
                "traceback": traceback.format_exc(),
            }
        )
    finally:
        if cache is not None:
            cache.close()


class PersistentPool:
    def __init__(
        self,
        instance: Mapping[str, Any],
        frozen_plan: Mapping[str, Any],
        cache_path: Path,
        descriptor: Mapping[str, Any],
    ) -> None:
        if meminfo()["MemAvailable"] < MINIMUM_AVAILABLE_MEMORY_BYTES:
            raise RuntimeError("8 GiB reserve is unavailable before N96 pool")
        context = mp.get_context("spawn")
        self.task_queue = context.Queue()
        self.result_queue = context.Queue()
        self.node_ids = [f"N{index:02d}" for index in range(len(CPU_IDS))]
        self.processes = {
            node_id: context.Process(
                target=worker_loop,
                args=(
                    node_id,
                    cpu_id,
                    instance,
                    frozen_plan,
                    self.task_queue,
                    self.result_queue,
                    str(cache_path),
                    descriptor,
                    str(NATIVE),
                ),
                name=f"SLCV05-N96-H14F-{node_id}",
            )
            for node_id, cpu_id in zip(self.node_ids, CPU_IDS)
        }
        started = time.perf_counter()
        for process in self.processes.values():
            process.start()
        self.readiness: dict[str, dict[str, Any]] = {}
        self.pids: dict[str, int] = {}
        self.minimum_available = meminfo()["MemAvailable"]
        self.peak_rss = 0
        self.peak_pss = 0
        while len(self.readiness) < len(self.node_ids):
            message = self.result_queue.get(timeout=180)
            if message.get("kind") == "ERROR":
                raise RuntimeError(
                    f"{message.get('node_id')}: {message.get('error')}\n"
                    f"{message.get('traceback')}"
                )
            if message.get("kind") != "READY":
                raise RuntimeError("unexpected N96 pool startup message")
            node_id = str(message["node_id"])
            expected_cpu = CPU_IDS[self.node_ids.index(node_id)]
            if message["observed_affinity"] != [expected_cpu]:
                raise RuntimeError("N96 worker affinity changed")
            self.readiness[node_id] = dict(message)
            self.pids[node_id] = int(message["pid"])
        if len({row["branch_report_sha256"] for row in self.readiness.values()}) != 1:
            raise RuntimeError("N96 worker branch reports differ")
        self.startup_seconds = time.perf_counter() - started
        self.sample_memory()

    def sample_memory(self) -> None:
        rollups = [pid_rollup(pid) for pid in self.pids.values()]
        self.peak_rss = max(self.peak_rss, sum(row.get("Rss", 0) for row in rollups))
        self.peak_pss = max(self.peak_pss, sum(row.get("Pss", 0) for row in rollups))
        self.minimum_available = min(
            self.minimum_available, meminfo()["MemAvailable"]
        )
        if self.minimum_available < MINIMUM_AVAILABLE_MEMORY_BYTES:
            raise RuntimeError("N96 H14F crossed the 8 GiB reserve")

    def close(self) -> None:
        for _ in self.node_ids:
            try:
                self.task_queue.put(None)
            except BaseException:
                pass
        for process in self.processes.values():
            process.join(timeout=15)
            if process.is_alive():
                process.terminate()
                process.join(timeout=5)

    def run_prime(
        self,
        prime_index: int,
        prime: int,
        authority: Mapping[str, Any],
        plan: Mapping[str, Any],
    ) -> tuple[dict[str, Any], bool]:
        path = lane_path(prime_index)
        if path.exists():
            lane = load_json(path)
            validate_seal(lane, "lane_sha256")
            if (
                lane["prime"] != prime
                or lane["plan_sha256"] != plan["plan_sha256"]
                or lane["coefficient_residues"] != authority["coefficient_residues"]
            ):
                raise RuntimeError("persisted N96 H14F lane differs")
            return lane, True
        for root in range(ROOT_COUNT):
            self.task_queue.put({"prime_index": prime_index, "prime": prime, "root": root})
        started = time.perf_counter()
        records: dict[int, dict[str, Any]] = {}
        last_sample = 0.0
        while len(records) < ROOT_COUNT:
            try:
                message = self.result_queue.get(timeout=0.25)
            except queue.Empty:
                message = None
            now = time.monotonic()
            if now - last_sample >= 0.75:
                self.sample_memory()
                last_sample = now
            if message is None:
                if any(not process.is_alive() for process in self.processes.values()):
                    raise RuntimeError("N96 H14F worker exited during prime")
                continue
            if message.get("kind") == "ERROR":
                raise RuntimeError(
                    f"{message.get('node_id')}: {message.get('error')}\n"
                    f"{message.get('traceback')}"
                )
            if message.get("kind") != "DONE":
                raise RuntimeError("unexpected N96 H14F task message")
            root = int(message["root"])
            if root in records:
                raise RuntimeError("duplicate N96 singleton root")
            records[root] = dict(message)
            if len(records) % 128 == 0:
                print(
                    json.dumps(
                        {
                            "event": "N96_PRIME_PROGRESS",
                            "prime": f"{prime_index + 1}/4",
                            "completed_roots": len(records),
                            "elapsed_seconds": time.perf_counter() - started,
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
        kernel_wall = time.perf_counter() - started
        self.sample_memory()
        evaluations = [
            [int(records[root]["evaluations"][state]) for root in range(ROOT_COUNT)]
            for state in range(16)
        ]
        inverse_started = time.perf_counter()
        coefficients = [n96_engine.inverse_ntt(row, prime) for row in evaluations]
        inverse_seconds = time.perf_counter() - inverse_started
        if coefficients != authority["coefficient_residues"]:
            raise RuntimeError("N96 H14F coefficient residues differ from frozen authority")
        structural = records[0]["structural_metrics"]
        if any(records[root]["structural_metrics"] != structural for root in range(1, ROOT_COUNT)):
            raise RuntimeError("N96 H14F structural metrics changed within prime")
        task_count_by_node: defaultdict[str, int] = defaultdict(int)
        task_wall_by_node: defaultdict[str, float] = defaultdict(float)
        task_cpu_by_node: defaultdict[str, float] = defaultdict(float)
        task_roster = []
        for root in range(ROOT_COUNT):
            row = records[root]
            node_id = str(row["node_id"])
            task_count_by_node[node_id] += 1
            task_wall_by_node[node_id] += float(row["wall_seconds"])
            task_cpu_by_node[node_id] += float(row["process_cpu_seconds"])
            task_roster.append(
                {
                    "root": root,
                    "node_id": node_id,
                    "wall_seconds": row["wall_seconds"],
                    "process_cpu_seconds": row["process_cpu_seconds"],
                    "evaluation_sha256": row["evaluation_sha256"],
                }
            )
        lane = sealed(
            {
                "schema": "SLCV05_N96_H14F_PRIME_LANE_V1",
                "campaign_id": CAMPAIGN_ID,
                "plan_sha256": plan["plan_sha256"],
                "prime_index": prime_index,
                "prime": prime,
                "root_count": ROOT_COUNT,
                "fresh_singleton_task_count": ROOT_COUNT,
                "evaluations": evaluations,
                "evaluation_sha256": canonical_sha256(evaluations),
                "coefficient_residues": coefficients,
                "coefficient_residue_sha256": canonical_sha256(coefficients),
                "frozen_coefficient_residue_sha256": authority[
                    "coefficient_residue_sha256"
                ],
                "coefficient_residues_equal_frozen": True,
                "structural_metrics": structural,
                "kernel_wall_seconds": kernel_wall,
                "inverse_ntt_seconds": inverse_seconds,
                "task_count_by_node": dict(sorted(task_count_by_node.items())),
                "task_wall_seconds_by_node": dict(sorted(task_wall_by_node.items())),
                "task_cpu_seconds_by_node": dict(sorted(task_cpu_by_node.items())),
                "sum_task_cpu_seconds": sum(task_cpu_by_node.values()),
                "task_roster": task_roster,
                "all_workers_active": set(task_count_by_node) == set(self.node_ids),
                "minimum_available_memory_bytes": self.minimum_available,
                "peak_aggregate_worker_rss_bytes": self.peak_rss,
                "peak_aggregate_worker_pss_bytes": self.peak_pss,
                "system_reserve_maintained": self.minimum_available
                >= MINIMUM_AVAILABLE_MEMORY_BYTES,
            },
            "lane_sha256",
        )
        write_immutable(path, lane)
        return lane, False


def root_zero_smoke(
    instance: Mapping[str, Any],
    frozen_plan: Mapping[str, Any],
    cache_path: Path,
    descriptor: Mapping[str, Any],
    plan: Mapping[str, Any],
) -> dict[str, Any]:
    if SMOKE.exists():
        receipt = load_json(SMOKE)
        validate_seal(receipt, "smoke_sha256")
        if receipt["plan_sha256"] != plan["plan_sha256"]:
            raise RuntimeError("persisted N96 smoke plan changed")
        return receipt
    templates, _report = n96_engine.build_branch_templates(instance, frozen_plan)
    cache = open_cache_file(cache_path, descriptor)
    try:
        native = NativeArithmeticU32P1(NATIVE)
        native.self_test([int(value) for value in frozen_plan["primes"]])
        points = n96_engine.zeta_points(int(frozen_plan["primes"][0]), ROOT_COUNT, 0, 1)
        started = time.perf_counter()
        terminal, structural = evaluate_n96_root_h14f(
            n96_engine,
            templates,
            points,
            int(frozen_plan["primes"][0]),
            cache,
            native,
            retained_port_root_p1_u32,
            CHUNK_CAP,
        )
        wall = time.perf_counter() - started
    finally:
        cache.close()
    old_checkpoint = load_json(
        FROZEN_ROOT
        / "work/N96_H14C/checkpoints/SLC_00/prime_00_task_0000_roots_0000_0004.json"
    )
    expected = [int(row[0]) for row in old_checkpoint["evaluations"]]
    observed = [int(row[0]) for row in terminal]
    if observed != expected:
        raise RuntimeError("N96 H14F root-zero smoke differs from frozen checkpoint")
    receipt = sealed(
        {
            "schema": "SLCV05_N96_H14F_ROOT_ZERO_SMOKE_V1",
            "campaign_id": CAMPAIGN_ID,
            "plan_sha256": plan["plan_sha256"],
            "prime": int(frozen_plan["primes"][0]),
            "root": 0,
            "evaluations": observed,
            "evaluation_sha256": canonical_sha256(observed),
            "frozen_checkpoint_record_sha256": old_checkpoint["record_sha256"],
            "exact_equality": True,
            "wall_seconds": wall,
            "structural_metrics": structural,
        },
        "smoke_sha256",
    )
    atomic_json(SMOKE, receipt)
    return receipt


def reconstruct(
    instance: Mapping[str, Any],
    frozen_plan: Mapping[str, Any],
    fiber: Mapping[str, Any],
    frozen_result: Mapping[str, Any],
    frozen_operator: Mapping[str, Any],
    lanes: Sequence[Mapping[str, Any]],
    plan: Mapping[str, Any],
    scale: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, bool]]:
    primes = [int(value) for value in frozen_plan["primes"]]
    local_bound = int(frozen_plan["local_y_bound"])
    total_bound = int(frozen_plan["energy_bound_B"])
    expected_row_sum = 1 << 92
    w_coefficients = []
    for state in range(16):
        row = [
            n96_engine.crt(
                [
                    int(lanes[index]["coefficient_residues"][state][degree])
                    for index in range(4)
                ],
                primes,
            )
            for degree in range(ROOT_COUNT)
        ]
        if any(row[local_bound + 1 :]):
            raise RuntimeError("N96 H14F operator support escaped local bound")
        active = row[: local_bound + 1]
        if any(value < 0 for value in active) or sum(active) != expected_row_sum:
            raise RuntimeError("N96 H14F operator row invariant changed")
        w_coefficients.append(active)
    cut_edges = n96_engine.cut_edges_with_weights(instance, frozen_plan["cut_edge_endpoints"])
    glue = n96_engine.glue_y_degrees(cut_edges, frozen_plan["port_order"])
    closure = n96_engine.close_one_cell(
        w_coefficients,
        glue,
        local_bound=local_bound,
        total_bound=total_bound,
    )
    verification = n96_engine.exact_dos_verification(instance, closure["fixed_coefficients"])
    v31_root = QC_ROOT / "SLCV0031_DENSE_EXACT_FULL_Q_STAGE4_N72"
    fiber_root = QC_ROOT / "SLCV004C16N72_LINKED_ACTIVE_512_FIBER"
    for path in (v31_root, fiber_root):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    import slcv0031_w10 as w10  # noqa: PLC0415
    import slcv004_fiber_probe as fiber_engine  # noqa: PLC0415
    open_port, routing = fiber_engine.build_open_port_attachment(w10)
    closed = n96_engine.build_closed_fiber_attachment(
        w_coefficients,
        glue,
        routing,
        closure["fixed_coefficients"],
        local_bound=local_bound,
        total_bound=total_bound,
    )
    operator_unsigned = {
        "schema": "SLCV05_N96_H14F_RETAINED_OPERATOR_V1",
        "campaign_id": CAMPAIGN_ID,
        "plan_sha256": plan["plan_sha256"],
        "source_instance_sha256": instance["instance_sha256"],
        "cutset_sites_in_order": frozen_plan["cutset_sites_in_order"],
        "branch_count": frozen_plan["cutset_branch_count"],
        "port_order": frozen_plan["port_order"],
        "cut_edges": cut_edges,
        "w_coefficients": w_coefficients,
        "w_sha256": canonical_sha256(w_coefficients),
        "local_y_bound": local_bound,
        "expected_row_sum": str(expected_row_sum),
        "row_sums": [str(sum(row)) for row in w_coefficients],
        "glue_y_degrees": glue,
        "glue_y_degrees_sha256": canonical_sha256(glue),
        "prime_lane_sha256": [lane["lane_sha256"] for lane in lanes],
        "coefficient_residue_sha256": [
            lane["coefficient_residue_sha256"] for lane in lanes
        ],
    }
    operator = sealed(operator_unsigned, "operator_sha256")
    write_immutable(OPERATOR, operator)
    checks = {
        "all_four_prime_residues_equal_frozen": all(
            lane["coefficient_residues_equal_frozen"] for lane in lanes
        ),
        "all_4096_singleton_tasks_fresh": sum(
            int(lane["fresh_singleton_task_count"]) for lane in lanes
        ) == 4096,
        "all_workers_active": all(lane["all_workers_active"] for lane in lanes),
        "all_memory_reserves_retained": all(
            lane["system_reserve_maintained"] for lane in lanes
        ),
        "operator_equals_frozen": w_coefficients == frozen_operator["w_coefficients"],
        "operator_hash_equals_frozen": operator["w_sha256"] == frozen_operator["w_sha256"],
        "glue_equals_frozen": glue == frozen_operator["glue_y_degrees"],
        "scalar_dos_equals_frozen": closure["dos_rows"] == frozen_result["dos"]["rows"],
        "scalar_fixed_hash_equals_frozen": closure["fixed_coefficient_sha256"]
        == frozen_result["dos"]["fixed_coefficient_sha256"],
        "configuration_count_is_2_pow_96": closure["configuration_count"] == 1 << 96,
        "exact_dos_verification_passed": verification.get("status") == "PASS"
        and all(verification["checks"].values()),
        "open_q_routing_equals_frozen": open_port["routing_sha256"]
        == fiber["open_port_attachment"]["routing_sha256"],
        "closed_q_attachment_equals_frozen": closed["joint_tensor_sha256"]
        == frozen_result["fiber"]["closed_attachment"]["joint_tensor_sha256"],
        "t18_map_retained": scale["t18"]["map_sha256"]
        == "5cd4e3001b11e8c1ecb828087aaab94bbace51c1129d5bacbd4218f95e7f9ab3",
    }
    return operator, {
        "closure": closure,
        "verification": verification,
        "open_port": open_port,
        "closed_attachment": closed,
    }, checks


def render(result: Mapping[str, Any]) -> str:
    walls = [row["kernel_wall_seconds"] for row in result["prime_lanes"]]
    return "\n".join(
        [
            f"# {CANDIDATE_NAME} acceptance result",
            "",
            f"**Status:** `{result['execution_status']}`  ",
            f"**Classification:** {result['result_classification']}",
            "",
            f"- Fresh singleton-root tasks: **{result['metrics']['executed_task_count']}**",
            f"- Prime kernel walls: **{walls}**",
            f"- Dense wall: **{result['metrics']['dense_wall_seconds']:.6f} s**",
            f"- Frozen H14C wall: **{result['comparison']['frozen_h14c_wall_seconds']:.6f} s**",
            f"- Observed speed ratio: **{result['comparison']['h14c_over_h14f_ratio']:.6f}x**",
            f"- N96 operator SHA-256: `{result['operator']['w_sha256']}`",
            f"- N96 fixed-coefficient SHA-256: `{result['dos']['fixed_coefficient_sha256']}`",
            f"- Configuration count: **{result['dos']['configuration_count']}**",
            f"- Minimum available memory: **{result['metrics']['minimum_available_memory_bytes']} bytes**",
            f"- Result SHA-256: `{result['result_sha256']}`",
            "",
            "This is an executed N96 acceptance candidate. Current-revision installation and release promotion remain open.",
            "",
        ]
    )


def main() -> int:
    for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
        if os.environ.get(key) != "1":
            raise RuntimeError(f"{key} must equal 1")
    if RESULT.exists() or RESULT_MD.exists():
        raise RuntimeError("N96 acceptance result already exists")
    total_started = time.perf_counter()
    (
        instance,
        frozen_plan,
        fiber,
        frozen_result,
        frozen_operator,
        frozen_freeze,
        scale,
    ) = validate_authorities()
    frozen_freeze_file_sha256 = sha256_file(FROZEN_FREEZE)
    templates, branch_report = n96_engine.build_branch_templates(instance, frozen_plan)
    reference = templates[0]
    descriptor = compile_descriptor(
        n96_engine.retained_engine,
        reference.local_instance,
        reference.elimination_order,
        reference.port_order,
    )
    validate_descriptor(descriptor)
    if descriptor["source_instance_n"] != 91 or len(descriptor["steps"]) != 87:
        raise RuntimeError("N96 scale-specific cache dimensions changed")
    WORK.mkdir(parents=True, exist_ok=True)
    LANES.mkdir(parents=True, exist_ok=True)
    RELEASE.mkdir(parents=True, exist_ok=True)
    native = build_native()
    manifest = source_manifest()
    if MANIFEST.exists():
        prior_manifest = load_json(MANIFEST)
        if prior_manifest != manifest:
            raise RuntimeError("persisted source manifest differs")
    else:
        atomic_json(MANIFEST, manifest)
    temporary_root = Path(tempfile.mkdtemp(prefix="slcv05_n96_h14f_cache_", dir="/tmp"))
    cache_path = temporary_root / "projection_cache.bin"
    pool: PersistentPool | None = None
    cache_removed = False
    try:
        cache_build = build_cache_file(cache_path, descriptor)
        if cache_build["cache_sha256"] != sha256_file(cache_path):
            raise RuntimeError("N96 cache file hash changed")
        os.chmod(cache_path, 0o444)
        cache = open_cache_file(cache_path, descriptor)
        try:
            index_validation = validate_cached_indices(cache)
        finally:
            cache.close()
        plan = build_execution_plan(
            frozen_plan, descriptor, cache_build, native, manifest, scale
        )
        if PLAN.exists():
            prior_plan = load_json(PLAN)
            if prior_plan != plan:
                raise RuntimeError("persisted N96 H14F plan differs")
        else:
            atomic_json(PLAN, plan)
        cache_artifact = sealed(
            {
                "schema": "SLCV05_N96_H14F_CACHE_ARTIFACT_V1",
                "campaign_id": CAMPAIGN_ID,
                "plan_sha256": plan["plan_sha256"],
                "descriptor": descriptor,
                "cache_sha256": cache_build["cache_sha256"],
                "cache_bytes": cache_build["cache_bytes"],
                "entry_count": descriptor["entry_count"],
                "dtype_entry_counts": descriptor["dtype_entry_counts"],
                "index_validation": index_validation,
                "read_only_mode": "0444",
                "ephemeral_cache_policy": "REBUILD_EXACTLY_AND_REMOVE_AFTER_RUN",
            },
            "artifact_sha256",
        )
        if CACHE_ARTIFACT.exists():
            prior_cache = load_json(CACHE_ARTIFACT)
            if prior_cache != cache_artifact:
                raise RuntimeError("persisted N96 cache artifact differs")
        else:
            atomic_json(CACHE_ARTIFACT, cache_artifact)
        smoke = root_zero_smoke(instance, frozen_plan, cache_path, descriptor, plan)
        print(
            json.dumps(
                {
                    "event": "N96_PREFLIGHT_COMPLETE",
                    "cache_bytes": descriptor["total_bytes"],
                    "cache_entries": descriptor["entry_count"],
                    "branch_count": len(templates),
                    "smoke_wall_seconds": smoke["wall_seconds"],
                    "smoke_exact": smoke["exact_equality"],
                    "memory_available_bytes": meminfo()["MemAvailable"],
                },
                sort_keys=True,
            ),
            flush=True,
        )
        dense_started = time.perf_counter()
        pool = PersistentPool(instance, frozen_plan, cache_path, descriptor)
        lanes = []
        reused_prime_count = 0
        for prime_index, raw_prime in enumerate(frozen_plan["primes"]):
            authority = load_json(authority_residue_path(prime_index))
            lane, reused = pool.run_prime(
                prime_index, int(raw_prime), authority, plan
            )
            lanes.append(lane)
            reused_prime_count += int(reused)
            print(
                json.dumps(
                    {
                        "event": "N96_PRIME_COMPLETE",
                        "prime": f"{prime_index + 1}/4",
                        "kernel_wall_seconds": lane["kernel_wall_seconds"],
                        "coefficient_residue_sha256": lane[
                            "coefficient_residue_sha256"
                        ],
                        "equal_frozen": lane["coefficient_residues_equal_frozen"],
                        "reused_completed_lane": reused,
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
            if prime_index == 0:
                print(
                    json.dumps(
                        {
                            "event": "N96_LIVE_PACE",
                            "first_prime_seconds": lane["kernel_wall_seconds"],
                            "projected_four_prime_kernel_seconds": 4
                            * float(lane["kernel_wall_seconds"]),
                        },
                        sort_keys=True,
                    ),
                    flush=True,
                )
        pool_startup = pool.startup_seconds
        pool.close()
        pool = None
        operator, reconstructed, checks = reconstruct(
            instance,
            frozen_plan,
            fiber,
            frozen_result,
            frozen_operator,
            lanes,
            plan,
            scale,
        )
        dense_wall = time.perf_counter() - dense_started
        minimum_available = min(
            int(lane["minimum_available_memory_bytes"]) for lane in lanes
        )
        checks.update(
            {
                "root_zero_smoke_equal_frozen": smoke["exact_equality"],
                "scale_specific_cache_indices_valid": index_validation[
                    "all_zero_and_one_indices_in_factor_extent"
                ],
                "scale_specific_cache_not_n72_transplant": descriptor["source_instance_n"]
                == 91
                and len(descriptor["steps"]) == 87,
                "minimum_8_gib_reserve_kept": minimum_available
                >= MINIMUM_AVAILABLE_MEMORY_BYTES,
                "n18_n54_regression_retained": all(scale["checks"].values()),
                "frozen_release_unchanged": (
                    sha256_file(FROZEN_FREEZE) == frozen_freeze_file_sha256
                    and load_json(FROZEN_FREEZE) == frozen_freeze
                    and frozen_freeze["status"] == "FROZEN_CURRENT_SLC_RELEASE"
                ),
            }
        )
        if not all(checks.values()):
            raise RuntimeError(
                f"N96 acceptance checks failed: {[key for key, value in checks.items() if not value]}"
            )
        metrics = {
            "dense_wall_seconds": dense_wall,
            "total_runner_wall_seconds": time.perf_counter() - total_started,
            "cache_build_seconds": cache_build["build_seconds"],
            "native_build_seconds": native["build_seconds"],
            "persistent_pool_startup_seconds": pool_startup,
            "sum_prime_kernel_wall_seconds": sum(
                float(lane["kernel_wall_seconds"]) for lane in lanes
            ),
            "sum_inverse_ntt_seconds": sum(
                float(lane["inverse_ntt_seconds"]) for lane in lanes
            ),
            "executed_task_count": 4096,
            "reused_completed_prime_count_this_invocation": reused_prime_count,
            "worker_count": len(CPU_IDS),
            "minimum_available_memory_bytes": minimum_available,
            "peak_aggregate_worker_rss_bytes": max(
                int(lane["peak_aggregate_worker_rss_bytes"]) for lane in lanes
            ),
            "peak_aggregate_worker_pss_bytes": max(
                int(lane["peak_aggregate_worker_pss_bytes"]) for lane in lanes
            ),
        }
        frozen_wall = float(frozen_result["metrics"]["campaign_elapsed_seconds"])
        comparison = {
            "frozen_h14c_wall_seconds": frozen_wall,
            "h14f_dense_wall_seconds": dense_wall,
            "wall_seconds_saved": frozen_wall - dense_wall,
            "wall_reduction_percent": 100.0 * (frozen_wall - dense_wall) / frozen_wall,
            "h14c_over_h14f_ratio": frozen_wall / dense_wall,
            "runtime_is_observation": True,
        }
        closure = reconstructed["closure"]
        result = sealed(
            {
                "schema": "SLCV05_N96_H14F_ACCEPTANCE_RESULT_V1",
                "campaign_id": CAMPAIGN_ID,
                "candidate_name": CANDIDATE_NAME,
                "execution_status": "COMPLETED",
                "result_classification": "The test result suggests strong contact with the concept.",
                "release_promoted": False,
                "current_revision_installed": False,
                "frozen_release_unchanged": "SLCV0.4-96-H14C-512",
                "source_instance_sha256": instance["instance_sha256"],
                "plan_path": str(PLAN.relative_to(REPO_ROOT)),
                "plan_sha256": plan["plan_sha256"],
                "source_manifest_sha256": manifest["manifest_sha256"],
                "cache": {
                    "artifact_path": str(CACHE_ARTIFACT.relative_to(REPO_ROOT)),
                    "artifact_sha256": cache_artifact["artifact_sha256"],
                    "descriptor_sha256": descriptor["descriptor_sha256"],
                    "cache_sha256": cache_build["cache_sha256"],
                    "cache_bytes": cache_build["cache_bytes"],
                    "entry_count": descriptor["entry_count"],
                    "ephemeral_cache_removed": False,
                },
                "native": native,
                "root_zero_smoke": smoke,
                "prime_lanes": [
                    {
                        "prime_index": lane["prime_index"],
                        "prime": lane["prime"],
                        "path": str(lane_path(index).relative_to(REPO_ROOT)),
                        "lane_sha256": lane["lane_sha256"],
                        "evaluation_sha256": lane["evaluation_sha256"],
                        "coefficient_residue_sha256": lane[
                            "coefficient_residue_sha256"
                        ],
                        "kernel_wall_seconds": lane["kernel_wall_seconds"],
                        "inverse_ntt_seconds": lane["inverse_ntt_seconds"],
                        "minimum_available_memory_bytes": lane[
                            "minimum_available_memory_bytes"
                        ],
                        "all_workers_active": lane["all_workers_active"],
                    }
                    for index, lane in enumerate(lanes)
                ],
                "operator": {
                    "path": str(OPERATOR.relative_to(REPO_ROOT)),
                    "operator_sha256": operator["operator_sha256"],
                    "w_sha256": operator["w_sha256"],
                    "glue_y_degrees_sha256": operator[
                        "glue_y_degrees_sha256"
                    ],
                    "row_sum": str(1 << 92),
                },
                "dos": {
                    "configuration_count": str(closure["configuration_count"]),
                    "fixed_coefficient_sha256": closure[
                        "fixed_coefficient_sha256"
                    ],
                    "dos_sha256": closure["dos_sha256"],
                    "occupied_energy_bins": closure["occupied_energy_bins"],
                    "minimum_energy": closure["minimum_energy"],
                    "maximum_energy": closure["maximum_energy"],
                },
                "t18_and_q": {
                    "t18_map_sha256": scale["t18"]["map_sha256"],
                    "open_port_routing_sha256": reconstructed["open_port"][
                        "routing_sha256"
                    ],
                    "closed_joint_tensor_sha256": reconstructed[
                        "closed_attachment"
                    ]["joint_tensor_sha256"],
                    "all_four_scalar_marginals_equal_n96": reconstructed[
                        "closed_attachment"
                    ]["all_four_scalar_marginals_equal_n96"],
                },
                "n18_n54_scale_regression": {
                    "path": str(SCALE_RESULT.relative_to(REPO_ROOT)),
                    "result_sha256": scale["result_sha256"],
                },
                "branch_report_sha256": canonical_sha256(branch_report),
                "metrics": metrics,
                "comparison": comparison,
                "checks": checks,
            },
            "result_sha256",
        )
        atomic_json(RESULT, result)
        RESULT_MD.write_text(render(result), encoding="utf-8")
    finally:
        if pool is not None:
            pool.close()
        if cache_path.exists():
            cache_path.chmod(0o644)
            cache_path.unlink()
        if temporary_root.exists():
            shutil.rmtree(temporary_root)
        cache_removed = not cache_path.exists() and not temporary_root.exists()
    saved = load_json(RESULT)
    if not cache_removed:
        raise RuntimeError("ephemeral N96 cache cleanup failed")
    saved["cache"]["ephemeral_cache_removed"] = True
    unsigned = dict(saved)
    unsigned.pop("result_sha256")
    saved = {**unsigned, "result_sha256": canonical_sha256(unsigned)}
    atomic_json(RESULT, saved)
    RESULT_MD.write_text(render(saved), encoding="utf-8")
    print(
        json.dumps(
            {
                "event": "N96_H14F_ACCEPTANCE_COMPLETE",
                "dense_wall_seconds": saved["metrics"]["dense_wall_seconds"],
                "h14c_over_h14f_ratio": saved["comparison"]["h14c_over_h14f_ratio"],
                "operator_w_sha256": saved["operator"]["w_sha256"],
                "fixed_coefficient_sha256": saved["dos"]["fixed_coefficient_sha256"],
                "result_sha256": saved["result_sha256"],
            },
            sort_keys=True,
        ),
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
