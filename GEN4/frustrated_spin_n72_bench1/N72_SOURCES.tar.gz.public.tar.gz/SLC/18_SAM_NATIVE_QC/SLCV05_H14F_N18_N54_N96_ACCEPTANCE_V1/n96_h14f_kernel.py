#!/usr/bin/env python3
"""H14F singleton-root aggregation across the frozen N96 cutset branches."""

from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np


def evaluate_n96_root_h14f(
    n96_engine: Any,
    templates: Sequence[Any],
    points: np.ndarray,
    prime: int,
    cache: Any,
    native: Any,
    retained_port_kernel: Any,
    chunk_cap: int,
) -> tuple[np.ndarray, dict[str, int]]:
    if len(points) != 1:
        raise RuntimeError("N96 H14F requires singleton-root tasks")
    if not templates:
        raise RuntimeError("N96 H14F branch roster is empty")
    retained = n96_engine.retained_engine
    total = np.zeros((int(n96_engine.STATE_COUNT), 1), dtype=np.uint64)
    peak: dict[str, int] = {}
    summed: dict[str, int] = {}
    point = int(points[0])
    for template in templates:
        terminal, metrics = retained_port_kernel(
            retained,
            template.local_instance,
            template.elimination_order,
            points,
            prime,
            template.port_order,
            cache,
            native,
            chunk_cap,
        )
        multiplier = pow(point, int(template.z_degree_shift), prime)
        contribution = (
            terminal.astype(np.uint64, copy=False) * np.uint64(multiplier)
        ) % np.uint64(prime)
        total += contribution
        total %= np.uint64(prime)
        for key, raw_value in metrics.items():
            value = int(raw_value)
            if key.startswith("sum_") or key in {
                "topology_projection_cache_entry_reads",
                "selected_value_gather_count",
                "one_branch_index_rule_count",
            }:
                summed[key] = summed.get(key, 0) + value
            else:
                peak[key] = max(peak.get(key, 0), value)
    return np.ascontiguousarray(total, dtype=np.int64), {
        **peak,
        **summed,
        "branch_count": len(templates),
        "policy_n96_branch_serial_accumulation": 1,
    }


__all__ = ["evaluate_n96_root_h14f"]
