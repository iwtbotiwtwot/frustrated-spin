# SLC v0.5 H14F scale-transfer and N96 acceptance

This supplemental campaign executes the remaining exact N18/N54 regression
and applies the already selected H14F execution policy to the frozen dense
N96 numerical authority.  It does not edit or rerun the frozen
`SLCV0.4-96-H14C-512` tree and it does not reinterpret T18, q, W8/W9, matter
identity, or the retained four-spin port.

The execution sequence is:

1. freshly compile and execute all 37 distinct Starbreaker N18 channel
   fixtures, including the analytic empty graph;
2. reconstruct all 28 N54 ledgers by exact convolution and freshly execute
   the monolithic `REF_0001/ledger_0` N54 control;
3. exhaust the typed T18 transition map and retain its existing identity;
4. compile a scale-specific N96 mixed-width projection cache;
5. execute four fresh N96 modular lanes with one persistent fourteen-core
   physical-worker pool; and
6. independently inverse-transform and CRT-reconstruct the N96 retained
   operator and scalar DOS against the frozen release authority.

The N96 run is resumable at completed-prime boundaries.  A completed prime
is retained only after its full coefficient-residue tensor equals the frozen
authority.  The first prime is therefore both useful completed work and the
live pace observation.

