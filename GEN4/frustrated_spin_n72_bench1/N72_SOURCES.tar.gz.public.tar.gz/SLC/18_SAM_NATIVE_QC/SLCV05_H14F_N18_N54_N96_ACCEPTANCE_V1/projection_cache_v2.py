#!/usr/bin/env python3
"""Scale-general mixed-width projection cache for H14F retained ports."""

from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
from typing import Any, Mapping

import numpy as np


HERE = Path(__file__).resolve().parent
REPO_ROOT = HERE.parents[2]
PARENT_PATH = (
    REPO_ROOT
    / "SLC/18_SAM_NATIVE_QC/SLCV05_N72_H14E_SHARED_PROJECTION_CACHE_V1"
    / "shared_projection_cache.py"
)
SCHEMA = "SLCV05_H14F_SCALE_GENERAL_PROJECTION_CACHE_DESCRIPTOR_V2"


def _load_parent() -> Any:
    name = "slcv05_h14f_projection_cache_parent"
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, PARENT_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load cache parent: {PARENT_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


parent = _load_parent()


def validate_descriptor(descriptor: Mapping[str, Any]) -> None:
    if descriptor.get("schema") != SCHEMA:
        raise RuntimeError("scale-general cache schema changed")
    if descriptor.get("layout") != parent.CACHE_LAYOUT:
        raise RuntimeError("scale-general cache layout changed")
    unsigned = dict(descriptor)
    observed = unsigned.pop("descriptor_sha256", None)
    if observed != parent.canonical_sha256(unsigned):
        raise RuntimeError("scale-general cache self-seal mismatch")
    if int(descriptor.get("alignment_bytes", -1)) != parent.ALIGNMENT_BYTES:
        raise RuntimeError("scale-general cache alignment changed")
    n = int(descriptor.get("source_instance_n", -1))
    ports = [int(value) for value in descriptor.get("port_order", [])]
    steps = descriptor.get("steps")
    if n < 4 or len(ports) != 4 or len(set(ports)) != 4:
        raise RuntimeError("scale-general cache source dimensions changed")
    if not isinstance(steps, list) or len(steps) != n - len(ports):
        raise RuntimeError("scale-general cache step count changed")
    if len(descriptor.get("elimination_order", [])) != len(steps):
        raise RuntimeError("scale-general cache order length changed")
    total_bytes = int(descriptor.get("total_bytes", -1))
    if total_bytes <= 0:
        raise RuntimeError("scale-general cache byte count is invalid")
    previous_stop = 0
    entry_count = 0
    dtype_counts = {"uint8": 0, "uint16": 0, "uint32": 0}
    for step_index, step in enumerate(steps):
        if int(step.get("step_index", -1)) != step_index:
            raise RuntimeError("scale-general cache step roster changed")
        maps = step.get("maps")
        if not isinstance(maps, list):
            raise RuntimeError("scale-general cache map roster is malformed")
        output_count = int(step.get("output_count", -1))
        if output_count != 1 << len(step.get("output_scope", [])):
            raise RuntimeError("scale-general cache output extent changed")
        for map_index, row in enumerate(maps):
            if int(row.get("map_index", -1)) != map_index:
                raise RuntimeError("scale-general cache map order changed")
            dtype = np.dtype(str(row.get("dtype")))
            if dtype.name not in dtype_counts:
                raise RuntimeError("scale-general cache dtype changed")
            offset = int(row.get("offset_bytes", -1))
            count = int(row.get("entry_count", -1))
            if (
                offset < previous_stop
                or offset % parent.ALIGNMENT_BYTES
                or count != output_count
                or count <= 0
            ):
                raise RuntimeError("scale-general cache extent is malformed")
            previous_stop = offset + count * dtype.itemsize
            if previous_stop > total_bytes:
                raise RuntimeError("scale-general cache extent exceeds file")
            entry_count += count
            dtype_counts[dtype.name] += count
    if previous_stop > total_bytes:
        raise RuntimeError("scale-general cache final extent exceeds file")
    if entry_count != int(descriptor.get("entry_count", -1)):
        raise RuntimeError("scale-general cache entry total changed")
    if dtype_counts != {
        key: int(value)
        for key, value in descriptor.get("dtype_entry_counts", {}).items()
    }:
        raise RuntimeError("scale-general cache dtype totals changed")


# The parent implementation is topology-generic except for its creation-time
# N72 descriptor constant and 68-step validator.  Replace only those two
# module globals; no frozen source file is edited.
parent.DESCRIPTOR_SCHEMA = SCHEMA
parent.validate_descriptor = validate_descriptor

ProjectionCache = parent.ProjectionCache
build_cache_file = parent.build_cache_file
canonical_bytes = parent.canonical_bytes
canonical_sha256 = parent.canonical_sha256
compile_descriptor = parent.compile_descriptor
open_cache_file = parent.open_cache_file
sha256_file = parent.sha256_file


__all__ = [
    "ProjectionCache",
    "SCHEMA",
    "build_cache_file",
    "canonical_bytes",
    "canonical_sha256",
    "compile_descriptor",
    "open_cache_file",
    "sha256_file",
    "validate_descriptor",
]

