#!/usr/bin/env python3
"""Exact cutset and retained-port arithmetic for the frozen N96 campaign."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import importlib
import json
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence

import numpy as np


CAMPAIGN_ID = "SLCV40_N96_CAPACITY_ADMITTED_H14C_512"
STATE_COUNT = 16
RESPONSE_VALUES = (-4, -2, 0, 2, 4)
PRIMES = (998244353, 1004535809, 469762049, 167772161)
PRIMITIVE_ROOT = 3

HERE = Path(__file__).resolve().parent
QC_ROOT = HERE.parent
V3_ROOT = QC_ROOT / "SLCV003_DENSE_EXACT_TYPED_RESOLUTION_N96"
V31_ROOT = QC_ROOT / "SLCV0031_DENSE_EXACT_FULL_Q_STAGE4_N72"
X32_ROOT = (
    QC_ROOT
    / "SLCX032_EXACT_N72_SUPERCELL_N144_DAISY_CHAIN_DISCOVERY"
)

for module_root in (V3_ROOT, V31_ROOT, X32_ROOT):
    module_text = str(module_root)
    if module_text not in sys.path:
        sys.path.insert(0, module_text)

import slcv003_core as v3_core  # noqa: E402
import slcx032_engine as retained_engine  # noqa: E402


class N96EngineError(RuntimeError):
    """Raised when a frozen N96 structure or arithmetic invariant changes."""


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def seal(unsigned: Mapping[str, Any], key: str) -> dict[str, Any]:
    return {**unsigned, key: canonical_sha256(unsigned)}


def validate_seal(value: Mapping[str, Any], key: str) -> None:
    unsigned = dict(value)
    observed = unsigned.pop(key, None)
    if observed != canonical_sha256(unsigned):
        raise N96EngineError(f"semantic self-seal mismatch: {key}")


def next_power_of_two_strictly_greater(value: int) -> int:
    if type(value) is not int or value < 0:
        raise N96EngineError("transform bound must be a nonnegative integer")
    length = 1
    while length <= value:
        length <<= 1
    if any((prime - 1) % (2 * length) for prime in PRIMES):
        raise N96EngineError("prime roster does not support the y quotient")
    return length


def _source_edge_map(
    instance: Mapping[str, Any],
) -> dict[tuple[int, int], tuple[int, int, int]]:
    return {
        (int(left), int(right)): (int(left), int(right), int(coupling))
        for left, right, coupling in instance["edges"]
    }


def cut_edges_with_weights(
    instance: Mapping[str, Any],
    cut_edge_endpoints: Sequence[Sequence[int]],
) -> list[list[int]]:
    edge_map = _source_edge_map(instance)
    result: list[list[int]] = []
    for raw_left, raw_right in cut_edge_endpoints:
        pair = tuple(sorted((int(raw_left), int(raw_right))))
        if pair not in edge_map:
            raise N96EngineError(f"retained cut edge is absent: {pair}")
        result.append(list(edge_map[pair]))
    if len(result) != 2 or len({tuple(row[:2]) for row in result}) != 2:
        raise N96EngineError("retained cut-edge roster changed")
    return result


def retained_order_structure(
    *,
    n: int,
    edges: Sequence[Sequence[int]],
    source_order: Sequence[int],
    port_order: Sequence[int],
) -> dict[str, Any]:
    ports = {int(value) for value in port_order}
    if len(ports) != 4:
        raise N96EngineError("retained port must contain four vertices")
    adjacency = {vertex: set() for vertex in range(n)}
    for raw_left, raw_right, _raw_coupling in edges:
        left, right = int(raw_left), int(raw_right)
        adjacency[left].add(right)
        adjacency[right].add(left)
    remaining = set(range(n))
    order = [
        int(vertex)
        for vertex in source_order
        if int(vertex) not in ports
    ]
    if set(order) != set(range(n)) - ports:
        raise N96EngineError("retained elimination order changed its roster")
    width = 0
    union_work = 0
    output_work = 0
    for vertex in order:
        neighbors = sorted(adjacency[vertex] & remaining)
        degree = len(neighbors)
        width = max(width, degree)
        union_work += 1 << (degree + 1)
        output_work += 1 << degree
        for index, left in enumerate(neighbors):
            for right in neighbors[index + 1 :]:
                adjacency[left].add(right)
                adjacency[right].add(left)
        remaining.remove(vertex)
        for neighbor in neighbors:
            adjacency[neighbor].discard(vertex)
    if remaining != ports:
        raise N96EngineError("retained elimination did not leave the port")
    return {
        "induced_width": width,
        "sum_2_pow_union_scope": union_work,
        "sum_2_pow_output_scope": output_work,
        "peak_union_assignment_entries": 1 << (width + 1),
        "peak_output_assignment_entries": 1 << width,
        "conditional_order": order,
    }


@dataclass(frozen=True)
class BranchTemplate:
    branch_index: int
    assignments: tuple[tuple[int, int], ...]
    local_instance: Mapping[str, Any]
    elimination_order: tuple[int, ...]
    port_order: tuple[int, ...]
    constant_energy_shift: int
    branch_bound: int
    global_local_bound: int
    z_degree_shift: int


def build_branch_templates(
    instance: Mapping[str, Any],
    plan: Mapping[str, Any],
) -> tuple[list[BranchTemplate], dict[str, Any]]:
    n = int(instance["N"])
    if n != 96:
        raise N96EngineError("campaign engine requires N96")
    cutset = [int(value) for value in plan["cutset_sites_in_order"]]
    ports_source = [int(value) for value in plan["port_order"]]
    if set(cutset) & set(ports_source):
        raise N96EngineError("cutset intersects the retained port")
    source_order = [int(value) for value in plan["selected_order"]]
    if sorted(source_order) != list(range(n)):
        raise N96EngineError("selected source order is not a permutation")
    cut_edges = cut_edges_with_weights(
        instance,
        plan["cut_edge_endpoints"],
    )
    glue_bound = sum(abs(int(row[2])) for row in cut_edges)
    global_local_bound = int(instance["energy_bound_B"]) - glue_bound
    residual_sites = [site for site in range(n) if site not in set(cutset)]
    old_to_new = {
        source_site: residual_site
        for residual_site, source_site in enumerate(residual_sites)
    }
    ports = tuple(old_to_new[site] for site in ports_source)
    cut_pairs_new = {
        tuple(sorted((old_to_new[int(left)], old_to_new[int(right)])))
        for left, right, _coupling in cut_edges
    }
    branch_templates: list[BranchTemplate] = []
    structural_reference: dict[str, Any] | None = None
    z_shifts: list[int] = []
    for branch_index in range(1 << len(cutset)):
        assignments = {
            site: (1 if branch_index & (1 << slot) else -1)
            for slot, site in enumerate(cutset)
        }
        fields = [int(instance["fields"][site]) for site in residual_sites]
        constant_shift = 0
        for site, spin in assignments.items():
            constant_shift -= int(instance["fields"][site]) * spin
        edges: list[list[int]] = []
        for raw_left, raw_right, raw_coupling in instance["edges"]:
            left = int(raw_left)
            right = int(raw_right)
            coupling = int(raw_coupling)
            left_fixed = left in assignments
            right_fixed = right in assignments
            if left_fixed and right_fixed:
                constant_shift -= (
                    coupling * assignments[left] * assignments[right]
                )
            elif left_fixed:
                fields[old_to_new[right]] += (
                    coupling * assignments[left]
                )
            elif right_fixed:
                fields[old_to_new[left]] += (
                    coupling * assignments[right]
                )
            else:
                new_left = old_to_new[left]
                new_right = old_to_new[right]
                pair = tuple(sorted((new_left, new_right)))
                if pair not in cut_pairs_new:
                    edges.append([pair[0], pair[1], coupling])
        edges.sort()
        branch_bound = sum(abs(value) for value in fields) + sum(
            abs(int(row[2])) for row in edges
        )
        z_shift = global_local_bound + constant_shift - branch_bound
        if z_shift < 0 or z_shift & 1:
            raise N96EngineError(
                f"branch {branch_index} has an invalid y alignment shift"
            )
        remapped_source_order = [
            old_to_new[site]
            for site in source_order
            if site in old_to_new
        ]
        structure = retained_order_structure(
            n=len(residual_sites),
            edges=edges,
            source_order=remapped_source_order,
            port_order=ports,
        )
        expected = {
            "induced_width": int(plan["retained_port_induced_width"]),
            "sum_2_pow_union_scope": int(
                plan["retained_port_union_per_branch"]
            ),
            "sum_2_pow_output_scope": int(
                plan["retained_port_output_per_branch"]
            ),
        }
        if any(structure[key] != value for key, value in expected.items()):
            raise N96EngineError(
                f"branch {branch_index} retained structure changed"
            )
        reference = {
            key: structure[key]
            for key in (
                "induced_width",
                "sum_2_pow_union_scope",
                "sum_2_pow_output_scope",
                "peak_union_assignment_entries",
                "peak_output_assignment_entries",
                "conditional_order",
            )
        }
        if structural_reference is None:
            structural_reference = reference
        elif reference != structural_reference:
            raise N96EngineError("branch topology or order changed")
        branch_templates.append(
            BranchTemplate(
                branch_index=branch_index,
                assignments=tuple(sorted(assignments.items())),
                local_instance={
                    "N": len(residual_sites),
                    "fields": fields,
                    "edges": edges,
                    "energy_bound_B": branch_bound,
                },
                elimination_order=tuple(
                    int(value) for value in structure["conditional_order"]
                ),
                port_order=ports,
                constant_energy_shift=constant_shift,
                branch_bound=branch_bound,
                global_local_bound=global_local_bound,
                z_degree_shift=z_shift,
            )
        )
        z_shifts.append(z_shift)
    if structural_reference is None:
        raise N96EngineError("branch roster is empty")
    weighted_union = (
        len(branch_templates)
        * int(structural_reference["sum_2_pow_union_scope"])
    )
    weighted_output = (
        len(branch_templates)
        * int(structural_reference["sum_2_pow_output_scope"])
    )
    if weighted_union != int(
        plan["retained_port_branch_weighted_union"]
    ):
        raise N96EngineError("branch-weighted retained work changed")
    report = {
        "branch_count": len(branch_templates),
        "source_cutset_sites": cutset,
        "source_port_order": ports_source,
        "residual_port_order": list(ports),
        "source_cut_edges": cut_edges,
        "global_local_bound": global_local_bound,
        "glue_bound": glue_bound,
        "total_bound": int(instance["energy_bound_B"]),
        "minimum_branch_bound": min(
            template.branch_bound for template in branch_templates
        ),
        "maximum_branch_bound": max(
            template.branch_bound for template in branch_templates
        ),
        "minimum_constant_energy_shift": min(
            template.constant_energy_shift
            for template in branch_templates
        ),
        "maximum_constant_energy_shift": max(
            template.constant_energy_shift
            for template in branch_templates
        ),
        "minimum_z_degree_shift": min(z_shifts),
        "maximum_z_degree_shift": max(z_shifts),
        "all_z_degree_shifts_even": all(not (value & 1) for value in z_shifts),
        "retained_structure": structural_reference,
        "branch_weighted_sum_2_pow_union_scope": weighted_union,
        "branch_weighted_sum_2_pow_output_scope": weighted_output,
    }
    return branch_templates, report


def zeta_points(
    prime: int,
    y_length: int,
    start: int,
    stop: int,
) -> np.ndarray:
    return retained_engine._zeta_points(prime, y_length, start, stop)


def evaluate_root_batch(
    templates: Sequence[BranchTemplate],
    points: np.ndarray,
    prime: int,
) -> tuple[np.ndarray, dict[str, int]]:
    if not templates:
        raise N96EngineError("cannot evaluate an empty branch roster")
    total = np.zeros((STATE_COUNT, len(points)), dtype=np.int64)
    peak_metrics: dict[str, int] = {}
    sum_metrics: dict[str, int] = {}
    for template in templates:
        terminal, metrics = retained_engine.retained_port_root_batch(
            template.local_instance,
            template.elimination_order,
            points,
            prime,
            template.port_order,
        )
        multipliers = np.asarray(
            [
                pow(int(point), template.z_degree_shift, prime)
                for point in points
            ],
            dtype=np.int64,
        )
        terminal = terminal * multipliers[np.newaxis, :] % prime
        total += terminal
        total %= prime
        for key, raw_value in metrics.items():
            value = int(raw_value)
            if key.startswith("sum_"):
                sum_metrics[key] = sum_metrics.get(key, 0) + value
            else:
                peak_metrics[key] = max(
                    peak_metrics.get(key, 0),
                    value,
                )
    return np.ascontiguousarray(total, dtype=np.int64), {
        **peak_metrics,
        **sum_metrics,
        "branch_count": len(templates),
    }


def inverse_ntt(values: Sequence[int], prime: int) -> list[int]:
    exact = retained_engine._modules()[1]
    return [int(value) for value in exact._inverse_ntt(values, prime)]


def crt(residues: Sequence[int], primes: Sequence[int]) -> int:
    exact = retained_engine._modules()[1]
    return int(exact._crt(residues, primes))


def _state_spin(
    state: int,
    vertex: int,
    port_order: Sequence[int],
) -> int:
    position = tuple(int(value) for value in port_order).index(vertex)
    return 1 if state & (1 << position) else -1


def glue_y_degrees(
    cut_edges: Sequence[Sequence[int]],
    port_order: Sequence[int],
) -> list[list[int]]:
    ports = [int(value) for value in port_order]
    table = [[0 for _ in range(STATE_COUNT)] for _ in range(STATE_COUNT)]
    glue_bound = sum(abs(int(row[2])) for row in cut_edges)
    for left_state in range(STATE_COUNT):
        for right_state in range(STATE_COUNT):
            z_degree = 0
            for raw_left, raw_right, raw_coupling in cut_edges:
                left = int(raw_left)
                right = int(raw_right)
                coupling = int(raw_coupling)
                z_degree += (
                    -coupling
                    * _state_spin(left_state, left, ports)
                    * _state_spin(right_state, right, ports)
                    + abs(coupling)
                )
            if z_degree < 0 or z_degree & 1:
                raise N96EngineError("glue exponent escaped the y quotient")
            table[left_state][right_state] = z_degree // 2
    if min(map(min, table)) < 0 or max(map(max, table)) > glue_bound:
        raise N96EngineError("glue y degree escaped its exact bound")
    return table


def fixed_energy_vector_from_y(
    coefficients_y: Sequence[int],
    bound: int,
) -> list[int]:
    fixed = [0] * (2 * bound + 1)
    for degree, raw_count in enumerate(coefficients_y):
        count = int(raw_count)
        if count < 0:
            raise N96EngineError("coefficient cannot be negative")
        energy = 2 * degree - bound
        if not -bound <= energy <= bound:
            if count:
                raise N96EngineError(
                    "nonzero coefficient lies above the exact bound"
                )
            continue
        fixed[energy + bound] = count
    return fixed


def close_one_cell(
    w_coefficients: Sequence[Sequence[int]],
    glue: Sequence[Sequence[int]],
    *,
    local_bound: int,
    total_bound: int,
) -> dict[str, Any]:
    if len(w_coefficients) != STATE_COUNT:
        raise N96EngineError("retained W must contain sixteen rows")
    coefficients = [0] * (total_bound + 1)
    for state in range(STATE_COUNT):
        shift = int(glue[state][state])
        row = w_coefficients[state]
        if len(row) != local_bound + 1:
            raise N96EngineError("retained W degree roster changed")
        for degree, raw_count in enumerate(row):
            coefficients[degree + shift] += int(raw_count)
    fixed = fixed_energy_vector_from_y(coefficients, total_bound)
    rows = [
        {
            "energy": energy,
            "count": str(fixed[energy + total_bound]),
        }
        for energy in range(-total_bound, total_bound + 1)
        if fixed[energy + total_bound]
    ]
    return {
        "y_coefficients": coefficients,
        "fixed_coefficients": fixed,
        "fixed_coefficient_sha256": canonical_sha256(fixed),
        "dos_rows": rows,
        "dos_sha256": canonical_sha256(rows),
        "configuration_count": sum(fixed),
        "occupied_energy_bins": len(rows),
        "minimum_energy": rows[0]["energy"],
        "maximum_energy": rows[-1]["energy"],
    }


def exact_dos_verification(
    instance: Mapping[str, Any],
    fixed: Sequence[int],
) -> dict[str, Any]:
    bound = int(instance["energy_bound_B"])
    dos = {
        index - bound: int(count)
        for index, count in enumerate(fixed)
        if int(count)
    }
    _fused, parent = v3_core.load_engines()
    report = dict(parent.verify_dos(instance, dos))
    if report.get("status") != "PASS":
        raise N96EngineError("exact N96 DOS invariants failed")
    return report


def build_closed_fiber_attachment(
    w_coefficients: Sequence[Sequence[int]],
    glue: Sequence[Sequence[int]],
    routing: np.ndarray,
    fixed: Sequence[int],
    *,
    local_bound: int,
    total_bound: int,
) -> dict[str, Any]:
    joint = [
        [[0] * (2 * total_bound + 1) for _ in RESPONSE_VALUES]
        for _ in range(4)
    ]
    for q in range(4):
        for state in range(STATE_COUNT):
            response_index = int(routing[q, state, state])
            shift = int(glue[state][state])
            for degree, raw_count in enumerate(w_coefficients[state]):
                fixed_index = 2 * (degree + shift)
                if not 0 <= fixed_index < 2 * total_bound + 1:
                    raise N96EngineError(
                        "fiber contribution escaped the fixed domain"
                    )
                joint[q][response_index][fixed_index] += int(raw_count)
    signatures: list[str] = []
    response_totals: dict[str, dict[str, str]] = {}
    marginal_hashes: list[str] = []
    for q in range(4):
        marginal = [
            sum(joint[q][response][index] for response in range(5))
            for index in range(2 * total_bound + 1)
        ]
        if marginal != list(fixed):
            raise N96EngineError("fiber changed an N96 scalar marginal")
        signatures.append(canonical_sha256(joint[q]))
        marginal_hashes.append(canonical_sha256(marginal))
        response_totals[str(q)] = {
            str(response): str(sum(joint[q][response_index]))
            for response_index, response in enumerate(RESPONSE_VALUES)
        }
    equality_pairs = [
        [left, right]
        for left in range(4)
        for right in range(left + 1, 4)
        if signatures[left] == signatures[right]
    ]
    return {
        "attachment": "N96_FINAL_ONE_CELL_TRACE_SCALAR_MARGINAL",
        "joint_coordinate_order": [
            "q",
            "ordered_square_response",
            "fixed_energy",
        ],
        "joint_shape": [4, 5, 2 * total_bound + 1],
        "joint_tensor_sha256": canonical_sha256(joint),
        "q_joint_signature_sha256": signatures,
        "distinct_q_joint_signature_count": len(set(signatures)),
        "equal_q_signature_pairs": equality_pairs,
        "response_totals": response_totals,
        "scalar_marginal_sha256_by_q": marginal_hashes,
        "scalar_fixed_sha256": canonical_sha256(list(fixed)),
        "all_four_scalar_marginals_equal_n96": True,
        "configuration_count_per_q": str(sum(fixed)),
        "local_bound": local_bound,
        "total_bound": total_bound,
    }


def run_cutset_port_fixture() -> dict[str, Any]:
    """Small exact fixture for branch alignment, retained ports, and closure."""

    fixture = {
        "N": 12,
        "fields": [1, -1, 2, 0, -2, 1, 0, 1, -1, 2, 0, -1],
        "edges": [
            [0, 1, 2],
            [0, 4, -1],
            [1, 5, 1],
            [2, 3, -1],
            [2, 6, 2],
            [3, 7, 1],
            [4, 5, -2],
            [4, 8, 1],
            [5, 9, -1],
            [6, 7, 2],
            [6, 10, -1],
            [7, 11, 1],
            [8, 9, 2],
            [9, 10, 1],
            [10, 11, -2],
        ],
    }
    fixture["energy_bound_B"] = sum(
        abs(value) for value in fixture["fields"]
    ) + sum(abs(row[2]) for row in fixture["edges"])
    cutset = [4, 7]
    ports = [0, 1, 2, 3]
    source_order = list(range(4, 12)) + ports
    edge_map = {
        (row[0], row[1]): row for row in fixture["edges"]
    }
    cut_edges = [edge_map[(0, 1)], edge_map[(2, 3)]]
    glue_bound = sum(abs(row[2]) for row in cut_edges)
    local_bound = fixture["energy_bound_B"] - glue_bound
    residual_sites = [
        site for site in range(fixture["N"]) if site not in set(cutset)
    ]
    old_to_new = {
        site: index for index, site in enumerate(residual_sites)
    }
    remapped_ports = [old_to_new[site] for site in ports]
    templates: list[BranchTemplate] = []
    for branch_index in range(4):
        assignments = {
            site: (1 if branch_index & (1 << slot) else -1)
            for slot, site in enumerate(cutset)
        }
        fields = [fixture["fields"][site] for site in residual_sites]
        constant_shift = sum(
            -fixture["fields"][site] * spin
            for site, spin in assignments.items()
        )
        edges: list[list[int]] = []
        for left, right, coupling in fixture["edges"]:
            left_fixed = left in assignments
            right_fixed = right in assignments
            if left_fixed and right_fixed:
                constant_shift -= (
                    coupling * assignments[left] * assignments[right]
                )
            elif left_fixed:
                fields[old_to_new[right]] += (
                    coupling * assignments[left]
                )
            elif right_fixed:
                fields[old_to_new[left]] += (
                    coupling * assignments[right]
                )
            elif [left, right, coupling] not in cut_edges:
                edges.append(
                    [old_to_new[left], old_to_new[right], coupling]
                )
        branch_bound = sum(abs(value) for value in fields) + sum(
            abs(row[2]) for row in edges
        )
        z_shift = local_bound + constant_shift - branch_bound
        if z_shift < 0 or z_shift & 1:
            raise N96EngineError("fixture branch alignment failed")
        order = [
            old_to_new[site]
            for site in source_order
            if site in old_to_new and site not in ports
        ]
        templates.append(
            BranchTemplate(
                branch_index=branch_index,
                assignments=tuple(sorted(assignments.items())),
                local_instance={
                    "N": len(residual_sites),
                    "fields": fields,
                    "edges": sorted(edges),
                    "energy_bound_B": branch_bound,
                },
                elimination_order=tuple(order),
                port_order=tuple(remapped_ports),
                constant_energy_shift=constant_shift,
                branch_bound=branch_bound,
                global_local_bound=local_bound,
                z_degree_shift=z_shift,
            )
        )
    y_length = next_power_of_two_strictly_greater(local_bound)
    prime = PRIMES[0]
    evaluations = np.zeros((STATE_COUNT, y_length), dtype=np.int64)
    for start in range(0, y_length, 4):
        stop = min(y_length, start + 4)
        points = zeta_points(prime, y_length, start, stop)
        terminal, _metrics = evaluate_root_batch(
            templates,
            points,
            prime,
        )
        evaluations[:, start:stop] = terminal
    w: list[list[int]] = []
    for state in range(STATE_COUNT):
        row = inverse_ntt(evaluations[state].tolist(), prime)
        if any(row[local_bound + 1 :]):
            raise N96EngineError("fixture W support escaped its bound")
        w.append(row[: local_bound + 1])
    glue = glue_y_degrees(cut_edges, ports)
    closed = close_one_cell(
        w,
        glue,
        local_bound=local_bound,
        total_bound=fixture["energy_bound_B"],
    )
    brute: dict[int, int] = {}
    for assignment in range(1 << fixture["N"]):
        spins = [
            1 if assignment & (1 << site) else -1
            for site in range(fixture["N"])
        ]
        energy = -sum(
            field * spins[site]
            for site, field in enumerate(fixture["fields"])
        ) - sum(
            coupling * spins[left] * spins[right]
            for left, right, coupling in fixture["edges"]
        )
        brute[energy] = brute.get(energy, 0) + 1
    observed = {
        int(row["energy"]): int(row["count"])
        for row in closed["dos_rows"]
    }
    if observed != dict(sorted(brute.items())):
        raise N96EngineError(
            "cutset/retained-port fixture differs from direct enumeration"
        )
    return {
        "schema": "SLCV40_N96_CUTSET_PORT_FIXTURE_V1",
        "status": "PASS",
        "N": fixture["N"],
        "cutset_sites": cutset,
        "branch_count": len(templates),
        "port_order": ports,
        "cut_edges": cut_edges,
        "energy_bound_B": fixture["energy_bound_B"],
        "local_bound": local_bound,
        "y_ntt_length": y_length,
        "configuration_count": closed["configuration_count"],
        "dos_sha256": closed["dos_sha256"],
    }


__all__ = [
    "BranchTemplate",
    "CAMPAIGN_ID",
    "N96EngineError",
    "PRIMES",
    "PRIMITIVE_ROOT",
    "RESPONSE_VALUES",
    "STATE_COUNT",
    "build_branch_templates",
    "build_closed_fiber_attachment",
    "canonical_bytes",
    "canonical_sha256",
    "close_one_cell",
    "crt",
    "cut_edges_with_weights",
    "evaluate_root_batch",
    "exact_dos_verification",
    "fixed_energy_vector_from_y",
    "glue_y_degrees",
    "inverse_ntt",
    "next_power_of_two_strictly_greater",
    "retained_order_structure",
    "run_cutset_port_fixture",
    "seal",
    "validate_seal",
    "zeta_points",
]
