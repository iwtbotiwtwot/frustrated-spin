#!/usr/bin/env python3
"""Shared identities and exact dependency loading for Dense Exact v0.3.1."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import ModuleType
from typing import Any, Mapping


CAMPAIGN_ID = "SLCV0031_DENSE_EXACT_FULL_Q_STAGE4_N72"
VERSION_LABEL = "SLC_DENSE_EXACT_V0_3_1_DEVELOPMENT"

BASE = Path(__file__).resolve().parent
SLC_ROOT = BASE.parents[1]
REPOSITORY_ROOT = BASE.parents[2]

STAGE4_ENGINE_PATH = (
    SLC_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLC_N72_NATIVE_APPLICATIONS_CHAINING_N96_HOLDOUT"
    / "CELL_TRANSFER"
    / "IMPLEMENTATION"
    / "slc_stage4r1_engine.py"
)
W10_C4_MODEL_PATH = (
    SLC_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLCN10E002_W10_C4_FRACTURE_TWIST_PORT"
    / "slcn10e002_model.py"
)
FOUR_WORKER_PATH = (
    SLC_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLCV002C4_FOUR_SLC_CLUSTER_SCALING_LADDER"
    / "slcv002c4_worker.py"
)
FUSED_ENGINE_PATH = (
    SLC_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLCX030_N72_STRUCTURE_ONLY_RETAINED_BOUNDARY_COMPRESSION_GATE"
    / "release"
    / "executed_capsule"
    / "slcx029_graph_engine.py"
)
PARENT_ENGINE_PATH = (
    SLC_ROOT
    / "18_SAM_NATIVE_QC"
    / "SLCX025_EXACT_N72_FRUSTRATED_ISING_DOS_EXTENSION"
    / "SLCX025_EXECUTION_CAPSULE"
    / "slcx023_exact_engine.py"
)

EXPECTED_SHA256 = {
    STAGE4_ENGINE_PATH: (
        "1f2b368d711e9b72a4d58ff0049208d139788efaeaef7d0a332a1f79e84805c5"
    ),
    W10_C4_MODEL_PATH: (
        "1cdb475ddb35c3e4d86fd56208edfc0e5b26174b6505c5a6045e5fd59d26f8e5"
    ),
    FOUR_WORKER_PATH: (
        "a21e3cbbf7099a2d5285b7a93d45a843df451d42709558acd6b9cc8048ff027f"
    ),
    FUSED_ENGINE_PATH: (
        "9827128293c306439000e5160fcac3d13d534cb825b7c508fcdef921bdded3aa"
    ),
    PARENT_ENGINE_PATH: (
        "fb8bff08ae0836a628a90edb141f8e3d96ae13d96075eb2e2031d12737f77c5a"
    ),
}


class SLCV0031Error(RuntimeError):
    """Raised when a v0.3.1 contract or exact implementation is inconsistent."""


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sealed(unsigned: Mapping[str, Any], key: str = "receipt_sha256") -> dict[str, Any]:
    return {**unsigned, key: canonical_sha256(unsigned)}


def validate_seal(
    record: Mapping[str, Any],
    key: str = "receipt_sha256",
) -> None:
    unsigned = dict(record)
    observed = unsigned.pop(key, None)
    if observed != canonical_sha256(unsigned):
        raise SLCV0031Error(f"self-seal mismatch: {key}")


def load_exact_module(path: Path, module_name: str) -> ModuleType:
    """Load one recorded implementation dependency by its exact source identity."""

    if path.is_symlink() or not path.is_file():
        raise SLCV0031Error(f"dependency must be a regular file: {path}")
    expected = EXPECTED_SHA256.get(path)
    if expected is None:
        raise SLCV0031Error(f"dependency has no declared source identity: {path}")
    observed = sha256_file(path)
    if observed != expected:
        raise SLCV0031Error(
            f"dependency source identity changed: {path.name}: {observed}"
        )
    existing = sys.modules.get(module_name)
    if existing is not None:
        return existing
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise SLCV0031Error(f"could not load dependency: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    return module


__all__ = [
    "BASE",
    "CAMPAIGN_ID",
    "EXPECTED_SHA256",
    "FOUR_WORKER_PATH",
    "FUSED_ENGINE_PATH",
    "PARENT_ENGINE_PATH",
    "REPOSITORY_ROOT",
    "SLCV0031Error",
    "SLC_ROOT",
    "STAGE4_ENGINE_PATH",
    "VERSION_LABEL",
    "W10_C4_MODEL_PATH",
    "canonical_bytes",
    "canonical_sha256",
    "load_exact_module",
    "sealed",
    "sha256_file",
    "validate_seal",
]
