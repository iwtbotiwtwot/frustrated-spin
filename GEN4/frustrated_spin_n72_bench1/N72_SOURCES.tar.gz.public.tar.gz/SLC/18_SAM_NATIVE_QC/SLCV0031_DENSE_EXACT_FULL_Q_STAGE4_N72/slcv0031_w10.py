#!/usr/bin/env python3
"""Active full-q W10 state and ordered-square response for v0.3.1."""

from __future__ import annotations

from collections import Counter
from typing import Any, Iterable, Mapping, Sequence

from slcv0031_common import (
    CAMPAIGN_ID,
    SLCV0031Error,
    VERSION_LABEL,
    W10_C4_MODEL_PATH,
    canonical_sha256,
    load_exact_module,
    sealed,
    validate_seal,
)


SHELL_STATE_COUNT = 256
POSITION_COUNT = 4
LOCAL_STATE_COUNT = SHELL_STATE_COUNT * POSITION_COUNT
PORT_BITS = 4
PORT_STATE_COUNT = 1 << PORT_BITS
RESPONSE_VALUES = (-4, -2, 0, 2, 4)
EVENT_INCREMENTS = {
    "IDENTITY": 0,
    "FORWARD": 1,
    "REVERSE": -1,
}
FULL_Q_SCHEMA = "SLCV0031_ACTIVE_FULL_Q_TENSOR_V1"
STATE_SCHEMA = "SLCV0031_W10_LOCAL_STATE_V1"
EVENT_SCHEMA = "SLCV0031_W10_EVENT_V1"


def _model() -> Any:
    return load_exact_module(W10_C4_MODEL_PATH, "_slcv0031_w10_c4_model")


def state_id(shell_mask: int, q: int) -> int:
    if type(shell_mask) is not int or not 0 <= shell_mask < SHELL_STATE_COUNT:
        raise SLCV0031Error("shell mask lies outside the exact 256-state roster")
    if type(q) is not int or not 0 <= q < POSITION_COUNT:
        raise SLCV0031Error("W10 position lies outside Z4")
    return shell_mask * POSITION_COUNT + q


def decode_state_id(value: int) -> tuple[int, int]:
    if type(value) is not int or not 0 <= value < LOCAL_STATE_COUNT:
        raise SLCV0031Error("W10 state ID lies outside the 1,024-state roster")
    return divmod(value, POSITION_COUNT)


def make_state(shell_mask: int, q: int) -> dict[str, Any]:
    unsigned = {
        "schema": STATE_SCHEMA,
        "campaign_id": CAMPAIGN_ID,
        "version_label": VERSION_LABEL,
        "state_id": state_id(shell_mask, q),
        "shell_mask": shell_mask,
        "q": q,
        "q_hi": (q >> 1) & 1,
        "q_lo": q & 1,
    }
    return sealed(unsigned, "state_sha256")


def apply_event(state: Mapping[str, Any], event: str) -> dict[str, Any]:
    validate_state(state)
    if event not in EVENT_INCREMENTS:
        raise SLCV0031Error(f"unknown W10 event: {event}")
    increment = EVENT_INCREMENTS[event]
    source_q = int(state["q"])
    target_q = (source_q + increment) % POSITION_COUNT
    target = make_state(int(state["shell_mask"]), target_q)
    unsigned = {
        "schema": EVENT_SCHEMA,
        "campaign_id": CAMPAIGN_ID,
        "event": event,
        "increment_mod_4": increment % POSITION_COUNT,
        "source_state_id": int(state["state_id"]),
        "source_q": source_q,
        "source_q_bits": [int(state["q_hi"]), int(state["q_lo"])],
        "target_state_id": int(target["state_id"]),
        "target_q": target_q,
        "target_q_bits": [int(target["q_hi"]), int(target["q_lo"])],
        "shell_mask_unchanged": int(target["shell_mask"]) == int(state["shell_mask"]),
    }
    return sealed(unsigned, "event_sha256")


def validate_state(state: Mapping[str, Any]) -> dict[str, Any]:
    if state.get("schema") != STATE_SCHEMA:
        raise SLCV0031Error("W10 local-state schema mismatch")
    unsigned = dict(state)
    observed = unsigned.pop("state_sha256", None)
    if observed != canonical_sha256(unsigned):
        raise SLCV0031Error("W10 local-state seal mismatch")
    expected = make_state(int(state["shell_mask"]), int(state["q"]))
    if dict(state) != expected:
        raise SLCV0031Error("W10 local-state fields are inconsistent")
    return {
        "status": "PASS",
        "state_id": int(state["state_id"]),
        "q": int(state["q"]),
        "state_sha256": observed,
    }


def port_spins(port_state: int) -> tuple[int, int, int, int]:
    if type(port_state) is not int or not 0 <= port_state < PORT_STATE_COUNT:
        raise SLCV0031Error("square-port state lies outside the 16-state roster")
    return tuple(
        1 if port_state & (1 << slot) else -1
        for slot in range(PORT_BITS)
    )


def square_response(left_state: int, right_state: int, q: int) -> int:
    if type(q) is not int or not 0 <= q < POSITION_COUNT:
        raise SLCV0031Error("square response position lies outside Z4")
    left = port_spins(left_state)
    right = port_spins(right_state)
    response = int(_model().port_response(left, right, q))
    if response not in RESPONSE_VALUES:
        raise SLCV0031Error("square response escaped its exact five-value domain")
    return response


def response_table() -> list[dict[str, int]]:
    return [
        {
            "q": q,
            "left_port_state": left,
            "right_port_state": right,
            "response": square_response(left, right, q),
        }
        for q in range(POSITION_COUNT)
        for left in range(PORT_STATE_COUNT)
        for right in range(PORT_STATE_COUNT)
    ]


def compile_stage4_port_adapter(
    *,
    left_local_sites: Sequence[int],
    right_local_sites: Sequence[int],
) -> dict[str, Any]:
    """Map tested W10 square slots to the tested four-spin Stage4 port order."""

    left_sites = [int(value) for value in left_local_sites]
    right_sites = [int(value) for value in right_local_sites]
    if len(left_sites) != PORT_BITS or len(set(left_sites)) != PORT_BITS:
        raise SLCV0031Error("Stage4 left port is not four distinct ordered sites")
    if len(right_sites) != PORT_BITS or len(set(right_sites)) != PORT_BITS:
        raise SLCV0031Error("Stage4 right port is not four distinct ordered sites")
    rows = response_table()
    direct_equal = all(
        row["response"]
        == -sum(
            port_spins(row["left_port_state"])[slot]
            * port_spins(row["right_port_state"])[(slot + row["q"]) % 4]
            for slot in range(4)
        )
        for row in rows
    )
    if not direct_equal:
        raise SLCV0031Error("W10 ordered-square adapter changed a response")
    unsigned = {
        "schema": "SLCV0031_W10_STAGE4_PORT_ADAPTER_V1",
        "campaign_id": CAMPAIGN_ID,
        "left_slot_to_stage4_local_site": {
            str(slot): site for slot, site in enumerate(left_sites)
        },
        "right_slot_to_stage4_local_site": {
            str(slot): site for slot, site in enumerate(right_sites)
        },
        "bit_to_spin_rule": "0_TO_MINUS_1__1_TO_PLUS_1",
        "q_action": "RIGHT_SLOT_(LEFT_SLOT_PLUS_Q)_MOD_4",
        "response_rule": "NEGATIVE_SUM_OF_FOUR_MATCHED_SPIN_PRODUCTS",
        "response_domain": list(RESPONSE_VALUES),
        "complete_response_row_count": len(rows),
        "complete_response_sha256": canonical_sha256(rows),
        "direct_response_equality": direct_equal,
        "stage4_energy_relation": (
            "SEPARATE_JOINT_OBSERVABLE__NOT_AN_UNDECLARED_REPLACEMENT_"
            "FOR_THE_COMPLETE_K4_4_ENERGY_KERNEL"
        ),
    }
    return sealed(unsigned, "adapter_sha256")


def encode_q_vector(q_values: Sequence[int]) -> tuple[int, int]:
    low = 0
    high = 0
    for index, raw_q in enumerate(q_values):
        q = int(raw_q)
        if q not in range(POSITION_COUNT):
            raise SLCV0031Error("full-q vector contains a value outside Z4")
        low |= (q & 1) << index
        high |= ((q >> 1) & 1) << index
    return low, high


def decode_q_factors(
    low_factor: int,
    high_factor: int,
    *,
    record_count: int,
) -> tuple[int, ...]:
    dimension = 1 << record_count
    if (
        type(low_factor) is not int
        or type(high_factor) is not int
        or not 0 <= low_factor < dimension
        or not 0 <= high_factor < dimension
    ):
        raise SLCV0031Error("full-q factor index lies outside its dimension")
    return tuple(
        (((high_factor >> index) & 1) << 1)
        | ((low_factor >> index) & 1)
        for index in range(record_count)
    )


def apply_event_to_q_factors(
    low_factor: int,
    high_factor: int,
    *,
    record_count: int,
    record_index: int,
    event: str,
) -> tuple[int, int]:
    if not 0 <= record_index < record_count:
        raise SLCV0031Error("event record index lies outside the full-q roster")
    if event not in EVENT_INCREMENTS:
        raise SLCV0031Error(f"unknown W10 event: {event}")
    q_values = list(
        decode_q_factors(
            low_factor,
            high_factor,
            record_count=record_count,
        )
    )
    q_values[record_index] = (
        q_values[record_index] + EVENT_INCREMENTS[event]
    ) % POSITION_COUNT
    return encode_q_vector(q_values)


def full_q_tensor_plan(record_count: int = 9) -> dict[str, Any]:
    if type(record_count) is not int or record_count < 1:
        raise SLCV0031Error("full-q record count must be a positive integer")
    factor_dimension = 1 << record_count
    event_table = [
        {
            "source_q": q,
            "event": event,
            "target_q": (q + increment) % 4,
            "source_bits": [(q >> 1) & 1, q & 1],
            "target_bits": [
                (((q + increment) % 4) >> 1) & 1,
                ((q + increment) % 4) & 1,
            ],
        }
        for q in range(4)
        for event, increment in EVENT_INCREMENTS.items()
    ]
    carry_couples_coordinates = any(
        row["source_bits"][0] != row["target_bits"][0]
        and row["source_bits"][1] != row["target_bits"][1]
        for row in event_table
    )
    unsigned = {
        "schema": FULL_Q_SCHEMA,
        "campaign_id": CAMPAIGN_ID,
        "version_label": VERSION_LABEL,
        "record_count": record_count,
        "coordinate_group": "Z4",
        "position_count_per_record": POSITION_COUNT,
        "assignment_count": str(4**record_count),
        "factorization": {
            "low_bit_factor_dimension": factor_dimension,
            "high_bit_factor_dimension": factor_dimension,
            "equation": f"4^{record_count}=2^{record_count}*2^{record_count}",
            "both_factors_active": True,
            "constant_multiplicity": False,
        },
        "event_table": event_table,
        "event_table_sha256": canonical_sha256(event_table),
        "mod_4_carry_couples_binary_storage_coordinates": (
            carry_couples_coordinates
        ),
        "execution_coordinates": [
            "q_low_factor",
            "q_high_factor",
            "record_index",
            "c4_position",
        ],
    }
    return sealed(unsigned, "tensor_plan_sha256")


def validate_full_q_tensor_plan(plan: Mapping[str, Any]) -> dict[str, Any]:
    validate_seal(plan, "tensor_plan_sha256")
    if plan.get("schema") != FULL_Q_SCHEMA:
        raise SLCV0031Error("full-q tensor schema mismatch")
    record_count = int(plan["record_count"])
    factor = 1 << record_count
    if (
        plan.get("coordinate_group") != "Z4"
        or int(plan["assignment_count"]) != 4**record_count
        or plan.get("factorization", {}).get("low_bit_factor_dimension") != factor
        or plan.get("factorization", {}).get("high_bit_factor_dimension") != factor
        or plan.get("factorization", {}).get("both_factors_active") is not True
        or plan.get("factorization", {}).get("constant_multiplicity") is not False
    ):
        raise SLCV0031Error("full-q tensor dimensions or activity changed")
    return {
        "status": "PASS",
        "record_count": record_count,
        "assignment_count": 4**record_count,
        "factor_dimensions": [factor, factor],
        "tensor_plan_sha256": plan["tensor_plan_sha256"],
    }


def finite_state_receipt() -> dict[str, Any]:
    states = [
        make_state(shell_mask, q)
        for shell_mask in range(SHELL_STATE_COUNT)
        for q in range(POSITION_COUNT)
    ]
    transitions = [
        apply_event(state, event)
        for state in states
        for event in EVENT_INCREMENTS
    ]
    target_counts = Counter(int(row["target_state_id"]) for row in transitions)
    if len(states) != 1024 or len(transitions) != 3072:
        raise SLCV0031Error("W10 finite-state cardinality changed")
    if set(target_counts.values()) != {3}:
        raise SLCV0031Error("W10 event action is not closed and balanced")
    unsigned = {
        "schema": "SLCV0031_W10_FINITE_STATE_RECEIPT_V1",
        "campaign_id": CAMPAIGN_ID,
        "state_count": len(states),
        "transition_count": len(transitions),
        "event_count": len(EVENT_INCREMENTS),
        "state_roster_sha256": canonical_sha256(states),
        "transition_roster_sha256": canonical_sha256(transitions),
        "closed_under_events": True,
        "each_state_has_one_preimage_per_event": True,
    }
    return sealed(unsigned)


def c4_character_multiplicities() -> dict[str, Any]:
    """Return the exact C4 multiplicities on the 16 binary square states."""

    fixed_counts = []
    for shift in range(4):
        fixed = 0
        for state in range(PORT_STATE_COUNT):
            spins = port_spins(state)
            rotated = tuple(spins[(slot + shift) % 4] for slot in range(4))
            fixed += int(rotated == spins)
        fixed_counts.append(fixed)
    # For C4 characters 1, i, -1, -i.  The imaginary terms cancel because
    # fixed_counts[1] == fixed_counts[3].
    multiplicities = [
        (fixed_counts[0] + fixed_counts[1] + fixed_counts[2] + fixed_counts[3])
        // 4,
        (fixed_counts[0] - fixed_counts[2]) // 4,
        (fixed_counts[0] - fixed_counts[1] + fixed_counts[2] - fixed_counts[3])
        // 4,
        (fixed_counts[0] - fixed_counts[2]) // 4,
    ]
    if fixed_counts != [16, 2, 4, 2] or multiplicities != [6, 3, 4, 3]:
        raise SLCV0031Error("C4 square-state character dimensions changed")
    unsigned = {
        "schema": "SLCV0031_C4_CHARACTER_BLOCK_PLAN_V1",
        "group": "C4",
        "square_state_count": 16,
        "fixed_state_counts_by_shift": fixed_counts,
        "character_block_dimensions": multiplicities,
        "dimension_sum": sum(multiplicities),
        "status": "EXACT_SCHEDULER_CANDIDATE",
    }
    return sealed(unsigned)


def rotate_port_state(port_state: int, shift: int) -> int:
    spins = port_spins(port_state)
    normalized_shift = int(shift) % 4
    rotated = tuple(
        spins[(slot + normalized_shift) % 4]
        for slot in range(4)
    )
    return sum(
        (1 if spin == 1 else 0) << slot
        for slot, spin in enumerate(rotated)
    )


def c4_state_orbits() -> list[dict[str, Any]]:
    remaining = set(range(PORT_STATE_COUNT))
    orbits: list[dict[str, Any]] = []
    while remaining:
        seed = min(remaining)
        orbit: list[int] = []
        current = seed
        while current not in orbit:
            orbit.append(current)
            current = rotate_port_state(current, 1)
        if current != seed or len(orbit) not in (1, 2, 4):
            raise SLCV0031Error("binary square generated an invalid C4 orbit")
        remaining -= set(orbit)
        orbits.append(
            {
                "orbit_id": len(orbits),
                "states": orbit,
                "size": len(orbit),
            }
        )
    if sorted(row["size"] for row in orbits) != [1, 1, 2, 4, 4, 4]:
        raise SLCV0031Error("C4 square-state orbit roster changed")
    return orbits


def c4_block_coordinate_roster() -> list[list[dict[str, int]]]:
    blocks: list[list[dict[str, int]]] = [[], [], [], []]
    for orbit in c4_state_orbits():
        size = int(orbit["size"])
        for local_mode in range(size):
            character = local_mode * (4 // size)
            blocks[character].append(
                {
                    "orbit_id": int(orbit["orbit_id"]),
                    "orbit_size": size,
                    "local_mode": local_mode,
                }
            )
    if [len(block) for block in blocks] != [6, 3, 4, 3]:
        raise SLCV0031Error("C4 block coordinate dimensions changed")
    return blocks


def c4_block_transform(
    values: Sequence[int],
    prime: int,
) -> list[list[int]]:
    if len(values) != PORT_STATE_COUNT:
        raise SLCV0031Error("C4 block transform requires 16 state values")
    if type(prime) is not int or (prime - 1) % 4:
        raise SLCV0031Error("C4 block transform prime lacks a fourth root")
    blocks: list[list[int]] = [[], [], [], []]
    for orbit in c4_state_orbits():
        states = [int(value) for value in orbit["states"]]
        size = int(orbit["size"])
        root = pow(3, (prime - 1) // size, prime)
        for local_mode in range(size):
            value = sum(
                int(values[state])
                * pow(root, (-local_mode * position) % size, prime)
                for position, state in enumerate(states)
            ) % prime
            character = local_mode * (4 // size)
            blocks[character].append(value)
    return blocks


def c4_block_inverse(
    blocks: Sequence[Sequence[int]],
    prime: int,
) -> list[int]:
    roster = c4_block_coordinate_roster()
    if (
        len(blocks) != 4
        or any(len(blocks[index]) != len(roster[index]) for index in range(4))
    ):
        raise SLCV0031Error("C4 block values do not match the 6/3/4/3 roster")
    lookup = {
        (int(record["orbit_id"]), int(record["local_mode"])): int(
            blocks[character][index]
        )
        for character, block in enumerate(roster)
        for index, record in enumerate(block)
    }
    output = [0] * PORT_STATE_COUNT
    for orbit in c4_state_orbits():
        orbit_id = int(orbit["orbit_id"])
        states = [int(value) for value in orbit["states"]]
        size = int(orbit["size"])
        root = pow(3, (prime - 1) // size, prime)
        inverse_size = pow(size, prime - 2, prime)
        for position, state in enumerate(states):
            output[state] = (
                inverse_size
                * sum(
                    lookup[(orbit_id, local_mode)]
                    * pow(root, local_mode * position, prime)
                    for local_mode in range(size)
                )
            ) % prime
    return output


def c4_block_comparison(
    vectors: Iterable[Sequence[int]],
    *,
    primes: Sequence[int],
) -> dict[str, Any]:
    canonical_vectors = [
        [int(value) for value in vector]
        for vector in vectors
    ]
    if not canonical_vectors:
        raise SLCV0031Error("C4 block comparison requires at least one vector")
    prime_rows: list[dict[str, Any]] = []
    all_equal = True
    for prime in primes:
        transformed_hashes: list[str] = []
        prime_equal = True
        for vector in canonical_vectors:
            blocks = c4_block_transform(vector, int(prime))
            reconstructed = c4_block_inverse(blocks, int(prime))
            expected = [value % int(prime) for value in vector]
            equal = reconstructed == expected
            prime_equal = prime_equal and equal
            all_equal = all_equal and equal
            transformed_hashes.append(canonical_sha256(blocks))
        prime_rows.append(
            {
                "prime": int(prime),
                "vector_count": len(canonical_vectors),
                "all_vectors_reconstruct": prime_equal,
                "block_roster_sha256": canonical_sha256(
                    transformed_hashes
                ),
            }
        )
    if not all_equal:
        raise SLCV0031Error("C4 character blocks did not reconstruct raw lanes")
    unsigned = {
        "schema": "SLCV0031_C4_RAW_VS_CHARACTER_BLOCK_COMPARISON_V1",
        "raw_dimension": 16,
        "block_dimensions": [6, 3, 4, 3],
        "vector_count": len(canonical_vectors),
        "source_vectors_sha256": canonical_sha256(canonical_vectors),
        "prime_rows": prime_rows,
        "complete_exact_reconstruction": all_equal,
        "selected_scheduler": (
            "RAW_C4_LANES_PENDING_RESOURCE_COMPARISON"
        ),
    }
    return sealed(unsigned)


__all__ = [
    "EVENT_INCREMENTS",
    "FULL_Q_SCHEMA",
    "LOCAL_STATE_COUNT",
    "PORT_STATE_COUNT",
    "POSITION_COUNT",
    "RESPONSE_VALUES",
    "SHELL_STATE_COUNT",
    "apply_event",
    "apply_event_to_q_factors",
    "c4_character_multiplicities",
    "c4_block_comparison",
    "c4_block_coordinate_roster",
    "c4_block_inverse",
    "c4_block_transform",
    "c4_state_orbits",
    "compile_stage4_port_adapter",
    "decode_q_factors",
    "decode_state_id",
    "encode_q_vector",
    "finite_state_receipt",
    "full_q_tensor_plan",
    "make_state",
    "port_spins",
    "response_table",
    "rotate_port_state",
    "square_response",
    "state_id",
    "validate_full_q_tensor_plan",
    "validate_state",
]
