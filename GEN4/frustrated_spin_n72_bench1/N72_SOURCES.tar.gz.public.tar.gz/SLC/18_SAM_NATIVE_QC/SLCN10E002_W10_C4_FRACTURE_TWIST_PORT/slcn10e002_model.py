#!/usr/bin/env python3
"""Frozen ordered-edge C4 model for SLCN10E002."""

from __future__ import annotations

import hashlib
import itertools
import json
from collections import Counter, deque
from pathlib import Path
from typing import Any, Iterable, Sequence


CAMPAIGN_ID = "SLCN10E002_W10_C4_FRACTURE_TWIST_PORT"
RUNTIME_ID = "SLCN10_C4_ORDERED_EDGE_PORT_V0_1"
FACE_LABELS = ("---", "--+", "-+-", "-++", "+--", "+-+", "++-", "+++")
PLUS_RING = (1, 3, 7, 5)
MINUS_RING = (0, 2, 6, 4)
ORIENTATIONS = (0, 1, 2, 3)
RESPONSE_DOMAIN = (-4, -2, 0, 2, 4)
JOINED_ENERGY_DOMAIN = tuple(range(-12, 13, 2))
OPEN_ENERGY_DOMAIN = tuple(range(-16, 9, 2))


def canonical_sha256(value: object) -> str:
    return hashlib.sha256(
        json.dumps(
            value, sort_keys=True, separators=(",", ":"), ensure_ascii=True
        ).encode("utf-8")
    ).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalized(left: int, right: int) -> tuple[int, int]:
    if left == right:
        raise ValueError("self-edge is forbidden")
    return (left, right) if left < right else (right, left)


def ring_edges(ring: Sequence[int]) -> tuple[tuple[int, int], ...]:
    if len(ring) != 4:
        raise ValueError("ordered square ring must contain four entries")
    return tuple(
        sorted(
            normalized(ring[index], ring[(index + 1) % 4])
            for index in range(4)
        )
    )


def seam_edges(k: int) -> tuple[tuple[int, int], ...]:
    if k not in ORIENTATIONS:
        raise ValueError("orientation outside C4")
    return tuple(
        sorted(
            normalized(PLUS_RING[index], MINUS_RING[(index + k) % 4])
            for index in range(4)
        )
    )


def joined_edges(k: int) -> tuple[tuple[int, int], ...]:
    edges = set(ring_edges(PLUS_RING))
    edges.update(ring_edges(MINUS_RING))
    edges.update(seam_edges(k))
    if len(edges) != 12:
        raise ValueError("joined graph did not contain twelve edges")
    return tuple(sorted(edges))


def cube_edges() -> tuple[tuple[int, int], ...]:
    return tuple(
        pair
        for pair in itertools.combinations(range(8), 2)
        if pair[0] ^ pair[1] in (1, 2, 4)
    )


def open_w10_edges() -> tuple[tuple[int, int], ...]:
    edges = set(ring_edges(PLUS_RING))
    edges.update(ring_edges(MINUS_RING))
    edges.update(normalized(8, face) for face in PLUS_RING)
    edges.update(normalized(9, face) for face in MINUS_RING)
    if len(edges) != 16:
        raise ValueError("open W10 graph did not contain sixteen edges")
    return tuple(sorted(edges))


def bits_from_mask(mask: int, count: int) -> list[int]:
    return [(mask >> index) & 1 for index in range(count)]


def spins_from_bits(bits: Sequence[int]) -> list[int]:
    return [2 * bit - 1 for bit in bits]


def energy(spins: Sequence[int], edges: Iterable[Sequence[int]]) -> int:
    return -sum(spins[int(left)] * spins[int(right)] for left, right in edges)


def ordered_ports(spins: Sequence[int]) -> tuple[tuple[int, ...], tuple[int, ...]]:
    return (
        tuple(spins[index] for index in PLUS_RING),
        tuple(spins[index] for index in MINUS_RING),
    )


def rotate(values: Sequence[int], k: int) -> tuple[int, ...]:
    if len(values) != 4 or k not in ORIENTATIONS:
        raise ValueError("invalid C4 rotation")
    return tuple(values[(index + k) % 4] for index in range(4))


def port_response(
    plus_port: Sequence[int], minus_port: Sequence[int], k: int
) -> int:
    rotated_minus = rotate(minus_port, k)
    return -sum(
        plus_port[index] * rotated_minus[index] for index in range(4)
    )


def direct_seam_response(spins: Sequence[int], k: int) -> int:
    return energy(spins, seam_edges(k))


def ring_energy(spins: Sequence[int]) -> int:
    return energy(
        spins,
        tuple(sorted(set(ring_edges(PLUS_RING)) | set(ring_edges(MINUS_RING)))),
    )


def twist_signature(spins: Sequence[int]) -> tuple[int, int, int, int]:
    plus_port, minus_port = ordered_ports(spins)
    return tuple(
        port_response(plus_port, minus_port, k) for k in ORIENTATIONS
    )  # type: ignore[return-value]


def cyclic_shift(values: Sequence[int], shift: int) -> tuple[int, ...]:
    return tuple(values[(index + shift) % len(values)] for index in range(len(values)))


def signature_classification(signature: Sequence[int]) -> dict[str, Any]:
    if len(signature) != 4:
        raise ValueError("twist signature must contain four responses")
    minimum = min(signature)
    minimizers = tuple(index for index, value in enumerate(signature) if value == minimum)
    minimum_mask = sum(1 << index for index in minimizers)
    stabilizer = sum(
        cyclic_shift(signature, shift) == tuple(signature)
        for shift in ORIENTATIONS
    )
    if stabilizer not in (1, 2, 4) or 4 % stabilizer:
        raise ValueError("invalid C4 signature stabilizer")
    rotations = tuple(cyclic_shift(signature, shift) for shift in ORIENTATIONS)
    canonical = min(rotations)
    return {
        "c2_distinct_response_count": len({signature[0], signature[2]}),
        "c4_adds_response_over_c2": int(
            len(set(signature)) > len({signature[0], signature[2]})
        ),
        "canonical_signature": canonical,
        "distinct_response_count": len(set(signature)),
        "minimum_orientation_mask": minimum_mask,
        "minimum_orientations": minimizers,
        "minimum_response": minimum,
        "minimum_tie_count": len(minimizers),
        "signature_orbit_size": 4 // stabilizer,
        "signature_stabilizer_size": stabilizer,
        "unaddressed_multiset": tuple(sorted(signature)),
    }


def c4_packet() -> dict[str, Any]:
    composition = [
        {
            "a": a,
            "b": b,
            "composed": (a + b) % 4,
            "expected": (a + b) % 4,
            "pass": True,
        }
        for a in ORIENTATIONS
        for b in ORIENTATIONS
    ]
    associativity = [
        {
            "a": a,
            "b": b,
            "c": c,
            "left": ((a + b) % 4 + c) % 4,
            "pass": ((a + b) % 4 + c) % 4 == (a + (b + c) % 4) % 4,
            "right": (a + (b + c) % 4) % 4,
        }
        for a in ORIENTATIONS
        for b in ORIENTATIONS
        for c in ORIENTATIONS
    ]
    gluing_maps: list[dict[str, Any]] = []
    for k in ORIENTATIONS:
        mapped_edges = []
        for local_edge in range(4):
            tail = (k - local_edge) % 4
            head = (k - (local_edge + 1)) % 4
            global_edge = head
            expected_tail = (global_edge + 1) % 4
            expected_head = global_edge
            orientation = -1 if (tail, head) == (expected_tail, expected_head) else 0
            mapped_edges.append(
                {
                    "global_edge": global_edge,
                    "local_edge": local_edge,
                    "orientation": orientation,
                }
            )
        gluing_maps.append(
            {
                "all_four_edges_reverse": all(
                    row["orientation"] == -1 for row in mapped_edges
                ),
                "k": k,
                "mapped_edges": mapped_edges,
                "vertex_map": [(k - index) % 4 for index in range(4)],
            }
        )
    return {
        "associativity": associativity,
        "composition": composition,
        "gluing_maps": gluing_maps,
        "group": "C4",
    }


def graph_metrics(n: int, edges: Iterable[Sequence[int]]) -> dict[str, Any]:
    edge_set = {normalized(int(edge[0]), int(edge[1])) for edge in edges}
    adjacency = [set() for _ in range(n)]
    for left, right in edge_set:
        adjacency[left].add(right)
        adjacency[right].add(left)
    remaining = set(range(n))
    components: list[int] = []
    while remaining:
        root = min(remaining)
        seen = {root}
        queue: deque[int] = deque([root])
        while queue:
            node = queue.popleft()
            for neighbor in adjacency[node]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    queue.append(neighbor)
        remaining -= seen
        components.append(len(seen))
    triangles = sum(
        all(normalized(a, b) in edge_set for a, b in itertools.combinations(nodes, 2))
        for nodes in itertools.combinations(range(n), 3)
    )
    return {
        "component_sizes": sorted(components, reverse=True),
        "degree_histogram": {
            str(degree): count
            for degree, count in sorted(Counter(map(len, adjacency)).items())
        },
        "edge_count": len(edge_set),
        "triangle_count": triangles,
    }

