# Fresh dense N96 on eight H100 workers

Prepared for the owner's eight-H100 pod. Each GPU has one independent spawned
worker. The CPU owns the exact inverse NTT, CRT, boundary gluing and frozen
open/closed directional fiber attachments. This is a source-bound execution
successor of GEN3_POD_N96_GPU1, not a global SLC engine promotion.

The source is the original dense 96-spin / 240-edge instance
625bcd4327e678fa9541d7ab4109449e432d199aad1fba6e1f254395ebdd203d:
32 cutset branches, four retained ports, four CRT primes, 1,024 roots each.
Each worker receives an initial eight-root batch, then pulls from a shared
queue. All 4,096 root vectors are computed afresh. There is no resume option,
checkpoint input, or saved-arithmetic input to the GPU calculation. Historical
vectors are confined to offline wiring tests; production compares freshly
reconstructed residues with frozen authority after the GPU calculation.

CPU fiber assembly uses the original frozen mathematical maps. The CPU is
their execution host; GPU process identifiers do not become mathematical
fiber coordinates. This deployment changes scheduling and device ownership,
not the source or fiber definition. CPU factor preparation feeds each GPU;
the owning CPU performs final assembly after all root batches arrive.

## Prepared checks

LOCAL_CHECK.json: offline root-roster coverage and CPU reconstruction/fiber
wiring pass on labeled saved test fixtures. This is not a fresh N96 solve or
GPU qualification. WATCH_CHECK.json: success/error handling and actual whole
process-group deadline termination pass, including a descendant process.
The literal modular CUDA step is unchanged from the preceding GPU campaign.
Actual eight-device preflight and fresh hardware equality remain pending.

The old launcher's final assembly had missing coefficient-residue hashes,
missing packaged fiber dependencies, and an output path pointing into the
frozen authority tree. This successor supplies those hashes/dependencies and
binds output to the new run. The old five-minute record stays unchanged.

## Deployment after pod power-on

The previous endpoint was root@103.207.149.74 port 19271; obtain the new endpoint
if the provider changes it. CPU quota, RAM and storage still require live
inspection. Upload payload.tar.gz and its SHA-256 sidecar, verify, and extract
into a NEW directory under /gen3-data/n96-h100x8/source. The extracted campaign
path is SAM_REVIEW/campaigns/GEN3_POD_N96_H100X8_PREP1.

Run `bash setup.sh` from that campaign directory. It creates a dedicated venv,
installs pinned NumPy/CuPy, checks every source hash, and executes a small
exact CUDA step on each of the eight GPUs. It records CPU quota, memory, GPUs
and mount sizes in /workspace/n96-h100x8/PREFLIGHT.json. Review that receipt
before starting the fresh run. Setup does not start N96.

Run `bash launch.sh` under an independent shell/nohup after preflight passes.
Default N96_LIMIT_SECONDS=300 bounds the fresh solver including source/cache
preparation and CPU assembly; setup is outside that timer. Set that variable
explicitly to change the bound. Each launch creates a unique fresh run.
Watch STATE.json, PROGRESS.json and stdout.jsonl. COMPLETE requires the full
solver's successful exit; RESULT.json records exact equality checks and actual
root counts per GPU. A deadline preserves completed batch checkpoints but
never resumes automatically. Do not describe partial roots as a full solve.

Bulk cache, environment and sources: /gen3-data/n96-h100x8 (container disk).
Compact results/state: /workspace/n96-h100x8. Mount persistence is unverified
until power-on; copy retained results off the pod before lifecycle removal.
The solver guards disk and live available CPU memory. It uses paid-pod
resources without imposing workstation utilization caps. Neither script
stops the provider or billing. Notify the owner after results are copied and
all computation exits so they can turn the pod off promptly.
