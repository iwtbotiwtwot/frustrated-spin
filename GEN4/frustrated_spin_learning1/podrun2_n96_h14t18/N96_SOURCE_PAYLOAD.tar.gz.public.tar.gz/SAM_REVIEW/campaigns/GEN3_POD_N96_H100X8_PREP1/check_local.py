"""Offline wiring qualification; saved vectors are test fixtures, never fresh work."""
import json
from pathlib import Path
import sys
import tempfile
import numpy as np
import run


def main():
    coverage = set()
    for pi, lo, hi in run.tasks():
        for root in range(lo, hi):
            assert (pi, root) not in coverage
            coverage.add((pi, root))
    assert coverage == {(p, r) for p in range(4) for r in range(1024)}
    authority, templates, branches, desc = run.source()
    assert len(templates) == 32
    assert desc['source_instance_n'] == 91
    lanes = []
    for pi in range(4):
        path = run.BASE/'work/N96_H14F/prime_lanes'/f'prime_{pi:02d}.json'
        values = np.array(json.loads(path.read_text())['evaluations'], dtype=np.int64)
        lane = run.lane_from_values(pi, values, fresh=False, workers_active=True, reserve_ok=True)
        lanes.append(lane)
    with tempfile.TemporaryDirectory(prefix='n96-fiber-check-') as temp:
        _, checks = run.assemble(authority, lanes, temp)
    assert checks.pop('all_4096_singleton_tasks_fresh') is False
    assert all(checks.values()), checks
    loaded = sorted({str(Path(m.__file__).resolve().relative_to(run.ROOT))
                     for m in list(sys.modules.values()) if getattr(m, '__file__', None)
                     and Path(m.__file__).resolve().is_relative_to(run.ROOT)
                     and '.venv' not in str(m.__file__)})
    result = dict(status='OFFLINE_WIRING_PASS', fresh_n96_executed=False,
                  unique_root_tasks=len(coverage), branches=len(templates),
                  cpu_fiber_checks=checks, loaded_source_files=loaded,
                  gpu_hardware_check='PENDING_POD_START')
    run.save(run.HERE/'LOCAL_CHECK.json', result)
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
