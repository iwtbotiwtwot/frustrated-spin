"""Actual pod allocation and exact CUDA step smoke test on every device."""
import json
import subprocess
from pathlib import Path
import numpy as np
import cupy as cp
import run

run.verify_sources()
if cp.cuda.runtime.getDeviceCount() != 8:
    raise RuntimeError('need exactly eight visible GPUs')
devices = []
prime = int(run.a.n96_engine.PRIMES[0])
for device in range(8):
    with cp.cuda.Device(device):
        kernel = cp.RawKernel((run.HERE/'kernel.cu').read_text(), 'step')
        factors = cp.asarray([prime-2, prime-3], dtype=cp.uint32)
        maps = cp.asarray([0], dtype=cp.uint32)
        fs = cp.asarray([factors.data.ptr], dtype=cp.uint64)
        ms = cp.asarray([maps.data.ptr], dtype=cp.uint64)
        bits = cp.asarray([1], dtype=cp.uint32)
        out = cp.empty(1, dtype=cp.uint32)
        kernel((1,), (32,), (fs, ms, bits, out, np.uint64(1), np.int32(1),
                            np.int32(1), np.uint32(prime), np.uint64((1 << 64)//prime)))
        assert int(out.get()[0]) == prime-5
        free, total = cp.cuda.runtime.memGetInfo()
        devices.append(dict(device=device, memory_bytes=total, free_bytes=free, exact_step_pass=True))
        cp.get_default_memory_pool().free_all_blocks()

def read(path):
    p = Path(path)
    return p.read_text().strip() if p.exists() else None
report = dict(status='EIGHT_GPU_PREFLIGHT_PASS', devices=devices,
              cpu_max=read('/sys/fs/cgroup/cpu.max'),
              memory_max=read('/sys/fs/cgroup/memory.max'),
              available_memory_bytes=run.available_memory(),
              cpu=subprocess.check_output(['lscpu'], text=True),
              storage=subprocess.check_output(['df', '-h', '/', '/workspace'], text=True),
              gpus=subprocess.check_output(['nvidia-smi', '--query-gpu=name,memory.total,driver_version', '--format=csv'], text=True))
print(json.dumps(report, indent=2))
