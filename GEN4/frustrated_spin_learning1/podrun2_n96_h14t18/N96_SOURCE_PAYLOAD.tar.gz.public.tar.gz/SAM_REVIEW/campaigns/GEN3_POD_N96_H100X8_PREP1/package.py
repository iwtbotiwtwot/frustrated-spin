"""Build a compact source-complete upload from explicit dependency receipts."""
import hashlib
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
old = ROOT/'SAM_REVIEW/campaigns/GEN3_POD_N96_GPU1'
paths = {p for p in json.loads((old/'MANIFEST.json').read_text())
         if not p.startswith('SAM_REVIEW/campaigns/GEN3_POD_N96_GPU1/')}
paths.update(json.loads((HERE/'LOCAL_CHECK.json').read_text())['loaded_source_files'])
paths.update(str(p.relative_to(ROOT)) for p in HERE.iterdir()
             if p.suffix in ('.py', '.sh', '.cu', '.txt', '.md'))
manifest = {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sorted(paths)}
(HERE/'MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
extra = [HERE/'MANIFEST.json', HERE/'LOCAL_CHECK.json', HERE/'WATCH_CHECK.json']
with tarfile.open(HERE/'payload.tar.gz', 'w:gz') as tar:
    for p in sorted(paths):
        tar.add(ROOT/p, arcname=p, recursive=False)
    for p in extra:
        tar.add(p, arcname=str(p.relative_to(ROOT)), recursive=False)
archive = HERE/'payload.tar.gz'
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(HERE/'payload.tar.gz.sha256').write_text(f'{digest}  payload.tar.gz\n')
print(json.dumps(dict(source_files=len(paths), archive_bytes=archive.stat().st_size, sha256=digest)))
