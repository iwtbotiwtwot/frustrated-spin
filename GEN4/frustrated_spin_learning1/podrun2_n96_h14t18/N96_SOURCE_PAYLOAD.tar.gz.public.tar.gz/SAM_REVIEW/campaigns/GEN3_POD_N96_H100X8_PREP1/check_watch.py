"""Exercise completion, failure, and actual descendant termination at deadline."""
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import watch

with tempfile.TemporaryDirectory(prefix='n96-watch-check-') as directory:
    root = Path(directory)
    complete = watch.supervise([sys.executable, '-c', 'pass'], root/'complete', 3)
    assert complete['status'] == 'COMPLETE'
    failure = watch.supervise([sys.executable, '-c', 'raise SystemExit(7)'], root/'failure', 3)
    assert failure['status'] == 'EXECUTION_ERROR' and failure['returncode'] == 7
    pid_path = root/'child.pid'
    code = ('import subprocess,sys,time; from pathlib import Path; '
            'p=subprocess.Popen([sys.executable,"-c","import time; time.sleep(60)"]); '
            f'Path({str(pid_path)!r}).write_text(str(p.pid)); time.sleep(60)')
    timeout = watch.supervise([sys.executable, '-c', code], root/'timeout', 1)
    assert timeout['status'] == 'STOPPED_AT_DEADLINE'
    pid = int(pid_path.read_text())
    for _ in range(30):
        path = Path(f'/proc/{pid}/stat')
        if not path.exists() or path.read_text().split()[2] == 'Z':
            break
        time.sleep(.1)
    else:
        raise AssertionError('descendant survived watchdog')
    result = dict(status='PASS', successful_exit=complete, failed_exit=failure,
                  deadline=timeout, descendant_stopped=True)
    Path(__file__).with_name('WATCH_CHECK.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result))
