"""Eight independent GPU owners, shared root queue, CPU exact fiber owner."""
import os
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import argparse
import hashlib
import itertools
import json
import multiprocessing as mp
from pathlib import Path
import queue
import shutil
import sys
import time
import traceback
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = ROOT/'SLC/18_SAM_NATIVE_QC/SLCV05_H14F_N18_N54_N96_ACCEPTANCE_V1'
sys.path[:0] = [str(ROOT), str(BASE)]
import run_n96_acceptance as a


def save(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    tmp.write_text(json.dumps(value, sort_keys=True)+'\n')
    tmp.replace(path)


def tasks(batch=8):
    # Interleave primes across the common queue; CPU assembles after root completion.
    return [(pi, lo, min(lo+batch, 1024)) for lo in range(0, 1024, batch) for pi in range(4)]


def verify_sources():
    manifest = json.loads((HERE/'MANIFEST.json').read_text())
    for name, digest in manifest.items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f'source mismatch: {name}')
    return manifest


def source():
    authority = a.validate_authorities()
    instance, plan = authority[:2]
    templates, branches = a.n96_engine.build_branch_templates(instance, plan)
    ref = templates[0]
    desc = a.compile_descriptor(a.n96_engine.retained_engine, ref.local_instance,
                                ref.elimination_order, ref.port_order)
    a.validate_descriptor(desc)
    return authority, templates, branches, desc


def available_memory():
    host = a.meminfo()['MemAvailable']
    cgroup = Path('/sys/fs/cgroup')
    if (cgroup/'memory.max').exists():
        limit = (cgroup/'memory.max').read_text().strip()
        if limit != 'max':
            host = min(host, int(limit)-int((cgroup/'memory.current').read_text()))
    return host


def worker(device, inbox, output, start_gate, cache_path, out, first_task):
    try:
        from gpu import GPUWorker
        authority, templates, _, desc = source()
        cache = a.open_cache_file(Path(cache_path), desc)
        gpu = GPUWorker(device, a, templates, desc, cache)
        output.put(('ready', device, None))
        start_gate.wait()
        for task in itertools.chain([first_task], iter(inbox.get, None)):
            pi, lo, hi = task
            t = time.monotonic()
            values = gpu.evaluate(authority[1]['primes'][pi], lo, hi)
            # Immutable per-batch checkpoint, persisted before notifying the CPU.
            file = Path(out)/f'batch_p{pi}_{lo:04d}_{hi:04d}.json'
            save(file, dict(gpu=device, prime_index=pi, root_start=lo,
                           root_stop=hi, evaluations=values.tolist(),
                           seconds=time.monotonic()-t))
            output.put(('batch', device, (pi, lo, hi, str(file))))
        cache.close()
    except BaseException:
        output.put(('error', device, traceback.format_exc()))
        raise


def lane_from_values(pi, values, *, fresh, workers_active, reserve_ok):
    e = a.n96_engine
    prime = e.PRIMES[pi]
    residues = [e.inverse_ntt(row, prime) for row in values.tolist()]
    expected = a.load_json(a.authority_residue_path(pi))
    if residues != expected['coefficient_residues']:
        raise RuntimeError(f'fresh residue mismatch in prime {pi}')
    return dict(prime=prime, coefficient_residues=residues,
                coefficient_residue_sha256=a.canonical_sha256(residues),
                coefficient_residues_equal_frozen=True,
                fresh_singleton_task_count=1024 if fresh else 0,
                all_workers_active=workers_active, system_reserve_maintained=reserve_ok,
                lane_sha256=a.canonical_sha256(values.tolist()))


def assemble(authority, lanes, out):
    instance, plan, fiber, expected, expected_op, _, scale = authority
    # The frozen helper writes OPERATOR as a side effect; bind it to this new run.
    a.OPERATOR = Path(out)/'OPERATOR.json'
    operator, recovery, checks = a.reconstruct(instance, plan, fiber, expected,
                                              expected_op, lanes, plan, scale)
    save(Path(out)/'RECOVERY.json', recovery)
    return operator, checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--bulk', type=Path, required=True)
    parser.add_argument('--batch', type=int, default=8)
    args = parser.parse_args()
    if not 1 <= args.batch <= 32:
        raise ValueError('batch must be between 1 and 32')
    args.out.mkdir(parents=True, exist_ok=False)
    args.bulk.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    manifest = verify_sources()
    import cupy as cp
    if cp.cuda.runtime.getDeviceCount() != 8:
        raise RuntimeError('this launch requires exactly eight visible GPUs')
    # Large scratch must be outside the small /workspace filesystem.
    if args.bulk.resolve().is_relative_to(Path('/workspace')):
        raise RuntimeError('bulk must be on container storage, outside /workspace')
    authority, templates, branches, desc = source()
    minimum_available = available_memory()
    reserve = 1 << 30
    if minimum_available < desc['total_bytes']*2 + reserve:
        raise RuntimeError('insufficient memory for shared cache and CPU fiber')
    if shutil.disk_usage(args.bulk).free < desc['total_bytes'] + reserve:
        raise RuntimeError('insufficient bulk disk space')
    if shutil.disk_usage(args.out).free < reserve:
        raise RuntimeError('insufficient checkpoint disk space')
    save(args.out/'SOURCE.json', dict(instance=authority[0], plan=authority[1],
        branches=branches, manifest=manifest, gpu_workers=8, batch=args.batch,
        route='eight spawned GPU workers/shared queue; CPU inverse NTT/CRT/fiber',
        fresh_arithmetic=True, bulk=str(args.bulk), durable=str(args.out)))
    save(args.out/'GRAPH.json', desc)
    cache_path = args.bulk/'projection_cache.bin'
    save(args.out/'CACHE.json', a.build_cache_file(cache_path, desc))
    ctx = mp.get_context('spawn')
    inbox, output, gate = ctx.Queue(), ctx.Queue(), ctx.Event()
    roster = tasks(args.batch)
    processes = [ctx.Process(target=worker, args=(d, inbox, output, gate, str(cache_path), str(args.out), roster[d])) for d in range(8)]
    seen = set()
    counts = [0]*8
    values = [np.zeros((16, 1024), dtype=np.int64) for _ in range(4)]
    def receive():
        while True:
            try:
                kind, device, data = output.get(timeout=1)
            except queue.Empty:
                failed = [(d, p.exitcode) for d, p in enumerate(processes) if p.exitcode is not None]
                if failed:
                    raise RuntimeError(f'worker exited before completion: {failed}')
                continue
            if kind == 'error':
                raise RuntimeError(f'GPU{device}: {data}')
            return kind, device, data
    try:
        for p in processes:
            p.start()
        ready = set()
        while len(ready) < 8:
            kind, device, _ = receive()
            if kind != 'ready' or device in ready:
                raise RuntimeError('invalid worker readiness')
            ready.add(device)
        for task in roster[8:]:
            inbox.put(task)
        gate.set()
        while len(seen) < len(roster):
            kind, device, data = receive()
            if kind != 'batch':
                raise RuntimeError('unexpected worker message')
            pi, lo, hi, file = data
            task = (pi, lo, hi)
            if task in seen or task not in roster:
                raise RuntimeError('duplicate or unknown batch')
            record = json.loads(Path(file).read_text())
            batch = np.asarray(record['evaluations'], dtype=np.int64)
            if batch.shape != (16, hi-lo):
                raise RuntimeError('invalid result shape')
            values[pi][:, lo:hi] = batch
            seen.add(task)
            counts[device] += hi-lo
            minimum_available = min(minimum_available, available_memory())
            if minimum_available < reserve:
                raise RuntimeError('CPU memory reserve exhausted; checkpoints preserved')
            status = dict(status='GPU_ROOTS', completed_roots=sum(counts), total_roots=4096,
                          roots_per_gpu=counts, elapsed_seconds=time.monotonic()-start)
            save(args.out/'PROGRESS.json', status)
            print(json.dumps(status), flush=True)
        for _ in processes:
            inbox.put(None)
        for p in processes:
            p.join(timeout=10)
            if p.exitcode != 0:
                raise RuntimeError('worker shutdown failed')
    finally:
        for p in processes:
            if p.is_alive():
                p.terminate()
        for p in processes:
            if p.pid is not None:
                p.join(timeout=5)
                if p.is_alive():
                    p.kill()
                    p.join()
    save(args.out/'PROGRESS.json', dict(status='CPU_FIBER', completed_roots=4096,
                                      roots_per_gpu=counts, elapsed_seconds=time.monotonic()-start))
    lanes = []
    for pi in range(4):
        lane = lane_from_values(pi, values[pi], fresh=True,
                               workers_active=all(counts), reserve_ok=minimum_available >= reserve)
        save(args.out/f'PRIME_{pi}.json', lane)
        lanes.append(lane)
    _, checks = assemble(authority, lanes, args.out)
    if not all(checks.values()):
        raise RuntimeError(f'assembly checks failed: {checks}')
    result = dict(status='EXACT_N96_COMPLETE', seconds=time.monotonic()-start,
                  checks=checks, configuration_count=str(1 << 96), gpu_workers=8,
                  roots_per_gpu=counts, minimum_available_memory_bytes=minimum_available,
                  source_instance=authority[0]['instance_sha256'])
    save(args.out/'RESULT.json', result)
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    main()
