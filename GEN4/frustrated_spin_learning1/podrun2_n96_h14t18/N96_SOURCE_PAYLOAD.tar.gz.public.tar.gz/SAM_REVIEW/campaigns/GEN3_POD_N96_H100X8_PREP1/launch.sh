#!/usr/bin/env bash
set -euo pipefail
campaign=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
run_id="fresh_$(date -u +%Y%m%dT%H%M%SZ)_$$"
export CUPY_CACHE_DIR=/gen3-data/n96-h100x8/cupy-cache
# Fresh unique output/cache paths; no checkpoint input or resume option exists.
exec /gen3-data/n96-h100x8/venv/bin/python -u "$campaign/watch.py" \
  --out "/workspace/n96-h100x8/$run_id/results" \
  --state "/workspace/n96-h100x8/$run_id/watch" \
  --bulk "/gen3-data/n96-h100x8/$run_id" \
  --seconds "${N96_LIMIT_SECONDS:-300}"
