"""Exact GPU elimination body retained from GEN3_POD_N96_GPU1.
One instance lives in each independent GPU process; CPU owns assembly.
"""
import numpy as np

class GPUWorker:
    def __init__(self, device, a, templates, desc, cache):
        import cupy as cp
        from pathlib import Path
        cp.cuda.Device(device).use()
        self.cp, self.a, self.templates, self.desc = cp, a, templates, desc
        self.kernel = cp.RawKernel(Path(__file__).with_name('kernel.cu').read_text(), 'step')
        self.kernel.compile()
        self.maps = [[cp.asarray(m, dtype=cp.uint32) for m in group] for group in cache.maps]
        self.bits = [cp.asarray([x['eliminated_factor_bit'] for x in s['maps']], dtype=cp.uint32) for s in desc['steps']]
        self.pointers = [cp.asarray([m.data.ptr for m in group], dtype=cp.uint64) for group in self.maps]
        cp.cuda.get_current_stream().synchronize()

    def evaluate(self, prime, lo, hi):
        cp, a, templates, desc = self.cp, self.a, self.templates, self.desc
        e = a.n96_engine
        exact = e.retained_engine._modules()[1]
        kernel, bits, pointers = self.kernel, self.bits, self.pointers
        points = e.zeta_points(prime, 1024, lo, hi)
        total = cp.zeros((16, hi-lo), cp.uint64)
        for template in templates:
         factors=[(tuple(f.scope),cp.asarray(f.values,dtype=cp.uint32)) for f in exact._initial_factors(template.local_instance,points,prime)]
         assert a.canonical_sha256([list(scope) for scope,values in factors])==desc['initial_factor_scope_sha256']
         for si,s in enumerate(desc['steps']):
          selected=[f for f in factors if s['vertex'] in f[0]];factors=[f for f in factors if s['vertex'] not in f[0]]
          assert [list(f[0]) for f in selected]==[x['factor_scope'] for x in s['maps']]
          values=cp.empty((1<<len(s['output_scope']),hi-lo),cp.uint32);ptr=cp.asarray([v.data.ptr for scope,v in selected],cp.uint64);n=values.size
          kernel(((n+255)//256,),(256,),(ptr,pointers[si],bits[si],values,np.uint64(n),np.int32(hi-lo),np.int32(len(selected)),np.uint32(prime),np.uint64((1<<64)//prime)))
          factors.append((tuple(s['output_scope']),values))
         terminal=cp.ones((16,hi-lo),cp.uint64)
         for scope,values in factors:
          idx=e.retained_engine._project_indices(np.arange(16,dtype=np.uint64),template.port_order,scope)
          terminal=(terminal*values[cp.asarray(idx)].astype(cp.uint64))%prime
         shifts=cp.asarray([pow(int(point),template.z_degree_shift,prime) for point in points],cp.uint64)
         total=(total+terminal*shifts[None,:]%prime)%prime

        return cp.asnumpy(total).astype(np.int64)
