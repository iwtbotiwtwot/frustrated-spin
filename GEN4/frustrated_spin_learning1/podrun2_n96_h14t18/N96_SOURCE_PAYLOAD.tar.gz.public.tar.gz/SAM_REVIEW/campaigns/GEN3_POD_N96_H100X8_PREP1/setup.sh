#!/usr/bin/env bash
set -euo pipefail
campaign=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
mkdir -p /gen3-data/n96-h100x8 /workspace/n96-h100x8
export PIP_CACHE_DIR=/gen3-data/n96-h100x8/pip-cache
export CUPY_CACHE_DIR=/gen3-data/n96-h100x8/cupy-cache
python3 -m venv /gen3-data/n96-h100x8/venv
/gen3-data/n96-h100x8/venv/bin/python -m pip install -r "$campaign/requirements.txt"
/gen3-data/n96-h100x8/venv/bin/python "$campaign/preflight.py" > /workspace/n96-h100x8/PREFLIGHT.json
cat /workspace/n96-h100x8/PREFLIGHT.json
