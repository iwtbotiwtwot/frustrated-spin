"""Bounded fresh launch; terminate the whole solver process group on expiry."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def supervise(command, state, seconds):
    if seconds <= 0:
        raise ValueError('deadline must be positive')
    state.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    def record(value):
        tmp = state/'STATE.tmp'
        tmp.write_text(json.dumps(value, indent=2)+'\n')
        tmp.replace(state/'STATE.json')
    with (state/'stdout.jsonl').open('w') as log:
        p = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        record(dict(status='RUNNING', pid=p.pid, started_epoch=time.time(), hard_limit_seconds=seconds))
        try:
            code = p.wait(timeout=max(0.001, seconds-(time.monotonic()-start)))
            status = 'COMPLETE' if code == 0 else 'EXECUTION_ERROR'
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL)
            code = p.wait()
            status = 'STOPPED_AT_DEADLINE'
        finally:
            # Includes failed-parent cases that may leave GPU descendants alive.
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        result = dict(status=status, returncode=code,
                      elapsed_seconds=time.monotonic()-start, hard_limit_seconds=seconds)
        record(result)
        return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--bulk', type=Path, required=True)
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=300)
    args = parser.parse_args()
    result = supervise([sys.executable, '-u', str(Path(__file__).with_name('run.py')),
                        '--out', str(args.out), '--bulk', str(args.bulk)], args.state, args.seconds)
    print(json.dumps(result), flush=True)
    sys.exit(0 if result['status'] == 'COMPLETE' else 1)
